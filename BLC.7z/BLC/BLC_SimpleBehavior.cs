using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
public partial class BLC
{
#region Members
#region Used For Delete Operations
private Coach_leaderboards _Coach_leaderboards;
private Player_leaderboards _Player_leaderboards;
private Playersport _Playersport;
private Sport _Sport;
private Coachsport _Coachsport;
private Coach_evaluation _Coach_evaluation;
private Currency _Currency;
private Session_evaluation _Session_evaluation;
private Taken_session _Taken_session;
private Scheduled_session _Scheduled_session;
private Notification _Notification;
private Owner _Owner;
private Comment _Comment;
private Report_coach _Report_coach;
private Comment_report _Comment_report;
private User _User;
private Direct_message _Direct_message;
private Report_player _Report_player;
private Coach _Coach;
private Player _Player;
#endregion
#region Stop Executing Flags For Edit and Delete Operations
private bool _Stop_Edit_Coach_leaderboards_Execution;
private bool _Stop_Delete_Coach_leaderboards_Execution;
private bool _Stop_Edit_Player_leaderboards_Execution;
private bool _Stop_Delete_Player_leaderboards_Execution;
private bool _Stop_Edit_Playersport_Execution;
private bool _Stop_Delete_Playersport_Execution;
private bool _Stop_Edit_Sport_Execution;
private bool _Stop_Delete_Sport_Execution;
private bool _Stop_Edit_Coachsport_Execution;
private bool _Stop_Delete_Coachsport_Execution;
private bool _Stop_Edit_Coach_evaluation_Execution;
private bool _Stop_Delete_Coach_evaluation_Execution;
private bool _Stop_Edit_Currency_Execution;
private bool _Stop_Delete_Currency_Execution;
private bool _Stop_Edit_Session_evaluation_Execution;
private bool _Stop_Delete_Session_evaluation_Execution;
private bool _Stop_Edit_Taken_session_Execution;
private bool _Stop_Delete_Taken_session_Execution;
private bool _Stop_Edit_Scheduled_session_Execution;
private bool _Stop_Delete_Scheduled_session_Execution;
private bool _Stop_Edit_Notification_Execution;
private bool _Stop_Delete_Notification_Execution;
private bool _Stop_Edit_Owner_Execution;
private bool _Stop_Delete_Owner_Execution;
private bool _Stop_Edit_Comment_Execution;
private bool _Stop_Delete_Comment_Execution;
private bool _Stop_Edit_Report_coach_Execution;
private bool _Stop_Delete_Report_coach_Execution;
private bool _Stop_Edit_Comment_report_Execution;
private bool _Stop_Delete_Comment_report_Execution;
private bool _Stop_Edit_User_Execution;
private bool _Stop_Delete_User_Execution;
private bool _Stop_Edit_Direct_message_Execution;
private bool _Stop_Delete_Direct_message_Execution;
private bool _Stop_Edit_Report_player_Execution;
private bool _Stop_Delete_Report_player_Execution;
private bool _Stop_Edit_Coach_Execution;
private bool _Stop_Delete_Coach_Execution;
private bool _Stop_Edit_Player_Execution;
private bool _Stop_Delete_Player_Execution;
#endregion
#endregion
public Coach_leaderboards Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID(Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID)
{
Coach_leaderboards oCoach_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID");}
#region Body Section.
DALC.Coach_leaderboards oDBEntry = _AppContext.Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID(i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID.COACH_LEADERBOARDS_ID);
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID");}
return oCoach_leaderboards;
}
public Player_leaderboards Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID(Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID)
{
Player_leaderboards oPlayer_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID");}
#region Body Section.
DALC.Player_leaderboards oDBEntry = _AppContext.Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID(i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID.PLAYER_LEADERBOARDS_ID);
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID");}
return oPlayer_leaderboards;
}
public Playersport Get_Playersport_By_PLAYERSPORT_ID(Params_Get_Playersport_By_PLAYERSPORT_ID i_Params_Get_Playersport_By_PLAYERSPORT_ID)
{
Playersport oPlayersport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYERSPORT_ID");}
#region Body Section.
DALC.Playersport oDBEntry = _AppContext.Get_Playersport_By_PLAYERSPORT_ID(i_Params_Get_Playersport_By_PLAYERSPORT_ID.PLAYERSPORT_ID);
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYERSPORT_ID");}
return oPlayersport;
}
public Sport Get_Sport_By_SPORT_ID(Params_Get_Sport_By_SPORT_ID i_Params_Get_Sport_By_SPORT_ID)
{
Sport oSport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_SPORT_ID");}
#region Body Section.
DALC.Sport oDBEntry = _AppContext.Get_Sport_By_SPORT_ID(i_Params_Get_Sport_By_SPORT_ID.SPORT_ID);
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_SPORT_ID");}
return oSport;
}
public Coachsport Get_Coachsport_By_COACHSPORT_ID(Params_Get_Coachsport_By_COACHSPORT_ID i_Params_Get_Coachsport_By_COACHSPORT_ID)
{
Coachsport oCoachsport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACHSPORT_ID");}
#region Body Section.
DALC.Coachsport oDBEntry = _AppContext.Get_Coachsport_By_COACHSPORT_ID(i_Params_Get_Coachsport_By_COACHSPORT_ID.COACHSPORT_ID);
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACHSPORT_ID");}
return oCoachsport;
}
public Coach_evaluation Get_Coach_evaluation_By_COACH_EVALUATION_ID(Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID)
{
Coach_evaluation oCoach_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID");}
#region Body Section.
DALC.Coach_evaluation oDBEntry = _AppContext.Get_Coach_evaluation_By_COACH_EVALUATION_ID(i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID.COACH_EVALUATION_ID);
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID");}
return oCoach_evaluation;
}
public Currency Get_Currency_By_CURRENCY_ID(Params_Get_Currency_By_CURRENCY_ID i_Params_Get_Currency_By_CURRENCY_ID)
{
Currency oCurrency = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_CURRENCY_ID");}
#region Body Section.
DALC.Currency oDBEntry = _AppContext.Get_Currency_By_CURRENCY_ID(i_Params_Get_Currency_By_CURRENCY_ID.CURRENCY_ID);
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_CURRENCY_ID");}
return oCurrency;
}
public Session_evaluation Get_Session_evaluation_By_SESSION_EVALUATION_ID(Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID)
{
Session_evaluation oSession_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID");}
#region Body Section.
DALC.Session_evaluation oDBEntry = _AppContext.Get_Session_evaluation_By_SESSION_EVALUATION_ID(i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID.SESSION_EVALUATION_ID);
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID");}
return oSession_evaluation;
}
public Taken_session Get_Taken_session_By_TAKEN_SESSION_ID(Params_Get_Taken_session_By_TAKEN_SESSION_ID i_Params_Get_Taken_session_By_TAKEN_SESSION_ID)
{
Taken_session oTaken_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID");}
#region Body Section.
DALC.Taken_session oDBEntry = _AppContext.Get_Taken_session_By_TAKEN_SESSION_ID(i_Params_Get_Taken_session_By_TAKEN_SESSION_ID.TAKEN_SESSION_ID);
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID");}
return oTaken_session;
}
public Scheduled_session Get_Scheduled_session_By_SCHEDULED_SESSION_ID(Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID)
{
Scheduled_session oScheduled_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID");}
#region Body Section.
DALC.Scheduled_session oDBEntry = _AppContext.Get_Scheduled_session_By_SCHEDULED_SESSION_ID(i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID.SCHEDULED_SESSION_ID);
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID");}
return oScheduled_session;
}
public Notification Get_Notification_By_NOTIFICATION_ID(Params_Get_Notification_By_NOTIFICATION_ID i_Params_Get_Notification_By_NOTIFICATION_ID)
{
Notification oNotification = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID");}
#region Body Section.
DALC.Notification oDBEntry = _AppContext.Get_Notification_By_NOTIFICATION_ID(i_Params_Get_Notification_By_NOTIFICATION_ID.NOTIFICATION_ID);
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID");}
return oNotification;
}
public Owner Get_Owner_By_OWNER_ID(Params_Get_Owner_By_OWNER_ID i_Params_Get_Owner_By_OWNER_ID)
{
Owner oOwner = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_OWNER_ID");}
#region Body Section.
DALC.Owner oDBEntry = _AppContext.Get_Owner_By_OWNER_ID(i_Params_Get_Owner_By_OWNER_ID.OWNER_ID);
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_OWNER_ID");}
return oOwner;
}
public Comment Get_Comment_By_COMMENT_ID(Params_Get_Comment_By_COMMENT_ID i_Params_Get_Comment_By_COMMENT_ID)
{
Comment oComment = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COMMENT_ID");}
#region Body Section.
DALC.Comment oDBEntry = _AppContext.Get_Comment_By_COMMENT_ID(i_Params_Get_Comment_By_COMMENT_ID.COMMENT_ID);
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COMMENT_ID");}
return oComment;
}
public Report_coach Get_Report_coach_By_REPORT_COACH_ID(Params_Get_Report_coach_By_REPORT_COACH_ID i_Params_Get_Report_coach_By_REPORT_COACH_ID)
{
Report_coach oReport_coach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_REPORT_COACH_ID");}
#region Body Section.
DALC.Report_coach oDBEntry = _AppContext.Get_Report_coach_By_REPORT_COACH_ID(i_Params_Get_Report_coach_By_REPORT_COACH_ID.REPORT_COACH_ID);
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_REPORT_COACH_ID");}
return oReport_coach;
}
public Comment_report Get_Comment_report_By_COMMENT_REPORT_ID(Params_Get_Comment_report_By_COMMENT_REPORT_ID i_Params_Get_Comment_report_By_COMMENT_REPORT_ID)
{
Comment_report oComment_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID");}
#region Body Section.
DALC.Comment_report oDBEntry = _AppContext.Get_Comment_report_By_COMMENT_REPORT_ID(i_Params_Get_Comment_report_By_COMMENT_REPORT_ID.COMMENT_REPORT_ID);
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID");}
return oComment_report;
}
public User Get_User_By_USER_ID(Params_Get_User_By_USER_ID i_Params_Get_User_By_USER_ID)
{
User oUser = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID");}
#region Body Section.
DALC.User oDBEntry = _AppContext.Get_User_By_USER_ID(i_Params_Get_User_By_USER_ID.USER_ID);
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID");}
return oUser;
}
public Direct_message Get_Direct_message_By_DIRECT_MESSAGE_ID(Params_Get_Direct_message_By_DIRECT_MESSAGE_ID i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID)
{
Direct_message oDirect_message = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID");}
#region Body Section.
DALC.Direct_message oDBEntry = _AppContext.Get_Direct_message_By_DIRECT_MESSAGE_ID(i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID.DIRECT_MESSAGE_ID);
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID");}
return oDirect_message;
}
public Report_player Get_Report_player_By_REPORT_PLAYER_ID(Params_Get_Report_player_By_REPORT_PLAYER_ID i_Params_Get_Report_player_By_REPORT_PLAYER_ID)
{
Report_player oReport_player = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_REPORT_PLAYER_ID");}
#region Body Section.
DALC.Report_player oDBEntry = _AppContext.Get_Report_player_By_REPORT_PLAYER_ID(i_Params_Get_Report_player_By_REPORT_PLAYER_ID.REPORT_PLAYER_ID);
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_REPORT_PLAYER_ID");}
return oReport_player;
}
public Coach Get_Coach_By_COACH_ID(Params_Get_Coach_By_COACH_ID i_Params_Get_Coach_By_COACH_ID)
{
Coach oCoach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_COACH_ID");}
#region Body Section.
DALC.Coach oDBEntry = _AppContext.Get_Coach_By_COACH_ID(i_Params_Get_Coach_By_COACH_ID.COACH_ID);
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_COACH_ID");}
return oCoach;
}
public Player Get_Player_By_PLAYER_ID(Params_Get_Player_By_PLAYER_ID i_Params_Get_Player_By_PLAYER_ID)
{
Player oPlayer = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_PLAYER_ID");}
#region Body Section.
DALC.Player oDBEntry = _AppContext.Get_Player_By_PLAYER_ID(i_Params_Get_Player_By_PLAYER_ID.PLAYER_ID);
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_PLAYER_ID");}
return oPlayer;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List(Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List)
{
Coach_leaderboards oCoach_leaderboards = null;
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_SP oParams_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_SP = new Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List(i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List.COACH_LEADERBOARDS_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List(Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List)
{
Player_leaderboards oPlayer_leaderboards = null;
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_SP oParams_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_SP = new Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List(i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List.PLAYER_LEADERBOARDS_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List");}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYERSPORT_ID_List(Params_Get_Playersport_By_PLAYERSPORT_ID_List i_Params_Get_Playersport_By_PLAYERSPORT_ID_List)
{
Playersport oPlayersport = null;
List<Playersport> oList = new List<Playersport>();
Params_Get_Playersport_By_PLAYERSPORT_ID_List_SP oParams_Get_Playersport_By_PLAYERSPORT_ID_List_SP = new Params_Get_Playersport_By_PLAYERSPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYERSPORT_ID_List");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_PLAYERSPORT_ID_List(i_Params_Get_Playersport_By_PLAYERSPORT_ID_List.PLAYERSPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYERSPORT_ID_List");}
return oList;
}
public List<Sport> Get_Sport_By_SPORT_ID_List(Params_Get_Sport_By_SPORT_ID_List i_Params_Get_Sport_By_SPORT_ID_List)
{
Sport oSport = null;
List<Sport> oList = new List<Sport>();
Params_Get_Sport_By_SPORT_ID_List_SP oParams_Get_Sport_By_SPORT_ID_List_SP = new Params_Get_Sport_By_SPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_SPORT_ID_List");}
#region Body Section.
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_SPORT_ID_List(i_Params_Get_Sport_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_SPORT_ID_List");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACHSPORT_ID_List(Params_Get_Coachsport_By_COACHSPORT_ID_List i_Params_Get_Coachsport_By_COACHSPORT_ID_List)
{
Coachsport oCoachsport = null;
List<Coachsport> oList = new List<Coachsport>();
Params_Get_Coachsport_By_COACHSPORT_ID_List_SP oParams_Get_Coachsport_By_COACHSPORT_ID_List_SP = new Params_Get_Coachsport_By_COACHSPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACHSPORT_ID_List");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_COACHSPORT_ID_List(i_Params_Get_Coachsport_By_COACHSPORT_ID_List.COACHSPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACHSPORT_ID_List");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_EVALUATION_ID_List(Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List)
{
Coach_evaluation oCoach_evaluation = null;
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_SP oParams_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_SP = new Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID_List");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_COACH_EVALUATION_ID_List(i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List.COACH_EVALUATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID_List");}
return oList;
}
public List<Currency> Get_Currency_By_CURRENCY_ID_List(Params_Get_Currency_By_CURRENCY_ID_List i_Params_Get_Currency_By_CURRENCY_ID_List)
{
Currency oCurrency = null;
List<Currency> oList = new List<Currency>();
Params_Get_Currency_By_CURRENCY_ID_List_SP oParams_Get_Currency_By_CURRENCY_ID_List_SP = new Params_Get_Currency_By_CURRENCY_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_CURRENCY_ID_List");}
#region Body Section.
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_CURRENCY_ID_List(i_Params_Get_Currency_By_CURRENCY_ID_List.CURRENCY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_CURRENCY_ID_List");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_SESSION_EVALUATION_ID_List(Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List)
{
Session_evaluation oSession_evaluation = null;
List<Session_evaluation> oList = new List<Session_evaluation>();
Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_SP oParams_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_SP = new Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID_List");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_SESSION_EVALUATION_ID_List(i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List.SESSION_EVALUATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID_List");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_TAKEN_SESSION_ID_List(Params_Get_Taken_session_By_TAKEN_SESSION_ID_List i_Params_Get_Taken_session_By_TAKEN_SESSION_ID_List)
{
Taken_session oTaken_session = null;
List<Taken_session> oList = new List<Taken_session>();
Params_Get_Taken_session_By_TAKEN_SESSION_ID_List_SP oParams_Get_Taken_session_By_TAKEN_SESSION_ID_List_SP = new Params_Get_Taken_session_By_TAKEN_SESSION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID_List");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_TAKEN_SESSION_ID_List(i_Params_Get_Taken_session_By_TAKEN_SESSION_ID_List.TAKEN_SESSION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID_List");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List(Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List)
{
Scheduled_session oScheduled_session = null;
List<Scheduled_session> oList = new List<Scheduled_session>();
Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_SP oParams_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_SP = new Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List(i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List.SCHEDULED_SESSION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List");}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List(Params_Get_Notification_By_NOTIFICATION_ID_List i_Params_Get_Notification_By_NOTIFICATION_ID_List)
{
Notification oNotification = null;
List<Notification> oList = new List<Notification>();
Params_Get_Notification_By_NOTIFICATION_ID_List_SP oParams_Get_Notification_By_NOTIFICATION_ID_List_SP = new Params_Get_Notification_By_NOTIFICATION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID_List");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_NOTIFICATION_ID_List(i_Params_Get_Notification_By_NOTIFICATION_ID_List.NOTIFICATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID_List");}
return oList;
}
public List<Owner> Get_Owner_By_OWNER_ID_List(Params_Get_Owner_By_OWNER_ID_List i_Params_Get_Owner_By_OWNER_ID_List)
{
Owner oOwner = null;
List<Owner> oList = new List<Owner>();
Params_Get_Owner_By_OWNER_ID_List_SP oParams_Get_Owner_By_OWNER_ID_List_SP = new Params_Get_Owner_By_OWNER_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_OWNER_ID_List");}
#region Body Section.
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_OWNER_ID_List(i_Params_Get_Owner_By_OWNER_ID_List.OWNER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_OWNER_ID_List");}
return oList;
}
public List<Comment> Get_Comment_By_COMMENT_ID_List(Params_Get_Comment_By_COMMENT_ID_List i_Params_Get_Comment_By_COMMENT_ID_List)
{
Comment oComment = null;
List<Comment> oList = new List<Comment>();
Params_Get_Comment_By_COMMENT_ID_List_SP oParams_Get_Comment_By_COMMENT_ID_List_SP = new Params_Get_Comment_By_COMMENT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COMMENT_ID_List");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_COMMENT_ID_List(i_Params_Get_Comment_By_COMMENT_ID_List.COMMENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COMMENT_ID_List");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_REPORT_COACH_ID_List(Params_Get_Report_coach_By_REPORT_COACH_ID_List i_Params_Get_Report_coach_By_REPORT_COACH_ID_List)
{
Report_coach oReport_coach = null;
List<Report_coach> oList = new List<Report_coach>();
Params_Get_Report_coach_By_REPORT_COACH_ID_List_SP oParams_Get_Report_coach_By_REPORT_COACH_ID_List_SP = new Params_Get_Report_coach_By_REPORT_COACH_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_REPORT_COACH_ID_List");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_REPORT_COACH_ID_List(i_Params_Get_Report_coach_By_REPORT_COACH_ID_List.REPORT_COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_REPORT_COACH_ID_List");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_REPORT_ID_List(Params_Get_Comment_report_By_COMMENT_REPORT_ID_List i_Params_Get_Comment_report_By_COMMENT_REPORT_ID_List)
{
Comment_report oComment_report = null;
List<Comment_report> oList = new List<Comment_report>();
Params_Get_Comment_report_By_COMMENT_REPORT_ID_List_SP oParams_Get_Comment_report_By_COMMENT_REPORT_ID_List_SP = new Params_Get_Comment_report_By_COMMENT_REPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID_List");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COMMENT_REPORT_ID_List(i_Params_Get_Comment_report_By_COMMENT_REPORT_ID_List.COMMENT_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID_List");}
return oList;
}
public List<User> Get_User_By_USER_ID_List(Params_Get_User_By_USER_ID_List i_Params_Get_User_By_USER_ID_List)
{
User oUser = null;
List<User> oList = new List<User>();
Params_Get_User_By_USER_ID_List_SP oParams_Get_User_By_USER_ID_List_SP = new Params_Get_User_By_USER_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID_List");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USER_ID_List(i_Params_Get_User_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID_List");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_DIRECT_MESSAGE_ID_List(Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List)
{
Direct_message oDirect_message = null;
List<Direct_message> oList = new List<Direct_message>();
Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List_SP oParams_Get_Direct_message_By_DIRECT_MESSAGE_ID_List_SP = new Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID_List");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_DIRECT_MESSAGE_ID_List(i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List.DIRECT_MESSAGE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID_List");}
return oList;
}
public List<Report_player> Get_Report_player_By_REPORT_PLAYER_ID_List(Params_Get_Report_player_By_REPORT_PLAYER_ID_List i_Params_Get_Report_player_By_REPORT_PLAYER_ID_List)
{
Report_player oReport_player = null;
List<Report_player> oList = new List<Report_player>();
Params_Get_Report_player_By_REPORT_PLAYER_ID_List_SP oParams_Get_Report_player_By_REPORT_PLAYER_ID_List_SP = new Params_Get_Report_player_By_REPORT_PLAYER_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_REPORT_PLAYER_ID_List");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_REPORT_PLAYER_ID_List(i_Params_Get_Report_player_By_REPORT_PLAYER_ID_List.REPORT_PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_REPORT_PLAYER_ID_List");}
return oList;
}
public List<Coach> Get_Coach_By_COACH_ID_List(Params_Get_Coach_By_COACH_ID_List i_Params_Get_Coach_By_COACH_ID_List)
{
Coach oCoach = null;
List<Coach> oList = new List<Coach>();
Params_Get_Coach_By_COACH_ID_List_SP oParams_Get_Coach_By_COACH_ID_List_SP = new Params_Get_Coach_By_COACH_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_COACH_ID_List");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_COACH_ID_List(i_Params_Get_Coach_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_COACH_ID_List");}
return oList;
}
public List<Player> Get_Player_By_PLAYER_ID_List(Params_Get_Player_By_PLAYER_ID_List i_Params_Get_Player_By_PLAYER_ID_List)
{
Player oPlayer = null;
List<Player> oList = new List<Player>();
Params_Get_Player_By_PLAYER_ID_List_SP oParams_Get_Player_By_PLAYER_ID_List_SP = new Params_Get_Player_By_PLAYER_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_PLAYER_ID_List(i_Params_Get_Player_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_PLAYER_ID_List");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_OWNER_ID(Params_Get_Coach_leaderboards_By_OWNER_ID i_Params_Get_Coach_leaderboards_By_OWNER_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_OWNER_ID");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_OWNER_ID(i_Params_Get_Coach_leaderboards_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_OWNER_ID");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID(Params_Get_Coach_leaderboards_By_COACH_ID i_Params_Get_Coach_leaderboards_By_COACH_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_ID");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_COACH_ID(i_Params_Get_Coach_leaderboards_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_ID");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_OWNER_ID(Params_Get_Player_leaderboards_By_OWNER_ID i_Params_Get_Player_leaderboards_By_OWNER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_OWNER_ID");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_OWNER_ID(i_Params_Get_Player_leaderboards_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_OWNER_ID");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID(Params_Get_Player_leaderboards_By_PLAYER_ID i_Params_Get_Player_leaderboards_By_PLAYER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_ID");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_PLAYER_ID(i_Params_Get_Player_leaderboards_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_ID");}
return oList;
}
public List<Playersport> Get_Playersport_By_OWNER_ID(Params_Get_Playersport_By_OWNER_ID i_Params_Get_Playersport_By_OWNER_ID)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_OWNER_ID");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_OWNER_ID(i_Params_Get_Playersport_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_OWNER_ID");}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID(Params_Get_Playersport_By_PLAYER_ID i_Params_Get_Playersport_By_PLAYER_ID)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYER_ID");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_PLAYER_ID(i_Params_Get_Playersport_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYER_ID");}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID(Params_Get_Playersport_By_SPORT_ID i_Params_Get_Playersport_By_SPORT_ID)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_SPORT_ID");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_SPORT_ID(i_Params_Get_Playersport_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_SPORT_ID");}
return oList;
}
public List<Sport> Get_Sport_By_OWNER_ID(Params_Get_Sport_By_OWNER_ID i_Params_Get_Sport_By_OWNER_ID)
{
List<Sport> oList = new List<Sport>();
Sport oSport = new Sport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_OWNER_ID");}
#region Body Section.
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_OWNER_ID(i_Params_Get_Sport_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_OWNER_ID");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_OWNER_ID(Params_Get_Coachsport_By_OWNER_ID i_Params_Get_Coachsport_By_OWNER_ID)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_OWNER_ID");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_OWNER_ID(i_Params_Get_Coachsport_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_OWNER_ID");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID(Params_Get_Coachsport_By_SPORT_ID i_Params_Get_Coachsport_By_SPORT_ID)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_SPORT_ID");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_SPORT_ID(i_Params_Get_Coachsport_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_SPORT_ID");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID(Params_Get_Coachsport_By_COACH_ID i_Params_Get_Coachsport_By_COACH_ID)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACH_ID");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_COACH_ID(i_Params_Get_Coachsport_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACH_ID");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_OWNER_ID(Params_Get_Coach_evaluation_By_OWNER_ID i_Params_Get_Coach_evaluation_By_OWNER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_OWNER_ID");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_OWNER_ID(i_Params_Get_Coach_evaluation_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_OWNER_ID");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID(Params_Get_Coach_evaluation_By_PLAYER_ID i_Params_Get_Coach_evaluation_By_PLAYER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_PLAYER_ID");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_PLAYER_ID(i_Params_Get_Coach_evaluation_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_PLAYER_ID");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID(Params_Get_Coach_evaluation_By_COACH_ID i_Params_Get_Coach_evaluation_By_COACH_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_ID");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_COACH_ID(i_Params_Get_Coach_evaluation_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_ID");}
return oList;
}
public List<Currency> Get_Currency_By_OWNER_ID(Params_Get_Currency_By_OWNER_ID i_Params_Get_Currency_By_OWNER_ID)
{
List<Currency> oList = new List<Currency>();
Currency oCurrency = new Currency();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_OWNER_ID");}
#region Body Section.
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_OWNER_ID(i_Params_Get_Currency_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_OWNER_ID");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_OWNER_ID(Params_Get_Session_evaluation_By_OWNER_ID i_Params_Get_Session_evaluation_By_OWNER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_OWNER_ID");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_OWNER_ID(i_Params_Get_Session_evaluation_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_OWNER_ID");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID(Params_Get_Session_evaluation_By_COACH_ID i_Params_Get_Session_evaluation_By_COACH_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_COACH_ID");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_COACH_ID(i_Params_Get_Session_evaluation_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_COACH_ID");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID(Params_Get_Session_evaluation_By_PLAYER_ID i_Params_Get_Session_evaluation_By_PLAYER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_PLAYER_ID");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_PLAYER_ID(i_Params_Get_Session_evaluation_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_PLAYER_ID");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_OWNER_ID(Params_Get_Taken_session_By_OWNER_ID i_Params_Get_Taken_session_By_OWNER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_OWNER_ID");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_OWNER_ID(i_Params_Get_Taken_session_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_OWNER_ID");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID(Params_Get_Taken_session_By_COACH_ID i_Params_Get_Taken_session_By_COACH_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_COACH_ID");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_COACH_ID(i_Params_Get_Taken_session_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_COACH_ID");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID(Params_Get_Taken_session_By_PLAYER_ID i_Params_Get_Taken_session_By_PLAYER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_PLAYER_ID");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_PLAYER_ID(i_Params_Get_Taken_session_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_PLAYER_ID");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID(Params_Get_Taken_session_By_SPORT_ID i_Params_Get_Taken_session_By_SPORT_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_SPORT_ID");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_SPORT_ID(i_Params_Get_Taken_session_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_SPORT_ID");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_OWNER_ID(Params_Get_Scheduled_session_By_OWNER_ID i_Params_Get_Scheduled_session_By_OWNER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_OWNER_ID");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_OWNER_ID(i_Params_Get_Scheduled_session_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_OWNER_ID");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID(Params_Get_Scheduled_session_By_PLAYER_ID i_Params_Get_Scheduled_session_By_PLAYER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_PLAYER_ID");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_PLAYER_ID(i_Params_Get_Scheduled_session_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_PLAYER_ID");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID(Params_Get_Scheduled_session_By_COACH_ID i_Params_Get_Scheduled_session_By_COACH_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_COACH_ID");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_COACH_ID(i_Params_Get_Scheduled_session_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_COACH_ID");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID(Params_Get_Scheduled_session_By_SPORT_ID i_Params_Get_Scheduled_session_By_SPORT_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SPORT_ID");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_SPORT_ID(i_Params_Get_Scheduled_session_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SPORT_ID");}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID(Params_Get_Notification_By_OWNER_ID i_Params_Get_Notification_By_OWNER_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_OWNER_ID");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_OWNER_ID(i_Params_Get_Notification_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_OWNER_ID");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID(Params_Get_Notification_By_USER_ID i_Params_Get_Notification_By_USER_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID(i_Params_Get_Notification_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID");}
return oList;
}
public List<Comment> Get_Comment_By_OWNER_ID(Params_Get_Comment_By_OWNER_ID i_Params_Get_Comment_By_OWNER_ID)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_OWNER_ID");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_OWNER_ID(i_Params_Get_Comment_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_OWNER_ID");}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID(Params_Get_Comment_By_PLAYER_ID i_Params_Get_Comment_By_PLAYER_ID)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_PLAYER_ID");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_PLAYER_ID(i_Params_Get_Comment_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_PLAYER_ID");}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID(Params_Get_Comment_By_COACH_ID i_Params_Get_Comment_By_COACH_ID)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COACH_ID");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_COACH_ID(i_Params_Get_Comment_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COACH_ID");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_OWNER_ID(Params_Get_Report_coach_By_OWNER_ID i_Params_Get_Report_coach_By_OWNER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_OWNER_ID");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_OWNER_ID(i_Params_Get_Report_coach_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_OWNER_ID");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID(Params_Get_Report_coach_By_USER_ID i_Params_Get_Report_coach_By_USER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_USER_ID");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_USER_ID(i_Params_Get_Report_coach_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_USER_ID");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID(Params_Get_Report_coach_By_COACH_ID i_Params_Get_Report_coach_By_COACH_ID)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_COACH_ID");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_COACH_ID(i_Params_Get_Report_coach_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_COACH_ID");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_OWNER_ID(Params_Get_Comment_report_By_OWNER_ID i_Params_Get_Comment_report_By_OWNER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_OWNER_ID");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_OWNER_ID(i_Params_Get_Comment_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_OWNER_ID");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID(Params_Get_Comment_report_By_PLAYER_ID i_Params_Get_Comment_report_By_PLAYER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_PLAYER_ID");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_PLAYER_ID(i_Params_Get_Comment_report_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_PLAYER_ID");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID(Params_Get_Comment_report_By_COACH_ID i_Params_Get_Comment_report_By_COACH_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COACH_ID");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COACH_ID(i_Params_Get_Comment_report_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COACH_ID");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID(Params_Get_Comment_report_By_COMMENT_ID i_Params_Get_Comment_report_By_COMMENT_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_ID");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COMMENT_ID(i_Params_Get_Comment_report_By_COMMENT_ID.COMMENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_ID");}
return oList;
}
public List<User> Get_User_By_OWNER_ID(Params_Get_User_By_OWNER_ID i_Params_Get_User_By_OWNER_ID)
{
List<User> oList = new List<User>();
User oUser = new User();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_OWNER_ID");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_OWNER_ID(i_Params_Get_User_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_OWNER_ID");}
return oList;
}
public List<User> Get_User_By_USERNAME(Params_Get_User_By_USERNAME i_Params_Get_User_By_USERNAME)
{
List<User> oList = new List<User>();
User oUser = new User();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USERNAME");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USERNAME(i_Params_Get_User_By_USERNAME.USERNAME);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USERNAME");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_OWNER_ID(Params_Get_Direct_message_By_OWNER_ID i_Params_Get_Direct_message_By_OWNER_ID)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_OWNER_ID");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_OWNER_ID(i_Params_Get_Direct_message_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_OWNER_ID");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID(Params_Get_Direct_message_By_AUTHOR_ID i_Params_Get_Direct_message_By_AUTHOR_ID)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_AUTHOR_ID");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_AUTHOR_ID(i_Params_Get_Direct_message_By_AUTHOR_ID.AUTHOR_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_AUTHOR_ID");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID(Params_Get_Direct_message_By_RECIPIENT_ID i_Params_Get_Direct_message_By_RECIPIENT_ID)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_RECIPIENT_ID");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_RECIPIENT_ID(i_Params_Get_Direct_message_By_RECIPIENT_ID.RECIPIENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_RECIPIENT_ID");}
return oList;
}
public List<Report_player> Get_Report_player_By_OWNER_ID(Params_Get_Report_player_By_OWNER_ID i_Params_Get_Report_player_By_OWNER_ID)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_OWNER_ID");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_OWNER_ID(i_Params_Get_Report_player_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_OWNER_ID");}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID(Params_Get_Report_player_By_USER_ID i_Params_Get_Report_player_By_USER_ID)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_USER_ID");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_USER_ID(i_Params_Get_Report_player_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_USER_ID");}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID(Params_Get_Report_player_By_PLAYER_ID i_Params_Get_Report_player_By_PLAYER_ID)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_PLAYER_ID");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_PLAYER_ID(i_Params_Get_Report_player_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_PLAYER_ID");}
return oList;
}
public List<Coach> Get_Coach_By_OWNER_ID(Params_Get_Coach_By_OWNER_ID i_Params_Get_Coach_By_OWNER_ID)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_OWNER_ID");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_OWNER_ID(i_Params_Get_Coach_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_OWNER_ID");}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID(Params_Get_Coach_By_USER_ID i_Params_Get_Coach_By_USER_ID)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_USER_ID");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_USER_ID(i_Params_Get_Coach_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_USER_ID");}
return oList;
}
public List<Player> Get_Player_By_OWNER_ID(Params_Get_Player_By_OWNER_ID i_Params_Get_Player_By_OWNER_ID)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_OWNER_ID");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_OWNER_ID(i_Params_Get_Player_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_OWNER_ID");}
return oList;
}
public List<Player> Get_Player_By_USER_ID(Params_Get_Player_By_USER_ID i_Params_Get_Player_By_USER_ID)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_USER_ID");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_USER_ID(i_Params_Get_Player_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_USER_ID");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_List(Params_Get_Coach_leaderboards_By_COACH_ID_List i_Params_Get_Coach_leaderboards_By_COACH_ID_List)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_ID_List");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_COACH_ID_List(i_Params_Get_Coach_leaderboards_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_ID_List");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_List(Params_Get_Player_leaderboards_By_PLAYER_ID_List i_Params_Get_Player_leaderboards_By_PLAYER_ID_List)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_PLAYER_ID_List(i_Params_Get_Player_leaderboards_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_ID_List");}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID_List(Params_Get_Playersport_By_PLAYER_ID_List i_Params_Get_Playersport_By_PLAYER_ID_List)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_PLAYER_ID_List(i_Params_Get_Playersport_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYER_ID_List");}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID_List(Params_Get_Playersport_By_SPORT_ID_List i_Params_Get_Playersport_By_SPORT_ID_List)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_SPORT_ID_List");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_SPORT_ID_List(i_Params_Get_Playersport_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_SPORT_ID_List");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID_List(Params_Get_Coachsport_By_SPORT_ID_List i_Params_Get_Coachsport_By_SPORT_ID_List)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_SPORT_ID_List");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_SPORT_ID_List(i_Params_Get_Coachsport_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_SPORT_ID_List");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID_List(Params_Get_Coachsport_By_COACH_ID_List i_Params_Get_Coachsport_By_COACH_ID_List)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACH_ID_List");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_COACH_ID_List(i_Params_Get_Coachsport_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACH_ID_List");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_List(Params_Get_Coach_evaluation_By_PLAYER_ID_List i_Params_Get_Coach_evaluation_By_PLAYER_ID_List)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_PLAYER_ID_List(i_Params_Get_Coach_evaluation_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_PLAYER_ID_List");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_List(Params_Get_Coach_evaluation_By_COACH_ID_List i_Params_Get_Coach_evaluation_By_COACH_ID_List)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_ID_List");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_COACH_ID_List(i_Params_Get_Coach_evaluation_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_ID_List");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_List(Params_Get_Session_evaluation_By_COACH_ID_List i_Params_Get_Session_evaluation_By_COACH_ID_List)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_COACH_ID_List");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_COACH_ID_List(i_Params_Get_Session_evaluation_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_COACH_ID_List");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_List(Params_Get_Session_evaluation_By_PLAYER_ID_List i_Params_Get_Session_evaluation_By_PLAYER_ID_List)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_PLAYER_ID_List(i_Params_Get_Session_evaluation_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_PLAYER_ID_List");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID_List(Params_Get_Taken_session_By_COACH_ID_List i_Params_Get_Taken_session_By_COACH_ID_List)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_COACH_ID_List");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_COACH_ID_List(i_Params_Get_Taken_session_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_COACH_ID_List");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID_List(Params_Get_Taken_session_By_PLAYER_ID_List i_Params_Get_Taken_session_By_PLAYER_ID_List)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_PLAYER_ID_List(i_Params_Get_Taken_session_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_PLAYER_ID_List");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID_List(Params_Get_Taken_session_By_SPORT_ID_List i_Params_Get_Taken_session_By_SPORT_ID_List)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_SPORT_ID_List");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_SPORT_ID_List(i_Params_Get_Taken_session_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_SPORT_ID_List");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_List(Params_Get_Scheduled_session_By_PLAYER_ID_List i_Params_Get_Scheduled_session_By_PLAYER_ID_List)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_PLAYER_ID_List(i_Params_Get_Scheduled_session_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_PLAYER_ID_List");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_List(Params_Get_Scheduled_session_By_COACH_ID_List i_Params_Get_Scheduled_session_By_COACH_ID_List)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_COACH_ID_List");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_COACH_ID_List(i_Params_Get_Scheduled_session_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_COACH_ID_List");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_List(Params_Get_Scheduled_session_By_SPORT_ID_List i_Params_Get_Scheduled_session_By_SPORT_ID_List)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SPORT_ID_List");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_SPORT_ID_List(i_Params_Get_Scheduled_session_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SPORT_ID_List");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List(Params_Get_Notification_By_USER_ID_List i_Params_Get_Notification_By_USER_ID_List)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID_List");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID_List(i_Params_Get_Notification_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID_List");}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID_List(Params_Get_Comment_By_PLAYER_ID_List i_Params_Get_Comment_By_PLAYER_ID_List)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_PLAYER_ID_List(i_Params_Get_Comment_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_PLAYER_ID_List");}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID_List(Params_Get_Comment_By_COACH_ID_List i_Params_Get_Comment_By_COACH_ID_List)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COACH_ID_List");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_COACH_ID_List(i_Params_Get_Comment_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COACH_ID_List");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID_List(Params_Get_Report_coach_By_USER_ID_List i_Params_Get_Report_coach_By_USER_ID_List)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_USER_ID_List");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_USER_ID_List(i_Params_Get_Report_coach_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_USER_ID_List");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID_List(Params_Get_Report_coach_By_COACH_ID_List i_Params_Get_Report_coach_By_COACH_ID_List)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_COACH_ID_List");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_COACH_ID_List(i_Params_Get_Report_coach_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_COACH_ID_List");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID_List(Params_Get_Comment_report_By_PLAYER_ID_List i_Params_Get_Comment_report_By_PLAYER_ID_List)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_PLAYER_ID_List(i_Params_Get_Comment_report_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_PLAYER_ID_List");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID_List(Params_Get_Comment_report_By_COACH_ID_List i_Params_Get_Comment_report_By_COACH_ID_List)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COACH_ID_List");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COACH_ID_List(i_Params_Get_Comment_report_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COACH_ID_List");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID_List(Params_Get_Comment_report_By_COMMENT_ID_List i_Params_Get_Comment_report_By_COMMENT_ID_List)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_ID_List");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COMMENT_ID_List(i_Params_Get_Comment_report_By_COMMENT_ID_List.COMMENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_ID_List");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID_List(Params_Get_Direct_message_By_AUTHOR_ID_List i_Params_Get_Direct_message_By_AUTHOR_ID_List)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_AUTHOR_ID_List");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_AUTHOR_ID_List(i_Params_Get_Direct_message_By_AUTHOR_ID_List.AUTHOR_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_AUTHOR_ID_List");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_List(Params_Get_Direct_message_By_RECIPIENT_ID_List i_Params_Get_Direct_message_By_RECIPIENT_ID_List)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_RECIPIENT_ID_List");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_RECIPIENT_ID_List(i_Params_Get_Direct_message_By_RECIPIENT_ID_List.RECIPIENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_RECIPIENT_ID_List");}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID_List(Params_Get_Report_player_By_USER_ID_List i_Params_Get_Report_player_By_USER_ID_List)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_USER_ID_List");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_USER_ID_List(i_Params_Get_Report_player_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_USER_ID_List");}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID_List(Params_Get_Report_player_By_PLAYER_ID_List i_Params_Get_Report_player_By_PLAYER_ID_List)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_PLAYER_ID_List");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_PLAYER_ID_List(i_Params_Get_Report_player_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_PLAYER_ID_List");}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID_List(Params_Get_Coach_By_USER_ID_List i_Params_Get_Coach_By_USER_ID_List)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_USER_ID_List");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_USER_ID_List(i_Params_Get_Coach_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_USER_ID_List");}
return oList;
}
public List<Player> Get_Player_By_USER_ID_List(Params_Get_Player_By_USER_ID_List i_Params_Get_Player_By_USER_ID_List)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_USER_ID_List");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_USER_ID_List(i_Params_Get_Player_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_USER_ID_List");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria(Params_Get_Coach_leaderboards_By_Criteria i_Params_Get_Coach_leaderboards_By_Criteria)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Criteria.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW = 1000000; }
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Criteria(i_Params_Get_Coach_leaderboards_By_Criteria.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Criteria.START_ROW,i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Criteria");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where(Params_Get_Coach_leaderboards_By_Where i_Params_Get_Coach_leaderboards_By_Where)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Where");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Where.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Where.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Where.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Where.END_ROW = 1000000; }
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Where(i_Params_Get_Coach_leaderboards_By_Where.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Where.START_ROW,i_Params_Get_Coach_leaderboards_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Where");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria(Params_Get_Player_leaderboards_By_Criteria i_Params_Get_Player_leaderboards_By_Criteria)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Criteria.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Criteria.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Criteria.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Criteria.END_ROW = 1000000; }
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Criteria(i_Params_Get_Player_leaderboards_By_Criteria.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID,i_Params_Get_Player_leaderboards_By_Criteria.START_ROW,i_Params_Get_Player_leaderboards_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Criteria");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where(Params_Get_Player_leaderboards_By_Where i_Params_Get_Player_leaderboards_By_Where)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Where");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Where.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Where.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Where.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Where.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Where.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Where.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Where.END_ROW = 1000000; }
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Where(i_Params_Get_Player_leaderboards_By_Where.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Where.OWNER_ID,i_Params_Get_Player_leaderboards_By_Where.START_ROW,i_Params_Get_Player_leaderboards_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Where");}
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria(Params_Get_Playersport_By_Criteria i_Params_Get_Playersport_By_Criteria)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Criteria.OWNER_ID == null) || (i_Params_Get_Playersport_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Criteria.START_ROW == null) { i_Params_Get_Playersport_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Criteria.END_ROW == null) || (i_Params_Get_Playersport_By_Criteria.END_ROW == 0)) { i_Params_Get_Playersport_By_Criteria.END_ROW = 1000000; }
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Criteria(i_Params_Get_Playersport_By_Criteria.DESCRIPTION,i_Params_Get_Playersport_By_Criteria.OWNER_ID,i_Params_Get_Playersport_By_Criteria.START_ROW,i_Params_Get_Playersport_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Criteria");}
return oList;
}
public List<Playersport> Get_Playersport_By_Where(Params_Get_Playersport_By_Where i_Params_Get_Playersport_By_Where)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Where");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Where.OWNER_ID == null) || (i_Params_Get_Playersport_By_Where.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Where.START_ROW == null) { i_Params_Get_Playersport_By_Where.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Where.END_ROW == null) || (i_Params_Get_Playersport_By_Where.END_ROW == 0)) { i_Params_Get_Playersport_By_Where.END_ROW = 1000000; }
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Where(i_Params_Get_Playersport_By_Where.DESCRIPTION,i_Params_Get_Playersport_By_Where.OWNER_ID,i_Params_Get_Playersport_By_Where.START_ROW,i_Params_Get_Playersport_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Where");}
return oList;
}
public List<Sport> Get_Sport_By_Criteria(Params_Get_Sport_By_Criteria i_Params_Get_Sport_By_Criteria)
{
List<Sport> oList = new List<Sport>();
Sport oSport = new Sport();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Sport_By_Criteria.OWNER_ID == null) || (i_Params_Get_Sport_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Sport_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Sport_By_Criteria.START_ROW == null) { i_Params_Get_Sport_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Sport_By_Criteria.END_ROW == null) || (i_Params_Get_Sport_By_Criteria.END_ROW == 0)) { i_Params_Get_Sport_By_Criteria.END_ROW = 1000000; }
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_Criteria(i_Params_Get_Sport_By_Criteria.SPORT_NAME,i_Params_Get_Sport_By_Criteria.DESCRIPTION,i_Params_Get_Sport_By_Criteria.OWNER_ID,i_Params_Get_Sport_By_Criteria.START_ROW,i_Params_Get_Sport_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
i_Params_Get_Sport_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_Criteria");}
return oList;
}
public List<Sport> Get_Sport_By_Where(Params_Get_Sport_By_Where i_Params_Get_Sport_By_Where)
{
List<Sport> oList = new List<Sport>();
Sport oSport = new Sport();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_Where");}
#region Body Section.
if ((i_Params_Get_Sport_By_Where.OWNER_ID == null) || (i_Params_Get_Sport_By_Where.OWNER_ID == 0)) { i_Params_Get_Sport_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Sport_By_Where.START_ROW == null) { i_Params_Get_Sport_By_Where.START_ROW = 0; }
if ((i_Params_Get_Sport_By_Where.END_ROW == null) || (i_Params_Get_Sport_By_Where.END_ROW == 0)) { i_Params_Get_Sport_By_Where.END_ROW = 1000000; }
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_Where(i_Params_Get_Sport_By_Where.SPORT_NAME,i_Params_Get_Sport_By_Where.DESCRIPTION,i_Params_Get_Sport_By_Where.OWNER_ID,i_Params_Get_Sport_By_Where.START_ROW,i_Params_Get_Sport_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
i_Params_Get_Sport_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_Where");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria(Params_Get_Coachsport_By_Criteria i_Params_Get_Coachsport_By_Criteria)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Criteria.START_ROW == null) { i_Params_Get_Coachsport_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Criteria.END_ROW == null) || (i_Params_Get_Coachsport_By_Criteria.END_ROW == 0)) { i_Params_Get_Coachsport_By_Criteria.END_ROW = 1000000; }
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Criteria(i_Params_Get_Coachsport_By_Criteria.DESCRIPTION,i_Params_Get_Coachsport_By_Criteria.OWNER_ID,i_Params_Get_Coachsport_By_Criteria.START_ROW,i_Params_Get_Coachsport_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Criteria");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where(Params_Get_Coachsport_By_Where i_Params_Get_Coachsport_By_Where)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Where");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Where.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Where.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Where.START_ROW == null) { i_Params_Get_Coachsport_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Where.END_ROW == null) || (i_Params_Get_Coachsport_By_Where.END_ROW == 0)) { i_Params_Get_Coachsport_By_Where.END_ROW = 1000000; }
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Where(i_Params_Get_Coachsport_By_Where.DESCRIPTION,i_Params_Get_Coachsport_By_Where.OWNER_ID,i_Params_Get_Coachsport_By_Where.START_ROW,i_Params_Get_Coachsport_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Where");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria(Params_Get_Coach_evaluation_By_Criteria i_Params_Get_Coach_evaluation_By_Criteria)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Criteria.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Criteria.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Criteria.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Criteria.END_ROW = 1000000; }
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Criteria(i_Params_Get_Coach_evaluation_By_Criteria.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID,i_Params_Get_Coach_evaluation_By_Criteria.START_ROW,i_Params_Get_Coach_evaluation_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Criteria");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where(Params_Get_Coach_evaluation_By_Where i_Params_Get_Coach_evaluation_By_Where)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Where");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Where.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Where.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Where.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Where.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Where.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Where.END_ROW = 1000000; }
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Where(i_Params_Get_Coach_evaluation_By_Where.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Where.OWNER_ID,i_Params_Get_Coach_evaluation_By_Where.START_ROW,i_Params_Get_Coach_evaluation_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Where");}
return oList;
}
public List<Currency> Get_Currency_By_Criteria(Params_Get_Currency_By_Criteria i_Params_Get_Currency_By_Criteria)
{
List<Currency> oList = new List<Currency>();
Currency oCurrency = new Currency();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Currency_By_Criteria.OWNER_ID == null) || (i_Params_Get_Currency_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Currency_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Currency_By_Criteria.START_ROW == null) { i_Params_Get_Currency_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Currency_By_Criteria.END_ROW == null) || (i_Params_Get_Currency_By_Criteria.END_ROW == 0)) { i_Params_Get_Currency_By_Criteria.END_ROW = 1000000; }
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_Criteria(i_Params_Get_Currency_By_Criteria.CURRENCY_NAME,i_Params_Get_Currency_By_Criteria.OWNER_ID,i_Params_Get_Currency_By_Criteria.START_ROW,i_Params_Get_Currency_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
i_Params_Get_Currency_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_Criteria");}
return oList;
}
public List<Currency> Get_Currency_By_Where(Params_Get_Currency_By_Where i_Params_Get_Currency_By_Where)
{
List<Currency> oList = new List<Currency>();
Currency oCurrency = new Currency();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_Where");}
#region Body Section.
if ((i_Params_Get_Currency_By_Where.OWNER_ID == null) || (i_Params_Get_Currency_By_Where.OWNER_ID == 0)) { i_Params_Get_Currency_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Currency_By_Where.START_ROW == null) { i_Params_Get_Currency_By_Where.START_ROW = 0; }
if ((i_Params_Get_Currency_By_Where.END_ROW == null) || (i_Params_Get_Currency_By_Where.END_ROW == 0)) { i_Params_Get_Currency_By_Where.END_ROW = 1000000; }
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_Where(i_Params_Get_Currency_By_Where.CURRENCY_NAME,i_Params_Get_Currency_By_Where.OWNER_ID,i_Params_Get_Currency_By_Where.START_ROW,i_Params_Get_Currency_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
i_Params_Get_Currency_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_Where");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria(Params_Get_Session_evaluation_By_Criteria i_Params_Get_Session_evaluation_By_Criteria)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Criteria.START_ROW == null) { i_Params_Get_Session_evaluation_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Criteria.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Criteria.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Criteria.END_ROW = 1000000; }
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Criteria(i_Params_Get_Session_evaluation_By_Criteria.DESCRIPTION,i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID,i_Params_Get_Session_evaluation_By_Criteria.START_ROW,i_Params_Get_Session_evaluation_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Criteria");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where(Params_Get_Session_evaluation_By_Where i_Params_Get_Session_evaluation_By_Where)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Where");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Where.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Where.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Where.START_ROW == null) { i_Params_Get_Session_evaluation_By_Where.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Where.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Where.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Where.END_ROW = 1000000; }
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Where(i_Params_Get_Session_evaluation_By_Where.DESCRIPTION,i_Params_Get_Session_evaluation_By_Where.OWNER_ID,i_Params_Get_Session_evaluation_By_Where.START_ROW,i_Params_Get_Session_evaluation_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Where");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria(Params_Get_Taken_session_By_Criteria i_Params_Get_Taken_session_By_Criteria)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Criteria.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Criteria.START_ROW == null) { i_Params_Get_Taken_session_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Criteria.END_ROW == null) || (i_Params_Get_Taken_session_By_Criteria.END_ROW == 0)) { i_Params_Get_Taken_session_By_Criteria.END_ROW = 1000000; }
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Criteria(i_Params_Get_Taken_session_By_Criteria.DATETIME,i_Params_Get_Taken_session_By_Criteria.OWNER_ID,i_Params_Get_Taken_session_By_Criteria.START_ROW,i_Params_Get_Taken_session_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Criteria");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where(Params_Get_Taken_session_By_Where i_Params_Get_Taken_session_By_Where)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Where");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Where.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Where.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Where.START_ROW == null) { i_Params_Get_Taken_session_By_Where.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Where.END_ROW == null) || (i_Params_Get_Taken_session_By_Where.END_ROW == 0)) { i_Params_Get_Taken_session_By_Where.END_ROW = 1000000; }
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Where(i_Params_Get_Taken_session_By_Where.DATETIME,i_Params_Get_Taken_session_By_Where.OWNER_ID,i_Params_Get_Taken_session_By_Where.START_ROW,i_Params_Get_Taken_session_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Where");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria(Params_Get_Scheduled_session_By_Criteria i_Params_Get_Scheduled_session_By_Criteria)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Criteria.START_ROW == null) { i_Params_Get_Scheduled_session_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Criteria.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Criteria.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Criteria.END_ROW = 1000000; }
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Criteria(i_Params_Get_Scheduled_session_By_Criteria.DATE_TIME,i_Params_Get_Scheduled_session_By_Criteria.DESCRIPTION,i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID,i_Params_Get_Scheduled_session_By_Criteria.START_ROW,i_Params_Get_Scheduled_session_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Criteria");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where(Params_Get_Scheduled_session_By_Where i_Params_Get_Scheduled_session_By_Where)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Where");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Where.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Where.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Where.START_ROW == null) { i_Params_Get_Scheduled_session_By_Where.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Where.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Where.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Where.END_ROW = 1000000; }
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Where(i_Params_Get_Scheduled_session_By_Where.DATE_TIME,i_Params_Get_Scheduled_session_By_Where.DESCRIPTION,i_Params_Get_Scheduled_session_By_Where.OWNER_ID,i_Params_Get_Scheduled_session_By_Where.START_ROW,i_Params_Get_Scheduled_session_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Where");}
return oList;
}
public List<Notification> Get_Notification_By_Criteria(Params_Get_Notification_By_Criteria i_Params_Get_Notification_By_Criteria)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Notification_By_Criteria.OWNER_ID == null) || (i_Params_Get_Notification_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Notification_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Criteria.START_ROW == null) { i_Params_Get_Notification_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Criteria.END_ROW == null) || (i_Params_Get_Notification_By_Criteria.END_ROW == 0)) { i_Params_Get_Notification_By_Criteria.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Criteria(i_Params_Get_Notification_By_Criteria.TITLE,i_Params_Get_Notification_By_Criteria.DESCRIPTION,i_Params_Get_Notification_By_Criteria.OWNER_ID,i_Params_Get_Notification_By_Criteria.START_ROW,i_Params_Get_Notification_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Criteria");}
return oList;
}
public List<Notification> Get_Notification_By_Where(Params_Get_Notification_By_Where i_Params_Get_Notification_By_Where)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Where");}
#region Body Section.
if ((i_Params_Get_Notification_By_Where.OWNER_ID == null) || (i_Params_Get_Notification_By_Where.OWNER_ID == 0)) { i_Params_Get_Notification_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Where.START_ROW == null) { i_Params_Get_Notification_By_Where.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Where.END_ROW == null) || (i_Params_Get_Notification_By_Where.END_ROW == 0)) { i_Params_Get_Notification_By_Where.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Where(i_Params_Get_Notification_By_Where.TITLE,i_Params_Get_Notification_By_Where.DESCRIPTION,i_Params_Get_Notification_By_Where.OWNER_ID,i_Params_Get_Notification_By_Where.START_ROW,i_Params_Get_Notification_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Where");}
return oList;
}
public List<Owner> Get_Owner_By_Criteria(Params_Get_Owner_By_Criteria i_Params_Get_Owner_By_Criteria)
{
List<Owner> oList = new List<Owner>();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Owner_By_Criteria.OWNER_ID == null) || (i_Params_Get_Owner_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Owner_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Criteria.START_ROW == null) { i_Params_Get_Owner_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Criteria.END_ROW == null) || (i_Params_Get_Owner_By_Criteria.END_ROW == 0)) { i_Params_Get_Owner_By_Criteria.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Criteria(i_Params_Get_Owner_By_Criteria.CODE,i_Params_Get_Owner_By_Criteria.DESCRIPTION,i_Params_Get_Owner_By_Criteria.OWNER_ID,i_Params_Get_Owner_By_Criteria.START_ROW,i_Params_Get_Owner_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Criteria");}
return oList;
}
public List<Owner> Get_Owner_By_Where(Params_Get_Owner_By_Where i_Params_Get_Owner_By_Where)
{
List<Owner> oList = new List<Owner>();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Where");}
#region Body Section.
if ((i_Params_Get_Owner_By_Where.OWNER_ID == null) || (i_Params_Get_Owner_By_Where.OWNER_ID == 0)) { i_Params_Get_Owner_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Where.START_ROW == null) { i_Params_Get_Owner_By_Where.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Where.END_ROW == null) || (i_Params_Get_Owner_By_Where.END_ROW == 0)) { i_Params_Get_Owner_By_Where.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Where(i_Params_Get_Owner_By_Where.CODE,i_Params_Get_Owner_By_Where.DESCRIPTION,i_Params_Get_Owner_By_Where.OWNER_ID,i_Params_Get_Owner_By_Where.START_ROW,i_Params_Get_Owner_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Where");}
return oList;
}
public List<Owner> Get_Owner_By_Criteria_V2(Params_Get_Owner_By_Criteria_V2 i_Params_Get_Owner_By_Criteria_V2)
{
List<Owner> oList = new List<Owner>();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Criteria_V2");}
#region Body Section.
if ((i_Params_Get_Owner_By_Criteria_V2.OWNER_ID == null) || (i_Params_Get_Owner_By_Criteria_V2.OWNER_ID == 0)) { i_Params_Get_Owner_By_Criteria_V2.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Criteria_V2.START_ROW == null) { i_Params_Get_Owner_By_Criteria_V2.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Criteria_V2.END_ROW == null) || (i_Params_Get_Owner_By_Criteria_V2.END_ROW == 0)) { i_Params_Get_Owner_By_Criteria_V2.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Criteria_V2(i_Params_Get_Owner_By_Criteria_V2.CODE,i_Params_Get_Owner_By_Criteria_V2.MAINTENANCE_DUE_DATE,i_Params_Get_Owner_By_Criteria_V2.DESCRIPTION,i_Params_Get_Owner_By_Criteria_V2.OWNER_ID,i_Params_Get_Owner_By_Criteria_V2.START_ROW,i_Params_Get_Owner_By_Criteria_V2.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Criteria_V2.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Criteria_V2");}
return oList;
}
public List<Owner> Get_Owner_By_Where_V2(Params_Get_Owner_By_Where_V2 i_Params_Get_Owner_By_Where_V2)
{
List<Owner> oList = new List<Owner>();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Where_V2");}
#region Body Section.
if ((i_Params_Get_Owner_By_Where_V2.OWNER_ID == null) || (i_Params_Get_Owner_By_Where_V2.OWNER_ID == 0)) { i_Params_Get_Owner_By_Where_V2.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Where_V2.START_ROW == null) { i_Params_Get_Owner_By_Where_V2.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Where_V2.END_ROW == null) || (i_Params_Get_Owner_By_Where_V2.END_ROW == 0)) { i_Params_Get_Owner_By_Where_V2.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Where_V2(i_Params_Get_Owner_By_Where_V2.CODE,i_Params_Get_Owner_By_Where_V2.MAINTENANCE_DUE_DATE,i_Params_Get_Owner_By_Where_V2.DESCRIPTION,i_Params_Get_Owner_By_Where_V2.OWNER_ID,i_Params_Get_Owner_By_Where_V2.START_ROW,i_Params_Get_Owner_By_Where_V2.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Where_V2.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Where_V2");}
return oList;
}
public List<Comment> Get_Comment_By_Criteria(Params_Get_Comment_By_Criteria i_Params_Get_Comment_By_Criteria)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Comment_By_Criteria.OWNER_ID == null) || (i_Params_Get_Comment_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Comment_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Criteria.START_ROW == null) { i_Params_Get_Comment_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Criteria.END_ROW == null) || (i_Params_Get_Comment_By_Criteria.END_ROW == 0)) { i_Params_Get_Comment_By_Criteria.END_ROW = 1000000; }
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Criteria(i_Params_Get_Comment_By_Criteria.TITLE,i_Params_Get_Comment_By_Criteria.DESCRIPTION,i_Params_Get_Comment_By_Criteria.OWNER_ID,i_Params_Get_Comment_By_Criteria.START_ROW,i_Params_Get_Comment_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Criteria");}
return oList;
}
public List<Comment> Get_Comment_By_Where(Params_Get_Comment_By_Where i_Params_Get_Comment_By_Where)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Where");}
#region Body Section.
if ((i_Params_Get_Comment_By_Where.OWNER_ID == null) || (i_Params_Get_Comment_By_Where.OWNER_ID == 0)) { i_Params_Get_Comment_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Where.START_ROW == null) { i_Params_Get_Comment_By_Where.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Where.END_ROW == null) || (i_Params_Get_Comment_By_Where.END_ROW == 0)) { i_Params_Get_Comment_By_Where.END_ROW = 1000000; }
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Where(i_Params_Get_Comment_By_Where.TITLE,i_Params_Get_Comment_By_Where.DESCRIPTION,i_Params_Get_Comment_By_Where.OWNER_ID,i_Params_Get_Comment_By_Where.START_ROW,i_Params_Get_Comment_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Where");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria(Params_Get_Report_coach_By_Criteria i_Params_Get_Report_coach_By_Criteria)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Criteria.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Criteria.START_ROW == null) { i_Params_Get_Report_coach_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Criteria.END_ROW == null) || (i_Params_Get_Report_coach_By_Criteria.END_ROW == 0)) { i_Params_Get_Report_coach_By_Criteria.END_ROW = 1000000; }
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Criteria(i_Params_Get_Report_coach_By_Criteria.DESCRIPTION,i_Params_Get_Report_coach_By_Criteria.OWNER_ID,i_Params_Get_Report_coach_By_Criteria.START_ROW,i_Params_Get_Report_coach_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Criteria");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where(Params_Get_Report_coach_By_Where i_Params_Get_Report_coach_By_Where)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Where");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Where.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Where.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Where.START_ROW == null) { i_Params_Get_Report_coach_By_Where.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Where.END_ROW == null) || (i_Params_Get_Report_coach_By_Where.END_ROW == 0)) { i_Params_Get_Report_coach_By_Where.END_ROW = 1000000; }
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Where(i_Params_Get_Report_coach_By_Where.DESCRIPTION,i_Params_Get_Report_coach_By_Where.OWNER_ID,i_Params_Get_Report_coach_By_Where.START_ROW,i_Params_Get_Report_coach_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Where");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria(Params_Get_Comment_report_By_Criteria i_Params_Get_Comment_report_By_Criteria)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Criteria.START_ROW == null) { i_Params_Get_Comment_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Criteria.END_ROW == null) || (i_Params_Get_Comment_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Comment_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Criteria(i_Params_Get_Comment_report_By_Criteria.DESCRIPTION,i_Params_Get_Comment_report_By_Criteria.OWNER_ID,i_Params_Get_Comment_report_By_Criteria.START_ROW,i_Params_Get_Comment_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Criteria");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where(Params_Get_Comment_report_By_Where i_Params_Get_Comment_report_By_Where)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Where");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Where.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Where.START_ROW == null) { i_Params_Get_Comment_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Where.END_ROW == null) || (i_Params_Get_Comment_report_By_Where.END_ROW == 0)) { i_Params_Get_Comment_report_By_Where.END_ROW = 1000000; }
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Where(i_Params_Get_Comment_report_By_Where.DESCRIPTION,i_Params_Get_Comment_report_By_Where.OWNER_ID,i_Params_Get_Comment_report_By_Where.START_ROW,i_Params_Get_Comment_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Where");}
return oList;
}
public List<User> Get_User_By_Criteria(Params_Get_User_By_Criteria i_Params_Get_User_By_Criteria)
{
List<User> oList = new List<User>();
User oUser = new User();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Criteria");}
#region Body Section.
if ((i_Params_Get_User_By_Criteria.OWNER_ID == null) || (i_Params_Get_User_By_Criteria.OWNER_ID == 0)) { i_Params_Get_User_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Criteria.START_ROW == null) { i_Params_Get_User_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_User_By_Criteria.END_ROW == null) || (i_Params_Get_User_By_Criteria.END_ROW == 0)) { i_Params_Get_User_By_Criteria.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Criteria(i_Params_Get_User_By_Criteria.USERNAME,i_Params_Get_User_By_Criteria.PASSWORD,i_Params_Get_User_By_Criteria.USER_TYPE_CODE,i_Params_Get_User_By_Criteria.OWNER_ID,i_Params_Get_User_By_Criteria.START_ROW,i_Params_Get_User_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
i_Params_Get_User_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Criteria");}
return oList;
}
public List<User> Get_User_By_Where(Params_Get_User_By_Where i_Params_Get_User_By_Where)
{
List<User> oList = new List<User>();
User oUser = new User();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Where");}
#region Body Section.
if ((i_Params_Get_User_By_Where.OWNER_ID == null) || (i_Params_Get_User_By_Where.OWNER_ID == 0)) { i_Params_Get_User_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Where.START_ROW == null) { i_Params_Get_User_By_Where.START_ROW = 0; }
if ((i_Params_Get_User_By_Where.END_ROW == null) || (i_Params_Get_User_By_Where.END_ROW == 0)) { i_Params_Get_User_By_Where.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Where(i_Params_Get_User_By_Where.USERNAME,i_Params_Get_User_By_Where.PASSWORD,i_Params_Get_User_By_Where.USER_TYPE_CODE,i_Params_Get_User_By_Where.OWNER_ID,i_Params_Get_User_By_Where.START_ROW,i_Params_Get_User_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
i_Params_Get_User_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Where");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_Criteria(Params_Get_Direct_message_By_Criteria i_Params_Get_Direct_message_By_Criteria)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Direct_message_By_Criteria.OWNER_ID == null) || (i_Params_Get_Direct_message_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Direct_message_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Direct_message_By_Criteria.START_ROW == null) { i_Params_Get_Direct_message_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Direct_message_By_Criteria.END_ROW == null) || (i_Params_Get_Direct_message_By_Criteria.END_ROW == 0)) { i_Params_Get_Direct_message_By_Criteria.END_ROW = 1000000; }
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_Criteria(i_Params_Get_Direct_message_By_Criteria.DESCRIPTION,i_Params_Get_Direct_message_By_Criteria.DATETIME,i_Params_Get_Direct_message_By_Criteria.OWNER_ID,i_Params_Get_Direct_message_By_Criteria.START_ROW,i_Params_Get_Direct_message_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
i_Params_Get_Direct_message_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_Criteria");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_Where(Params_Get_Direct_message_By_Where i_Params_Get_Direct_message_By_Where)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_Where");}
#region Body Section.
if ((i_Params_Get_Direct_message_By_Where.OWNER_ID == null) || (i_Params_Get_Direct_message_By_Where.OWNER_ID == 0)) { i_Params_Get_Direct_message_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Direct_message_By_Where.START_ROW == null) { i_Params_Get_Direct_message_By_Where.START_ROW = 0; }
if ((i_Params_Get_Direct_message_By_Where.END_ROW == null) || (i_Params_Get_Direct_message_By_Where.END_ROW == 0)) { i_Params_Get_Direct_message_By_Where.END_ROW = 1000000; }
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_Where(i_Params_Get_Direct_message_By_Where.DESCRIPTION,i_Params_Get_Direct_message_By_Where.DATETIME,i_Params_Get_Direct_message_By_Where.OWNER_ID,i_Params_Get_Direct_message_By_Where.START_ROW,i_Params_Get_Direct_message_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oList.Add(oDirect_message);
}
}
i_Params_Get_Direct_message_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_Where");}
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria(Params_Get_Report_player_By_Criteria i_Params_Get_Report_player_By_Criteria)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Criteria.OWNER_ID == null) || (i_Params_Get_Report_player_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Criteria.START_ROW == null) { i_Params_Get_Report_player_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Criteria.END_ROW == null) || (i_Params_Get_Report_player_By_Criteria.END_ROW == 0)) { i_Params_Get_Report_player_By_Criteria.END_ROW = 1000000; }
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Criteria(i_Params_Get_Report_player_By_Criteria.DESCRIPTION,i_Params_Get_Report_player_By_Criteria.OWNER_ID,i_Params_Get_Report_player_By_Criteria.START_ROW,i_Params_Get_Report_player_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Criteria");}
return oList;
}
public List<Report_player> Get_Report_player_By_Where(Params_Get_Report_player_By_Where i_Params_Get_Report_player_By_Where)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Where");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Where.OWNER_ID == null) || (i_Params_Get_Report_player_By_Where.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Where.START_ROW == null) { i_Params_Get_Report_player_By_Where.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Where.END_ROW == null) || (i_Params_Get_Report_player_By_Where.END_ROW == 0)) { i_Params_Get_Report_player_By_Where.END_ROW = 1000000; }
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Where(i_Params_Get_Report_player_By_Where.DESCRIPTION,i_Params_Get_Report_player_By_Where.OWNER_ID,i_Params_Get_Report_player_By_Where.START_ROW,i_Params_Get_Report_player_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Where");}
return oList;
}
public List<Coach> Get_Coach_By_Criteria(Params_Get_Coach_By_Criteria i_Params_Get_Coach_By_Criteria)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Coach_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coach_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coach_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_By_Criteria.START_ROW == null) { i_Params_Get_Coach_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coach_By_Criteria.END_ROW == null) || (i_Params_Get_Coach_By_Criteria.END_ROW == 0)) { i_Params_Get_Coach_By_Criteria.END_ROW = 1000000; }
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_Criteria(i_Params_Get_Coach_By_Criteria.FIRSTNAME,i_Params_Get_Coach_By_Criteria.LASTNAME,i_Params_Get_Coach_By_Criteria.EMAIL,i_Params_Get_Coach_By_Criteria.MOBILE,i_Params_Get_Coach_By_Criteria.GEO_LOCATION,i_Params_Get_Coach_By_Criteria.OWNER_ID,i_Params_Get_Coach_By_Criteria.START_ROW,i_Params_Get_Coach_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oList.Add(oCoach);
}
}
i_Params_Get_Coach_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_Criteria");}
return oList;
}
public List<Coach> Get_Coach_By_Where(Params_Get_Coach_By_Where i_Params_Get_Coach_By_Where)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_Where");}
#region Body Section.
if ((i_Params_Get_Coach_By_Where.OWNER_ID == null) || (i_Params_Get_Coach_By_Where.OWNER_ID == 0)) { i_Params_Get_Coach_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_By_Where.START_ROW == null) { i_Params_Get_Coach_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coach_By_Where.END_ROW == null) || (i_Params_Get_Coach_By_Where.END_ROW == 0)) { i_Params_Get_Coach_By_Where.END_ROW = 1000000; }
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_Where(i_Params_Get_Coach_By_Where.FIRSTNAME,i_Params_Get_Coach_By_Where.LASTNAME,i_Params_Get_Coach_By_Where.EMAIL,i_Params_Get_Coach_By_Where.MOBILE,i_Params_Get_Coach_By_Where.GEO_LOCATION,i_Params_Get_Coach_By_Where.OWNER_ID,i_Params_Get_Coach_By_Where.START_ROW,i_Params_Get_Coach_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oList.Add(oCoach);
}
}
i_Params_Get_Coach_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_Where");}
return oList;
}
public List<Player> Get_Player_By_Criteria(Params_Get_Player_By_Criteria i_Params_Get_Player_By_Criteria)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Player_By_Criteria.OWNER_ID == null) || (i_Params_Get_Player_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Player_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_By_Criteria.START_ROW == null) { i_Params_Get_Player_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Player_By_Criteria.END_ROW == null) || (i_Params_Get_Player_By_Criteria.END_ROW == 0)) { i_Params_Get_Player_By_Criteria.END_ROW = 1000000; }
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_Criteria(i_Params_Get_Player_By_Criteria.FIRSTNAME,i_Params_Get_Player_By_Criteria.LASTNAME,i_Params_Get_Player_By_Criteria.EMAIL,i_Params_Get_Player_By_Criteria.MOBILE,i_Params_Get_Player_By_Criteria.GEO_LOCATION,i_Params_Get_Player_By_Criteria.OWNER_ID,i_Params_Get_Player_By_Criteria.START_ROW,i_Params_Get_Player_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oList.Add(oPlayer);
}
}
i_Params_Get_Player_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_Criteria");}
return oList;
}
public List<Player> Get_Player_By_Where(Params_Get_Player_By_Where i_Params_Get_Player_By_Where)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_Where");}
#region Body Section.
if ((i_Params_Get_Player_By_Where.OWNER_ID == null) || (i_Params_Get_Player_By_Where.OWNER_ID == 0)) { i_Params_Get_Player_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_By_Where.START_ROW == null) { i_Params_Get_Player_By_Where.START_ROW = 0; }
if ((i_Params_Get_Player_By_Where.END_ROW == null) || (i_Params_Get_Player_By_Where.END_ROW == 0)) { i_Params_Get_Player_By_Where.END_ROW = 1000000; }
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_Where(i_Params_Get_Player_By_Where.FIRSTNAME,i_Params_Get_Player_By_Where.LASTNAME,i_Params_Get_Player_By_Where.EMAIL,i_Params_Get_Player_By_Where.MOBILE,i_Params_Get_Player_By_Where.GEO_LOCATION,i_Params_Get_Player_By_Where.OWNER_ID,i_Params_Get_Player_By_Where.START_ROW,i_Params_Get_Player_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oList.Add(oPlayer);
}
}
i_Params_Get_Player_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_Where");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_InList(Params_Get_Coach_leaderboards_By_Criteria_InList i_Params_Get_Coach_leaderboards_By_Criteria_InList)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Coach_leaderboards_By_Criteria_InList_SP oParams_Get_Coach_leaderboards_By_Criteria_InList_SP = new Params_Get_Coach_leaderboards_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID;
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Coach_leaderboards_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.START_ROW = i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW;
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.END_ROW = i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW;
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_leaderboards_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Criteria_InList(i_Params_Get_Coach_leaderboards_By_Criteria_InList.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW,i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_leaderboards_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Criteria_InList");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_InList(Params_Get_Coach_leaderboards_By_Where_InList i_Params_Get_Coach_leaderboards_By_Where_InList)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Coach_leaderboards_By_Where_InList_SP oParams_Get_Coach_leaderboards_By_Where_InList_SP = new Params_Get_Coach_leaderboards_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Coach_leaderboards_By_Where_InList_SP.OWNER_ID = i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID;
oParams_Get_Coach_leaderboards_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Coach_leaderboards_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_leaderboards_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST);
oParams_Get_Coach_leaderboards_By_Where_InList_SP.START_ROW = i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW;
oParams_Get_Coach_leaderboards_By_Where_InList_SP.END_ROW = i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW;
oParams_Get_Coach_leaderboards_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_leaderboards_By_Where_InList.TOTAL_COUNT;
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Where_InList(i_Params_Get_Coach_leaderboards_By_Where_InList.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST,i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW,i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Where_InList.TOTAL_COUNT = oParams_Get_Coach_leaderboards_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_leaderboards_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Where_InList");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_InList(Params_Get_Player_leaderboards_By_Criteria_InList i_Params_Get_Player_leaderboards_By_Criteria_InList)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Player_leaderboards_By_Criteria_InList_SP oParams_Get_Player_leaderboards_By_Criteria_InList_SP = new Params_Get_Player_leaderboards_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID;
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Player_leaderboards_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST);
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.START_ROW = i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW;
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.END_ROW = i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW;
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Player_leaderboards_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Criteria_InList(i_Params_Get_Player_leaderboards_By_Criteria_InList.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID,i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW,i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Player_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Player_leaderboards_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Criteria_InList");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where_InList(Params_Get_Player_leaderboards_By_Where_InList i_Params_Get_Player_leaderboards_By_Where_InList)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Player_leaderboards_By_Where_InList_SP oParams_Get_Player_leaderboards_By_Where_InList_SP = new Params_Get_Player_leaderboards_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Player_leaderboards_By_Where_InList_SP.OWNER_ID = i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID;
oParams_Get_Player_leaderboards_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Player_leaderboards_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Player_leaderboards_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST);
oParams_Get_Player_leaderboards_By_Where_InList_SP.START_ROW = i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW;
oParams_Get_Player_leaderboards_By_Where_InList_SP.END_ROW = i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW;
oParams_Get_Player_leaderboards_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Player_leaderboards_By_Where_InList.TOTAL_COUNT;
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Where_InList(i_Params_Get_Player_leaderboards_By_Where_InList.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID,i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW,i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Where_InList.TOTAL_COUNT = oParams_Get_Player_leaderboards_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Player_leaderboards_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Where_InList");}
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria_InList(Params_Get_Playersport_By_Criteria_InList i_Params_Get_Playersport_By_Criteria_InList)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Playersport_By_Criteria_InList_SP oParams_Get_Playersport_By_Criteria_InList_SP = new Params_Get_Playersport_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Criteria_InList.START_ROW == null) { i_Params_Get_Playersport_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Playersport_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Playersport_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Playersport_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID;
oParams_Get_Playersport_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Playersport_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST);
oParams_Get_Playersport_By_Criteria_InList_SP.START_ROW = i_Params_Get_Playersport_By_Criteria_InList.START_ROW;
oParams_Get_Playersport_By_Criteria_InList_SP.END_ROW = i_Params_Get_Playersport_By_Criteria_InList.END_ROW;
oParams_Get_Playersport_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Playersport_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Criteria_InList(i_Params_Get_Playersport_By_Criteria_InList.DESCRIPTION,i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID,i_Params_Get_Playersport_By_Criteria_InList.START_ROW,i_Params_Get_Playersport_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Playersport_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Playersport_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Criteria_InList");}
return oList;
}
public List<Playersport> Get_Playersport_By_Where_InList(Params_Get_Playersport_By_Where_InList i_Params_Get_Playersport_By_Where_InList)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Playersport_By_Where_InList_SP oParams_Get_Playersport_By_Where_InList_SP = new Params_Get_Playersport_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Playersport_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Where_InList.START_ROW == null) { i_Params_Get_Playersport_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Where_InList.END_ROW == null) || (i_Params_Get_Playersport_By_Where_InList.END_ROW == 0)) { i_Params_Get_Playersport_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Playersport_By_Where_InList_SP.OWNER_ID = i_Params_Get_Playersport_By_Where_InList.OWNER_ID;
oParams_Get_Playersport_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Playersport_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST);
oParams_Get_Playersport_By_Where_InList_SP.START_ROW = i_Params_Get_Playersport_By_Where_InList.START_ROW;
oParams_Get_Playersport_By_Where_InList_SP.END_ROW = i_Params_Get_Playersport_By_Where_InList.END_ROW;
oParams_Get_Playersport_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Playersport_By_Where_InList.TOTAL_COUNT;
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Where_InList(i_Params_Get_Playersport_By_Where_InList.DESCRIPTION,i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Playersport_By_Where_InList.OWNER_ID,i_Params_Get_Playersport_By_Where_InList.START_ROW,i_Params_Get_Playersport_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Where_InList.TOTAL_COUNT = oParams_Get_Playersport_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Playersport_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Where_InList");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria_InList(Params_Get_Coachsport_By_Criteria_InList i_Params_Get_Coachsport_By_Criteria_InList)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Coachsport_By_Criteria_InList_SP oParams_Get_Coachsport_By_Criteria_InList_SP = new Params_Get_Coachsport_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Criteria_InList.START_ROW == null) { i_Params_Get_Coachsport_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Coachsport_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Coachsport_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Coachsport_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID;
oParams_Get_Coachsport_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Coachsport_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST);
if ( i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Coachsport_By_Criteria_InList_SP.START_ROW = i_Params_Get_Coachsport_By_Criteria_InList.START_ROW;
oParams_Get_Coachsport_By_Criteria_InList_SP.END_ROW = i_Params_Get_Coachsport_By_Criteria_InList.END_ROW;
oParams_Get_Coachsport_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Coachsport_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Criteria_InList(i_Params_Get_Coachsport_By_Criteria_InList.DESCRIPTION,i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID,i_Params_Get_Coachsport_By_Criteria_InList.START_ROW,i_Params_Get_Coachsport_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Coachsport_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Coachsport_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Criteria_InList");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where_InList(Params_Get_Coachsport_By_Where_InList i_Params_Get_Coachsport_By_Where_InList)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Coachsport_By_Where_InList_SP oParams_Get_Coachsport_By_Where_InList_SP = new Params_Get_Coachsport_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Where_InList.START_ROW == null) { i_Params_Get_Coachsport_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Where_InList.END_ROW == null) || (i_Params_Get_Coachsport_By_Where_InList.END_ROW == 0)) { i_Params_Get_Coachsport_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Coachsport_By_Where_InList_SP.OWNER_ID = i_Params_Get_Coachsport_By_Where_InList.OWNER_ID;
oParams_Get_Coachsport_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Coachsport_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST);
if ( i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST);
oParams_Get_Coachsport_By_Where_InList_SP.START_ROW = i_Params_Get_Coachsport_By_Where_InList.START_ROW;
oParams_Get_Coachsport_By_Where_InList_SP.END_ROW = i_Params_Get_Coachsport_By_Where_InList.END_ROW;
oParams_Get_Coachsport_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Coachsport_By_Where_InList.TOTAL_COUNT;
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Where_InList(i_Params_Get_Coachsport_By_Where_InList.DESCRIPTION,i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST,i_Params_Get_Coachsport_By_Where_InList.OWNER_ID,i_Params_Get_Coachsport_By_Where_InList.START_ROW,i_Params_Get_Coachsport_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Where_InList.TOTAL_COUNT = oParams_Get_Coachsport_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Coachsport_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Where_InList");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_InList(Params_Get_Coach_evaluation_By_Criteria_InList i_Params_Get_Coach_evaluation_By_Criteria_InList)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Coach_evaluation_By_Criteria_InList_SP oParams_Get_Coach_evaluation_By_Criteria_InList_SP = new Params_Get_Coach_evaluation_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID;
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Coach_evaluation_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.START_ROW = i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW;
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.END_ROW = i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW;
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_evaluation_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Criteria_InList(i_Params_Get_Coach_evaluation_By_Criteria_InList.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID,i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW,i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Coach_evaluation_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_evaluation_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Criteria_InList");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where_InList(Params_Get_Coach_evaluation_By_Where_InList i_Params_Get_Coach_evaluation_By_Where_InList)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Coach_evaluation_By_Where_InList_SP oParams_Get_Coach_evaluation_By_Where_InList_SP = new Params_Get_Coach_evaluation_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Coach_evaluation_By_Where_InList_SP.OWNER_ID = i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID;
oParams_Get_Coach_evaluation_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Coach_evaluation_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST);
oParams_Get_Coach_evaluation_By_Where_InList_SP.START_ROW = i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW;
oParams_Get_Coach_evaluation_By_Where_InList_SP.END_ROW = i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW;
oParams_Get_Coach_evaluation_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_evaluation_By_Where_InList.TOTAL_COUNT;
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Where_InList(i_Params_Get_Coach_evaluation_By_Where_InList.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST,i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID,i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW,i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Where_InList.TOTAL_COUNT = oParams_Get_Coach_evaluation_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_evaluation_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Where_InList");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria_InList(Params_Get_Session_evaluation_By_Criteria_InList i_Params_Get_Session_evaluation_By_Criteria_InList)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Session_evaluation_By_Criteria_InList_SP oParams_Get_Session_evaluation_By_Criteria_InList_SP = new Params_Get_Session_evaluation_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW == null) { i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Session_evaluation_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID;
oParams_Get_Session_evaluation_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Session_evaluation_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST);
oParams_Get_Session_evaluation_By_Criteria_InList_SP.START_ROW = i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW;
oParams_Get_Session_evaluation_By_Criteria_InList_SP.END_ROW = i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW;
oParams_Get_Session_evaluation_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Session_evaluation_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Criteria_InList(i_Params_Get_Session_evaluation_By_Criteria_InList.DESCRIPTION,i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID,i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW,i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Session_evaluation_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Session_evaluation_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Criteria_InList");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where_InList(Params_Get_Session_evaluation_By_Where_InList i_Params_Get_Session_evaluation_By_Where_InList)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Session_evaluation_By_Where_InList_SP oParams_Get_Session_evaluation_By_Where_InList_SP = new Params_Get_Session_evaluation_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Where_InList.START_ROW == null) { i_Params_Get_Session_evaluation_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Where_InList.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Where_InList.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Session_evaluation_By_Where_InList_SP.OWNER_ID = i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID;
oParams_Get_Session_evaluation_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Session_evaluation_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST);
oParams_Get_Session_evaluation_By_Where_InList_SP.START_ROW = i_Params_Get_Session_evaluation_By_Where_InList.START_ROW;
oParams_Get_Session_evaluation_By_Where_InList_SP.END_ROW = i_Params_Get_Session_evaluation_By_Where_InList.END_ROW;
oParams_Get_Session_evaluation_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Session_evaluation_By_Where_InList.TOTAL_COUNT;
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Where_InList(i_Params_Get_Session_evaluation_By_Where_InList.DESCRIPTION,i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST,i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID,i_Params_Get_Session_evaluation_By_Where_InList.START_ROW,i_Params_Get_Session_evaluation_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Where_InList.TOTAL_COUNT = oParams_Get_Session_evaluation_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Session_evaluation_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Where_InList");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria_InList(Params_Get_Taken_session_By_Criteria_InList i_Params_Get_Taken_session_By_Criteria_InList)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Taken_session_By_Criteria_InList_SP oParams_Get_Taken_session_By_Criteria_InList_SP = new Params_Get_Taken_session_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Criteria_InList.START_ROW == null) { i_Params_Get_Taken_session_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Taken_session_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Taken_session_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Taken_session_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID;
oParams_Get_Taken_session_By_Criteria_InList_SP.DATETIME = i_Params_Get_Taken_session_By_Criteria_InList.DATETIME;
if ( i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST);
oParams_Get_Taken_session_By_Criteria_InList_SP.START_ROW = i_Params_Get_Taken_session_By_Criteria_InList.START_ROW;
oParams_Get_Taken_session_By_Criteria_InList_SP.END_ROW = i_Params_Get_Taken_session_By_Criteria_InList.END_ROW;
oParams_Get_Taken_session_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Taken_session_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Criteria_InList(i_Params_Get_Taken_session_By_Criteria_InList.DATETIME,i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID,i_Params_Get_Taken_session_By_Criteria_InList.START_ROW,i_Params_Get_Taken_session_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Taken_session_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Taken_session_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Criteria_InList");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where_InList(Params_Get_Taken_session_By_Where_InList i_Params_Get_Taken_session_By_Where_InList)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Taken_session_By_Where_InList_SP oParams_Get_Taken_session_By_Where_InList_SP = new Params_Get_Taken_session_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Where_InList.START_ROW == null) { i_Params_Get_Taken_session_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Where_InList.END_ROW == null) || (i_Params_Get_Taken_session_By_Where_InList.END_ROW == 0)) { i_Params_Get_Taken_session_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Taken_session_By_Where_InList_SP.OWNER_ID = i_Params_Get_Taken_session_By_Where_InList.OWNER_ID;
oParams_Get_Taken_session_By_Where_InList_SP.DATETIME = i_Params_Get_Taken_session_By_Where_InList.DATETIME;
if ( i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST);
oParams_Get_Taken_session_By_Where_InList_SP.START_ROW = i_Params_Get_Taken_session_By_Where_InList.START_ROW;
oParams_Get_Taken_session_By_Where_InList_SP.END_ROW = i_Params_Get_Taken_session_By_Where_InList.END_ROW;
oParams_Get_Taken_session_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Taken_session_By_Where_InList.TOTAL_COUNT;
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Where_InList(i_Params_Get_Taken_session_By_Where_InList.DATETIME,i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST,i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Taken_session_By_Where_InList.OWNER_ID,i_Params_Get_Taken_session_By_Where_InList.START_ROW,i_Params_Get_Taken_session_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Where_InList.TOTAL_COUNT = oParams_Get_Taken_session_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Taken_session_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Where_InList");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria_InList(Params_Get_Scheduled_session_By_Criteria_InList i_Params_Get_Scheduled_session_By_Criteria_InList)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Scheduled_session_By_Criteria_InList_SP oParams_Get_Scheduled_session_By_Criteria_InList_SP = new Params_Get_Scheduled_session_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW == null) { i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Scheduled_session_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.DATE_TIME = i_Params_Get_Scheduled_session_By_Criteria_InList.DATE_TIME;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Scheduled_session_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST);
oParams_Get_Scheduled_session_By_Criteria_InList_SP.START_ROW = i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.END_ROW = i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Scheduled_session_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Criteria_InList(i_Params_Get_Scheduled_session_By_Criteria_InList.DATE_TIME,i_Params_Get_Scheduled_session_By_Criteria_InList.DESCRIPTION,i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID,i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW,i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Scheduled_session_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Scheduled_session_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Criteria_InList");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where_InList(Params_Get_Scheduled_session_By_Where_InList i_Params_Get_Scheduled_session_By_Where_InList)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Scheduled_session_By_Where_InList_SP oParams_Get_Scheduled_session_By_Where_InList_SP = new Params_Get_Scheduled_session_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Where_InList.START_ROW == null) { i_Params_Get_Scheduled_session_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Where_InList.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Where_InList.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Scheduled_session_By_Where_InList_SP.OWNER_ID = i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID;
oParams_Get_Scheduled_session_By_Where_InList_SP.DATE_TIME = i_Params_Get_Scheduled_session_By_Where_InList.DATE_TIME;
oParams_Get_Scheduled_session_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Scheduled_session_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST);
oParams_Get_Scheduled_session_By_Where_InList_SP.START_ROW = i_Params_Get_Scheduled_session_By_Where_InList.START_ROW;
oParams_Get_Scheduled_session_By_Where_InList_SP.END_ROW = i_Params_Get_Scheduled_session_By_Where_InList.END_ROW;
oParams_Get_Scheduled_session_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Scheduled_session_By_Where_InList.TOTAL_COUNT;
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Where_InList(i_Params_Get_Scheduled_session_By_Where_InList.DATE_TIME,i_Params_Get_Scheduled_session_By_Where_InList.DESCRIPTION,i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST,i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID,i_Params_Get_Scheduled_session_By_Where_InList.START_ROW,i_Params_Get_Scheduled_session_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Where_InList.TOTAL_COUNT = oParams_Get_Scheduled_session_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Scheduled_session_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Where_InList");}
return oList;
}
public List<Comment> Get_Comment_By_Criteria_InList(Params_Get_Comment_By_Criteria_InList i_Params_Get_Comment_By_Criteria_InList)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Comment_By_Criteria_InList_SP oParams_Get_Comment_By_Criteria_InList_SP = new Params_Get_Comment_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Comment_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Comment_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Comment_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Criteria_InList.START_ROW == null) { i_Params_Get_Comment_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Comment_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Comment_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Comment_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Comment_By_Criteria_InList.OWNER_ID;
oParams_Get_Comment_By_Criteria_InList_SP.TITLE = i_Params_Get_Comment_By_Criteria_InList.TITLE;
oParams_Get_Comment_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Comment_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Comment_By_Criteria_InList_SP.START_ROW = i_Params_Get_Comment_By_Criteria_InList.START_ROW;
oParams_Get_Comment_By_Criteria_InList_SP.END_ROW = i_Params_Get_Comment_By_Criteria_InList.END_ROW;
oParams_Get_Comment_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Criteria_InList(i_Params_Get_Comment_By_Criteria_InList.TITLE,i_Params_Get_Comment_By_Criteria_InList.DESCRIPTION,i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Comment_By_Criteria_InList.OWNER_ID,i_Params_Get_Comment_By_Criteria_InList.START_ROW,i_Params_Get_Comment_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Comment_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Criteria_InList");}
return oList;
}
public List<Comment> Get_Comment_By_Where_InList(Params_Get_Comment_By_Where_InList i_Params_Get_Comment_By_Where_InList)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Comment_By_Where_InList_SP oParams_Get_Comment_By_Where_InList_SP = new Params_Get_Comment_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Comment_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Comment_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Comment_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Where_InList.START_ROW == null) { i_Params_Get_Comment_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Where_InList.END_ROW == null) || (i_Params_Get_Comment_By_Where_InList.END_ROW == 0)) { i_Params_Get_Comment_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Comment_By_Where_InList_SP.OWNER_ID = i_Params_Get_Comment_By_Where_InList.OWNER_ID;
oParams_Get_Comment_By_Where_InList_SP.TITLE = i_Params_Get_Comment_By_Where_InList.TITLE;
oParams_Get_Comment_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Comment_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST);
oParams_Get_Comment_By_Where_InList_SP.START_ROW = i_Params_Get_Comment_By_Where_InList.START_ROW;
oParams_Get_Comment_By_Where_InList_SP.END_ROW = i_Params_Get_Comment_By_Where_InList.END_ROW;
oParams_Get_Comment_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_By_Where_InList.TOTAL_COUNT;
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Where_InList(i_Params_Get_Comment_By_Where_InList.TITLE,i_Params_Get_Comment_By_Where_InList.DESCRIPTION,i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST,i_Params_Get_Comment_By_Where_InList.OWNER_ID,i_Params_Get_Comment_By_Where_InList.START_ROW,i_Params_Get_Comment_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Where_InList.TOTAL_COUNT = oParams_Get_Comment_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Where_InList");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria_InList(Params_Get_Report_coach_By_Criteria_InList i_Params_Get_Report_coach_By_Criteria_InList)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Report_coach_By_Criteria_InList_SP oParams_Get_Report_coach_By_Criteria_InList_SP = new Params_Get_Report_coach_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Criteria_InList.START_ROW == null) { i_Params_Get_Report_coach_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Report_coach_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Report_coach_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Report_coach_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID;
oParams_Get_Report_coach_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Report_coach_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_coach_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Report_coach_By_Criteria_InList_SP.START_ROW = i_Params_Get_Report_coach_By_Criteria_InList.START_ROW;
oParams_Get_Report_coach_By_Criteria_InList_SP.END_ROW = i_Params_Get_Report_coach_By_Criteria_InList.END_ROW;
oParams_Get_Report_coach_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Report_coach_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Criteria_InList(i_Params_Get_Report_coach_By_Criteria_InList.DESCRIPTION,i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID,i_Params_Get_Report_coach_By_Criteria_InList.START_ROW,i_Params_Get_Report_coach_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Report_coach_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_coach_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Criteria_InList");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where_InList(Params_Get_Report_coach_By_Where_InList i_Params_Get_Report_coach_By_Where_InList)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Report_coach_By_Where_InList_SP oParams_Get_Report_coach_By_Where_InList_SP = new Params_Get_Report_coach_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Where_InList.START_ROW == null) { i_Params_Get_Report_coach_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Where_InList.END_ROW == null) || (i_Params_Get_Report_coach_By_Where_InList.END_ROW == 0)) { i_Params_Get_Report_coach_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Report_coach_By_Where_InList_SP.OWNER_ID = i_Params_Get_Report_coach_By_Where_InList.OWNER_ID;
oParams_Get_Report_coach_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Report_coach_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_coach_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST);
oParams_Get_Report_coach_By_Where_InList_SP.START_ROW = i_Params_Get_Report_coach_By_Where_InList.START_ROW;
oParams_Get_Report_coach_By_Where_InList_SP.END_ROW = i_Params_Get_Report_coach_By_Where_InList.END_ROW;
oParams_Get_Report_coach_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Report_coach_By_Where_InList.TOTAL_COUNT;
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Where_InList(i_Params_Get_Report_coach_By_Where_InList.DESCRIPTION,i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST,i_Params_Get_Report_coach_By_Where_InList.OWNER_ID,i_Params_Get_Report_coach_By_Where_InList.START_ROW,i_Params_Get_Report_coach_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Where_InList.TOTAL_COUNT = oParams_Get_Report_coach_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_coach_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Where_InList");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria_InList(Params_Get_Comment_report_By_Criteria_InList i_Params_Get_Comment_report_By_Criteria_InList)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Comment_report_By_Criteria_InList_SP oParams_Get_Comment_report_By_Criteria_InList_SP = new Params_Get_Comment_report_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Comment_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Comment_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Comment_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Comment_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Comment_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Comment_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Criteria_InList_SP.COMMENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST);
oParams_Get_Comment_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Comment_report_By_Criteria_InList.START_ROW;
oParams_Get_Comment_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Comment_report_By_Criteria_InList.END_ROW;
oParams_Get_Comment_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Criteria_InList(i_Params_Get_Comment_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST,i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Comment_report_By_Criteria_InList.START_ROW,i_Params_Get_Comment_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Comment_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Criteria_InList");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where_InList(Params_Get_Comment_report_By_Where_InList i_Params_Get_Comment_report_By_Where_InList)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Comment_report_By_Where_InList_SP oParams_Get_Comment_report_By_Where_InList_SP = new Params_Get_Comment_report_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Where_InList.START_ROW == null) { i_Params_Get_Comment_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Comment_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Comment_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Comment_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Comment_report_By_Where_InList.OWNER_ID;
oParams_Get_Comment_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Comment_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Where_InList_SP.COMMENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST);
oParams_Get_Comment_report_By_Where_InList_SP.START_ROW = i_Params_Get_Comment_report_By_Where_InList.START_ROW;
oParams_Get_Comment_report_By_Where_InList_SP.END_ROW = i_Params_Get_Comment_report_By_Where_InList.END_ROW;
oParams_Get_Comment_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Where_InList(i_Params_Get_Comment_report_By_Where_InList.DESCRIPTION,i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST,i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST,i_Params_Get_Comment_report_By_Where_InList.OWNER_ID,i_Params_Get_Comment_report_By_Where_InList.START_ROW,i_Params_Get_Comment_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Comment_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Where_InList");}
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria_InList(Params_Get_Report_player_By_Criteria_InList i_Params_Get_Report_player_By_Criteria_InList)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Report_player_By_Criteria_InList_SP oParams_Get_Report_player_By_Criteria_InList_SP = new Params_Get_Report_player_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Criteria_InList.START_ROW == null) { i_Params_Get_Report_player_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Report_player_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Report_player_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Report_player_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID;
oParams_Get_Report_player_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Report_player_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_player_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST);
oParams_Get_Report_player_By_Criteria_InList_SP.START_ROW = i_Params_Get_Report_player_By_Criteria_InList.START_ROW;
oParams_Get_Report_player_By_Criteria_InList_SP.END_ROW = i_Params_Get_Report_player_By_Criteria_InList.END_ROW;
oParams_Get_Report_player_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Report_player_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Criteria_InList(i_Params_Get_Report_player_By_Criteria_InList.DESCRIPTION,i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID,i_Params_Get_Report_player_By_Criteria_InList.START_ROW,i_Params_Get_Report_player_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Report_player_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_player_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Criteria_InList");}
return oList;
}
public List<Report_player> Get_Report_player_By_Where_InList(Params_Get_Report_player_By_Where_InList i_Params_Get_Report_player_By_Where_InList)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Report_player_By_Where_InList_SP oParams_Get_Report_player_By_Where_InList_SP = new Params_Get_Report_player_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Report_player_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Where_InList.START_ROW == null) { i_Params_Get_Report_player_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Where_InList.END_ROW == null) || (i_Params_Get_Report_player_By_Where_InList.END_ROW == 0)) { i_Params_Get_Report_player_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Report_player_By_Where_InList_SP.OWNER_ID = i_Params_Get_Report_player_By_Where_InList.OWNER_ID;
oParams_Get_Report_player_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Report_player_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_player_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST);
oParams_Get_Report_player_By_Where_InList_SP.START_ROW = i_Params_Get_Report_player_By_Where_InList.START_ROW;
oParams_Get_Report_player_By_Where_InList_SP.END_ROW = i_Params_Get_Report_player_By_Where_InList.END_ROW;
oParams_Get_Report_player_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Report_player_By_Where_InList.TOTAL_COUNT;
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Where_InList(i_Params_Get_Report_player_By_Where_InList.DESCRIPTION,i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Report_player_By_Where_InList.OWNER_ID,i_Params_Get_Report_player_By_Where_InList.START_ROW,i_Params_Get_Report_player_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Where_InList.TOTAL_COUNT = oParams_Get_Report_player_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_player_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Where_InList");}
return oList;
}
public void Delete_Coach_leaderboards(Params_Delete_Coach_leaderboards i_Params_Delete_Coach_leaderboards)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_leaderboards");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_leaderboards_Execution)
{
_Stop_Delete_Coach_leaderboards_Execution = false;
return;
}
_AppContext.Delete_Coach_leaderboards(i_Params_Delete_Coach_leaderboards.COACH_LEADERBOARDS_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_leaderboards");}
}
public void Delete_Player_leaderboards(Params_Delete_Player_leaderboards i_Params_Delete_Player_leaderboards)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Player_leaderboards");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Player_leaderboards_Execution)
{
_Stop_Delete_Player_leaderboards_Execution = false;
return;
}
_AppContext.Delete_Player_leaderboards(i_Params_Delete_Player_leaderboards.PLAYER_LEADERBOARDS_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Player_leaderboards");}
}
public void Delete_Playersport(Params_Delete_Playersport i_Params_Delete_Playersport)
{
Params_Get_Playersport_By_PLAYERSPORT_ID oParams_Get_Playersport_By_PLAYERSPORT_ID = new Params_Get_Playersport_By_PLAYERSPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Playersport");}
#region Body Section.
try
{
oParams_Get_Playersport_By_PLAYERSPORT_ID.PLAYERSPORT_ID = i_Params_Delete_Playersport.PLAYERSPORT_ID;
_Playersport = Get_Playersport_By_PLAYERSPORT_ID_Adv(oParams_Get_Playersport_By_PLAYERSPORT_ID);
if (_Playersport != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Playersport_Execution)
{
_Stop_Delete_Playersport_Execution = false;
return;
}
_AppContext.Delete_Playersport(i_Params_Delete_Playersport.PLAYERSPORT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Playersport");}
}
public void Delete_Sport(Params_Delete_Sport i_Params_Delete_Sport)
{
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Sport");}
#region Body Section.
try
{
oParams_Get_Sport_By_SPORT_ID.SPORT_ID = i_Params_Delete_Sport.SPORT_ID;
_Sport = Get_Sport_By_SPORT_ID_Adv(oParams_Get_Sport_By_SPORT_ID);
if (_Sport != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Sport_Execution)
{
_Stop_Delete_Sport_Execution = false;
return;
}
_AppContext.Delete_Sport(i_Params_Delete_Sport.SPORT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Sport");}
}
public void Delete_Coachsport(Params_Delete_Coachsport i_Params_Delete_Coachsport)
{
Params_Get_Coachsport_By_COACHSPORT_ID oParams_Get_Coachsport_By_COACHSPORT_ID = new Params_Get_Coachsport_By_COACHSPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coachsport");}
#region Body Section.
try
{
oParams_Get_Coachsport_By_COACHSPORT_ID.COACHSPORT_ID = i_Params_Delete_Coachsport.COACHSPORT_ID;
_Coachsport = Get_Coachsport_By_COACHSPORT_ID_Adv(oParams_Get_Coachsport_By_COACHSPORT_ID);
if (_Coachsport != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coachsport_Execution)
{
_Stop_Delete_Coachsport_Execution = false;
return;
}
_AppContext.Delete_Coachsport(i_Params_Delete_Coachsport.COACHSPORT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coachsport");}
}
public void Delete_Coach_evaluation(Params_Delete_Coach_evaluation i_Params_Delete_Coach_evaluation)
{
Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID oParams_Get_Coach_evaluation_By_COACH_EVALUATION_ID = new Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_evaluation");}
#region Body Section.
try
{
oParams_Get_Coach_evaluation_By_COACH_EVALUATION_ID.COACH_EVALUATION_ID = i_Params_Delete_Coach_evaluation.COACH_EVALUATION_ID;
_Coach_evaluation = Get_Coach_evaluation_By_COACH_EVALUATION_ID_Adv(oParams_Get_Coach_evaluation_By_COACH_EVALUATION_ID);
if (_Coach_evaluation != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_evaluation_Execution)
{
_Stop_Delete_Coach_evaluation_Execution = false;
return;
}
_AppContext.Delete_Coach_evaluation(i_Params_Delete_Coach_evaluation.COACH_EVALUATION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_evaluation");}
}
public void Delete_Currency(Params_Delete_Currency i_Params_Delete_Currency)
{
Params_Get_Currency_By_CURRENCY_ID oParams_Get_Currency_By_CURRENCY_ID = new Params_Get_Currency_By_CURRENCY_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Currency");}
#region Body Section.
try
{
oParams_Get_Currency_By_CURRENCY_ID.CURRENCY_ID = i_Params_Delete_Currency.CURRENCY_ID;
_Currency = Get_Currency_By_CURRENCY_ID_Adv(oParams_Get_Currency_By_CURRENCY_ID);
if (_Currency != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Currency_Execution)
{
_Stop_Delete_Currency_Execution = false;
return;
}
_AppContext.Delete_Currency(i_Params_Delete_Currency.CURRENCY_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Currency");}
}
public void Delete_Session_evaluation(Params_Delete_Session_evaluation i_Params_Delete_Session_evaluation)
{
Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID oParams_Get_Session_evaluation_By_SESSION_EVALUATION_ID = new Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Session_evaluation");}
#region Body Section.
try
{
oParams_Get_Session_evaluation_By_SESSION_EVALUATION_ID.SESSION_EVALUATION_ID = i_Params_Delete_Session_evaluation.SESSION_EVALUATION_ID;
_Session_evaluation = Get_Session_evaluation_By_SESSION_EVALUATION_ID_Adv(oParams_Get_Session_evaluation_By_SESSION_EVALUATION_ID);
if (_Session_evaluation != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Session_evaluation_Execution)
{
_Stop_Delete_Session_evaluation_Execution = false;
return;
}
_AppContext.Delete_Session_evaluation(i_Params_Delete_Session_evaluation.SESSION_EVALUATION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Session_evaluation");}
}
public void Delete_Taken_session(Params_Delete_Taken_session i_Params_Delete_Taken_session)
{
Params_Get_Taken_session_By_TAKEN_SESSION_ID oParams_Get_Taken_session_By_TAKEN_SESSION_ID = new Params_Get_Taken_session_By_TAKEN_SESSION_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Taken_session");}
#region Body Section.
try
{
oParams_Get_Taken_session_By_TAKEN_SESSION_ID.TAKEN_SESSION_ID = i_Params_Delete_Taken_session.TAKEN_SESSION_ID;
_Taken_session = Get_Taken_session_By_TAKEN_SESSION_ID_Adv(oParams_Get_Taken_session_By_TAKEN_SESSION_ID);
if (_Taken_session != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Taken_session_Execution)
{
_Stop_Delete_Taken_session_Execution = false;
return;
}
_AppContext.Delete_Taken_session(i_Params_Delete_Taken_session.TAKEN_SESSION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Taken_session");}
}
public void Delete_Scheduled_session(Params_Delete_Scheduled_session i_Params_Delete_Scheduled_session)
{
Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID oParams_Get_Scheduled_session_By_SCHEDULED_SESSION_ID = new Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Scheduled_session");}
#region Body Section.
try
{
oParams_Get_Scheduled_session_By_SCHEDULED_SESSION_ID.SCHEDULED_SESSION_ID = i_Params_Delete_Scheduled_session.SCHEDULED_SESSION_ID;
_Scheduled_session = Get_Scheduled_session_By_SCHEDULED_SESSION_ID_Adv(oParams_Get_Scheduled_session_By_SCHEDULED_SESSION_ID);
if (_Scheduled_session != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Scheduled_session_Execution)
{
_Stop_Delete_Scheduled_session_Execution = false;
return;
}
_AppContext.Delete_Scheduled_session(i_Params_Delete_Scheduled_session.SCHEDULED_SESSION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Scheduled_session");}
}
public void Delete_Notification(Params_Delete_Notification i_Params_Delete_Notification)
{
Params_Get_Notification_By_NOTIFICATION_ID oParams_Get_Notification_By_NOTIFICATION_ID = new Params_Get_Notification_By_NOTIFICATION_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification");}
#region Body Section.
try
{
oParams_Get_Notification_By_NOTIFICATION_ID.NOTIFICATION_ID = i_Params_Delete_Notification.NOTIFICATION_ID;
_Notification = Get_Notification_By_NOTIFICATION_ID_Adv(oParams_Get_Notification_By_NOTIFICATION_ID);
if (_Notification != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification(i_Params_Delete_Notification.NOTIFICATION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification");}
}
public void Delete_Owner(Params_Delete_Owner i_Params_Delete_Owner)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Owner");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Owner_Execution)
{
_Stop_Delete_Owner_Execution = false;
return;
}
_AppContext.Delete_Owner(i_Params_Delete_Owner.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Owner");}
}
public void Delete_Comment(Params_Delete_Comment i_Params_Delete_Comment)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_Execution)
{
_Stop_Delete_Comment_Execution = false;
return;
}
_AppContext.Delete_Comment(i_Params_Delete_Comment.COMMENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment");}
}
public void Delete_Report_coach(Params_Delete_Report_coach i_Params_Delete_Report_coach)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_coach");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_coach_Execution)
{
_Stop_Delete_Report_coach_Execution = false;
return;
}
_AppContext.Delete_Report_coach(i_Params_Delete_Report_coach.REPORT_COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_coach");}
}
public void Delete_Comment_report(Params_Delete_Comment_report i_Params_Delete_Comment_report)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_report");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_report_Execution)
{
_Stop_Delete_Comment_report_Execution = false;
return;
}
_AppContext.Delete_Comment_report(i_Params_Delete_Comment_report.COMMENT_REPORT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_report");}
}
public void Delete_User(Params_Delete_User i_Params_Delete_User)
{
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_User");}
#region Body Section.
try
{
oParams_Get_User_By_USER_ID.USER_ID = i_Params_Delete_User.USER_ID;
_User = Get_User_By_USER_ID_Adv(oParams_Get_User_By_USER_ID);
if (_User != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_User_Execution)
{
_Stop_Delete_User_Execution = false;
return;
}
_AppContext.Delete_User(i_Params_Delete_User.USER_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_User");}
}
public void Delete_Direct_message(Params_Delete_Direct_message i_Params_Delete_Direct_message)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Direct_message");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Direct_message_Execution)
{
_Stop_Delete_Direct_message_Execution = false;
return;
}
_AppContext.Delete_Direct_message(i_Params_Delete_Direct_message.DIRECT_MESSAGE_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Direct_message");}
}
public void Delete_Report_player(Params_Delete_Report_player i_Params_Delete_Report_player)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_player");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_player_Execution)
{
_Stop_Delete_Report_player_Execution = false;
return;
}
_AppContext.Delete_Report_player(i_Params_Delete_Report_player.REPORT_PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_player");}
}
public void Delete_Coach(Params_Delete_Coach i_Params_Delete_Coach)
{
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach");}
#region Body Section.
try
{
oParams_Get_Coach_By_COACH_ID.COACH_ID = i_Params_Delete_Coach.COACH_ID;
_Coach = Get_Coach_By_COACH_ID_Adv(oParams_Get_Coach_By_COACH_ID);
if (_Coach != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_Execution)
{
_Stop_Delete_Coach_Execution = false;
return;
}
_AppContext.Delete_Coach(i_Params_Delete_Coach.COACH_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach");}
}
public void Delete_Player(Params_Delete_Player i_Params_Delete_Player)
{
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Player");}
#region Body Section.
try
{
oParams_Get_Player_By_PLAYER_ID.PLAYER_ID = i_Params_Delete_Player.PLAYER_ID;
_Player = Get_Player_By_PLAYER_ID_Adv(oParams_Get_Player_By_PLAYER_ID);
if (_Player != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Player_Execution)
{
_Stop_Delete_Player_Execution = false;
return;
}
_AppContext.Delete_Player(i_Params_Delete_Player.PLAYER_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Player");}
}
public void Delete_Coach_leaderboards_By_OWNER_ID(Params_Delete_Coach_leaderboards_By_OWNER_ID i_Params_Delete_Coach_leaderboards_By_OWNER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_leaderboards_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_leaderboards_Execution)
{
_Stop_Delete_Coach_leaderboards_Execution = false;
return;
}
_AppContext.Delete_Coach_leaderboards_By_OWNER_ID(i_Params_Delete_Coach_leaderboards_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_leaderboards_By_OWNER_ID");}
}
public void Delete_Coach_leaderboards_By_COACH_ID(Params_Delete_Coach_leaderboards_By_COACH_ID i_Params_Delete_Coach_leaderboards_By_COACH_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_leaderboards_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_leaderboards_Execution)
{
_Stop_Delete_Coach_leaderboards_Execution = false;
return;
}
_AppContext.Delete_Coach_leaderboards_By_COACH_ID(i_Params_Delete_Coach_leaderboards_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_leaderboards_By_COACH_ID");}
}
public void Delete_Player_leaderboards_By_OWNER_ID(Params_Delete_Player_leaderboards_By_OWNER_ID i_Params_Delete_Player_leaderboards_By_OWNER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Player_leaderboards_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Player_leaderboards_Execution)
{
_Stop_Delete_Player_leaderboards_Execution = false;
return;
}
_AppContext.Delete_Player_leaderboards_By_OWNER_ID(i_Params_Delete_Player_leaderboards_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Player_leaderboards_By_OWNER_ID");}
}
public void Delete_Player_leaderboards_By_PLAYER_ID(Params_Delete_Player_leaderboards_By_PLAYER_ID i_Params_Delete_Player_leaderboards_By_PLAYER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Player_leaderboards_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Player_leaderboards_Execution)
{
_Stop_Delete_Player_leaderboards_Execution = false;
return;
}
_AppContext.Delete_Player_leaderboards_By_PLAYER_ID(i_Params_Delete_Player_leaderboards_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Player_leaderboards_By_PLAYER_ID");}
}
public void Delete_Playersport_By_OWNER_ID(Params_Delete_Playersport_By_OWNER_ID i_Params_Delete_Playersport_By_OWNER_ID)
{
Params_Get_Playersport_By_OWNER_ID oParams_Get_Playersport_By_OWNER_ID = new Params_Get_Playersport_By_OWNER_ID();
List<Playersport> _List_Playersport = new List<Playersport>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Playersport_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Playersport_Execution)
{
_Stop_Delete_Playersport_Execution = false;
return;
}
_AppContext.Delete_Playersport_By_OWNER_ID(i_Params_Delete_Playersport_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Playersport_By_OWNER_ID");}
}
public void Delete_Playersport_By_PLAYER_ID(Params_Delete_Playersport_By_PLAYER_ID i_Params_Delete_Playersport_By_PLAYER_ID)
{
Params_Get_Playersport_By_PLAYER_ID oParams_Get_Playersport_By_PLAYER_ID = new Params_Get_Playersport_By_PLAYER_ID();
List<Playersport> _List_Playersport = new List<Playersport>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Playersport_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Playersport_Execution)
{
_Stop_Delete_Playersport_Execution = false;
return;
}
_AppContext.Delete_Playersport_By_PLAYER_ID(i_Params_Delete_Playersport_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Playersport_By_PLAYER_ID");}
}
public void Delete_Playersport_By_SPORT_ID(Params_Delete_Playersport_By_SPORT_ID i_Params_Delete_Playersport_By_SPORT_ID)
{
Params_Get_Playersport_By_SPORT_ID oParams_Get_Playersport_By_SPORT_ID = new Params_Get_Playersport_By_SPORT_ID();
List<Playersport> _List_Playersport = new List<Playersport>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Playersport_By_SPORT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Playersport_Execution)
{
_Stop_Delete_Playersport_Execution = false;
return;
}
_AppContext.Delete_Playersport_By_SPORT_ID(i_Params_Delete_Playersport_By_SPORT_ID.SPORT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Playersport_By_SPORT_ID");}
}
public void Delete_Sport_By_OWNER_ID(Params_Delete_Sport_By_OWNER_ID i_Params_Delete_Sport_By_OWNER_ID)
{
Params_Get_Sport_By_OWNER_ID oParams_Get_Sport_By_OWNER_ID = new Params_Get_Sport_By_OWNER_ID();
List<Sport> _List_Sport = new List<Sport>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Sport_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Sport_Execution)
{
_Stop_Delete_Sport_Execution = false;
return;
}
_AppContext.Delete_Sport_By_OWNER_ID(i_Params_Delete_Sport_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Sport_By_OWNER_ID");}
}
public void Delete_Coachsport_By_OWNER_ID(Params_Delete_Coachsport_By_OWNER_ID i_Params_Delete_Coachsport_By_OWNER_ID)
{
Params_Get_Coachsport_By_OWNER_ID oParams_Get_Coachsport_By_OWNER_ID = new Params_Get_Coachsport_By_OWNER_ID();
List<Coachsport> _List_Coachsport = new List<Coachsport>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coachsport_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coachsport_Execution)
{
_Stop_Delete_Coachsport_Execution = false;
return;
}
_AppContext.Delete_Coachsport_By_OWNER_ID(i_Params_Delete_Coachsport_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coachsport_By_OWNER_ID");}
}
public void Delete_Coachsport_By_SPORT_ID(Params_Delete_Coachsport_By_SPORT_ID i_Params_Delete_Coachsport_By_SPORT_ID)
{
Params_Get_Coachsport_By_SPORT_ID oParams_Get_Coachsport_By_SPORT_ID = new Params_Get_Coachsport_By_SPORT_ID();
List<Coachsport> _List_Coachsport = new List<Coachsport>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coachsport_By_SPORT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coachsport_Execution)
{
_Stop_Delete_Coachsport_Execution = false;
return;
}
_AppContext.Delete_Coachsport_By_SPORT_ID(i_Params_Delete_Coachsport_By_SPORT_ID.SPORT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coachsport_By_SPORT_ID");}
}
public void Delete_Coachsport_By_COACH_ID(Params_Delete_Coachsport_By_COACH_ID i_Params_Delete_Coachsport_By_COACH_ID)
{
Params_Get_Coachsport_By_COACH_ID oParams_Get_Coachsport_By_COACH_ID = new Params_Get_Coachsport_By_COACH_ID();
List<Coachsport> _List_Coachsport = new List<Coachsport>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coachsport_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coachsport_Execution)
{
_Stop_Delete_Coachsport_Execution = false;
return;
}
_AppContext.Delete_Coachsport_By_COACH_ID(i_Params_Delete_Coachsport_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coachsport_By_COACH_ID");}
}
public void Delete_Coach_evaluation_By_OWNER_ID(Params_Delete_Coach_evaluation_By_OWNER_ID i_Params_Delete_Coach_evaluation_By_OWNER_ID)
{
Params_Get_Coach_evaluation_By_OWNER_ID oParams_Get_Coach_evaluation_By_OWNER_ID = new Params_Get_Coach_evaluation_By_OWNER_ID();
List<Coach_evaluation> _List_Coach_evaluation = new List<Coach_evaluation>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_evaluation_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_evaluation_Execution)
{
_Stop_Delete_Coach_evaluation_Execution = false;
return;
}
_AppContext.Delete_Coach_evaluation_By_OWNER_ID(i_Params_Delete_Coach_evaluation_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_evaluation_By_OWNER_ID");}
}
public void Delete_Coach_evaluation_By_PLAYER_ID(Params_Delete_Coach_evaluation_By_PLAYER_ID i_Params_Delete_Coach_evaluation_By_PLAYER_ID)
{
Params_Get_Coach_evaluation_By_PLAYER_ID oParams_Get_Coach_evaluation_By_PLAYER_ID = new Params_Get_Coach_evaluation_By_PLAYER_ID();
List<Coach_evaluation> _List_Coach_evaluation = new List<Coach_evaluation>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_evaluation_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_evaluation_Execution)
{
_Stop_Delete_Coach_evaluation_Execution = false;
return;
}
_AppContext.Delete_Coach_evaluation_By_PLAYER_ID(i_Params_Delete_Coach_evaluation_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_evaluation_By_PLAYER_ID");}
}
public void Delete_Coach_evaluation_By_COACH_ID(Params_Delete_Coach_evaluation_By_COACH_ID i_Params_Delete_Coach_evaluation_By_COACH_ID)
{
Params_Get_Coach_evaluation_By_COACH_ID oParams_Get_Coach_evaluation_By_COACH_ID = new Params_Get_Coach_evaluation_By_COACH_ID();
List<Coach_evaluation> _List_Coach_evaluation = new List<Coach_evaluation>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_evaluation_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_evaluation_Execution)
{
_Stop_Delete_Coach_evaluation_Execution = false;
return;
}
_AppContext.Delete_Coach_evaluation_By_COACH_ID(i_Params_Delete_Coach_evaluation_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_evaluation_By_COACH_ID");}
}
public void Delete_Currency_By_OWNER_ID(Params_Delete_Currency_By_OWNER_ID i_Params_Delete_Currency_By_OWNER_ID)
{
Params_Get_Currency_By_OWNER_ID oParams_Get_Currency_By_OWNER_ID = new Params_Get_Currency_By_OWNER_ID();
List<Currency> _List_Currency = new List<Currency>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Currency_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Currency_Execution)
{
_Stop_Delete_Currency_Execution = false;
return;
}
_AppContext.Delete_Currency_By_OWNER_ID(i_Params_Delete_Currency_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Currency_By_OWNER_ID");}
}
public void Delete_Session_evaluation_By_OWNER_ID(Params_Delete_Session_evaluation_By_OWNER_ID i_Params_Delete_Session_evaluation_By_OWNER_ID)
{
Params_Get_Session_evaluation_By_OWNER_ID oParams_Get_Session_evaluation_By_OWNER_ID = new Params_Get_Session_evaluation_By_OWNER_ID();
List<Session_evaluation> _List_Session_evaluation = new List<Session_evaluation>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Session_evaluation_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Session_evaluation_Execution)
{
_Stop_Delete_Session_evaluation_Execution = false;
return;
}
_AppContext.Delete_Session_evaluation_By_OWNER_ID(i_Params_Delete_Session_evaluation_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Session_evaluation_By_OWNER_ID");}
}
public void Delete_Session_evaluation_By_COACH_ID(Params_Delete_Session_evaluation_By_COACH_ID i_Params_Delete_Session_evaluation_By_COACH_ID)
{
Params_Get_Session_evaluation_By_COACH_ID oParams_Get_Session_evaluation_By_COACH_ID = new Params_Get_Session_evaluation_By_COACH_ID();
List<Session_evaluation> _List_Session_evaluation = new List<Session_evaluation>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Session_evaluation_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Session_evaluation_Execution)
{
_Stop_Delete_Session_evaluation_Execution = false;
return;
}
_AppContext.Delete_Session_evaluation_By_COACH_ID(i_Params_Delete_Session_evaluation_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Session_evaluation_By_COACH_ID");}
}
public void Delete_Session_evaluation_By_PLAYER_ID(Params_Delete_Session_evaluation_By_PLAYER_ID i_Params_Delete_Session_evaluation_By_PLAYER_ID)
{
Params_Get_Session_evaluation_By_PLAYER_ID oParams_Get_Session_evaluation_By_PLAYER_ID = new Params_Get_Session_evaluation_By_PLAYER_ID();
List<Session_evaluation> _List_Session_evaluation = new List<Session_evaluation>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Session_evaluation_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Session_evaluation_Execution)
{
_Stop_Delete_Session_evaluation_Execution = false;
return;
}
_AppContext.Delete_Session_evaluation_By_PLAYER_ID(i_Params_Delete_Session_evaluation_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Session_evaluation_By_PLAYER_ID");}
}
public void Delete_Taken_session_By_OWNER_ID(Params_Delete_Taken_session_By_OWNER_ID i_Params_Delete_Taken_session_By_OWNER_ID)
{
Params_Get_Taken_session_By_OWNER_ID oParams_Get_Taken_session_By_OWNER_ID = new Params_Get_Taken_session_By_OWNER_ID();
List<Taken_session> _List_Taken_session = new List<Taken_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Taken_session_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Taken_session_Execution)
{
_Stop_Delete_Taken_session_Execution = false;
return;
}
_AppContext.Delete_Taken_session_By_OWNER_ID(i_Params_Delete_Taken_session_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Taken_session_By_OWNER_ID");}
}
public void Delete_Taken_session_By_COACH_ID(Params_Delete_Taken_session_By_COACH_ID i_Params_Delete_Taken_session_By_COACH_ID)
{
Params_Get_Taken_session_By_COACH_ID oParams_Get_Taken_session_By_COACH_ID = new Params_Get_Taken_session_By_COACH_ID();
List<Taken_session> _List_Taken_session = new List<Taken_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Taken_session_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Taken_session_Execution)
{
_Stop_Delete_Taken_session_Execution = false;
return;
}
_AppContext.Delete_Taken_session_By_COACH_ID(i_Params_Delete_Taken_session_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Taken_session_By_COACH_ID");}
}
public void Delete_Taken_session_By_PLAYER_ID(Params_Delete_Taken_session_By_PLAYER_ID i_Params_Delete_Taken_session_By_PLAYER_ID)
{
Params_Get_Taken_session_By_PLAYER_ID oParams_Get_Taken_session_By_PLAYER_ID = new Params_Get_Taken_session_By_PLAYER_ID();
List<Taken_session> _List_Taken_session = new List<Taken_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Taken_session_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Taken_session_Execution)
{
_Stop_Delete_Taken_session_Execution = false;
return;
}
_AppContext.Delete_Taken_session_By_PLAYER_ID(i_Params_Delete_Taken_session_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Taken_session_By_PLAYER_ID");}
}
public void Delete_Taken_session_By_SPORT_ID(Params_Delete_Taken_session_By_SPORT_ID i_Params_Delete_Taken_session_By_SPORT_ID)
{
Params_Get_Taken_session_By_SPORT_ID oParams_Get_Taken_session_By_SPORT_ID = new Params_Get_Taken_session_By_SPORT_ID();
List<Taken_session> _List_Taken_session = new List<Taken_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Taken_session_By_SPORT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Taken_session_Execution)
{
_Stop_Delete_Taken_session_Execution = false;
return;
}
_AppContext.Delete_Taken_session_By_SPORT_ID(i_Params_Delete_Taken_session_By_SPORT_ID.SPORT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Taken_session_By_SPORT_ID");}
}
public void Delete_Scheduled_session_By_OWNER_ID(Params_Delete_Scheduled_session_By_OWNER_ID i_Params_Delete_Scheduled_session_By_OWNER_ID)
{
Params_Get_Scheduled_session_By_OWNER_ID oParams_Get_Scheduled_session_By_OWNER_ID = new Params_Get_Scheduled_session_By_OWNER_ID();
List<Scheduled_session> _List_Scheduled_session = new List<Scheduled_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Scheduled_session_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Scheduled_session_Execution)
{
_Stop_Delete_Scheduled_session_Execution = false;
return;
}
_AppContext.Delete_Scheduled_session_By_OWNER_ID(i_Params_Delete_Scheduled_session_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Scheduled_session_By_OWNER_ID");}
}
public void Delete_Scheduled_session_By_PLAYER_ID(Params_Delete_Scheduled_session_By_PLAYER_ID i_Params_Delete_Scheduled_session_By_PLAYER_ID)
{
Params_Get_Scheduled_session_By_PLAYER_ID oParams_Get_Scheduled_session_By_PLAYER_ID = new Params_Get_Scheduled_session_By_PLAYER_ID();
List<Scheduled_session> _List_Scheduled_session = new List<Scheduled_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Scheduled_session_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Scheduled_session_Execution)
{
_Stop_Delete_Scheduled_session_Execution = false;
return;
}
_AppContext.Delete_Scheduled_session_By_PLAYER_ID(i_Params_Delete_Scheduled_session_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Scheduled_session_By_PLAYER_ID");}
}
public void Delete_Scheduled_session_By_COACH_ID(Params_Delete_Scheduled_session_By_COACH_ID i_Params_Delete_Scheduled_session_By_COACH_ID)
{
Params_Get_Scheduled_session_By_COACH_ID oParams_Get_Scheduled_session_By_COACH_ID = new Params_Get_Scheduled_session_By_COACH_ID();
List<Scheduled_session> _List_Scheduled_session = new List<Scheduled_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Scheduled_session_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Scheduled_session_Execution)
{
_Stop_Delete_Scheduled_session_Execution = false;
return;
}
_AppContext.Delete_Scheduled_session_By_COACH_ID(i_Params_Delete_Scheduled_session_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Scheduled_session_By_COACH_ID");}
}
public void Delete_Scheduled_session_By_SPORT_ID(Params_Delete_Scheduled_session_By_SPORT_ID i_Params_Delete_Scheduled_session_By_SPORT_ID)
{
Params_Get_Scheduled_session_By_SPORT_ID oParams_Get_Scheduled_session_By_SPORT_ID = new Params_Get_Scheduled_session_By_SPORT_ID();
List<Scheduled_session> _List_Scheduled_session = new List<Scheduled_session>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Scheduled_session_By_SPORT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Scheduled_session_Execution)
{
_Stop_Delete_Scheduled_session_Execution = false;
return;
}
_AppContext.Delete_Scheduled_session_By_SPORT_ID(i_Params_Delete_Scheduled_session_By_SPORT_ID.SPORT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Scheduled_session_By_SPORT_ID");}
}
public void Delete_Notification_By_OWNER_ID(Params_Delete_Notification_By_OWNER_ID i_Params_Delete_Notification_By_OWNER_ID)
{
Params_Get_Notification_By_OWNER_ID oParams_Get_Notification_By_OWNER_ID = new Params_Get_Notification_By_OWNER_ID();
List<Notification> _List_Notification = new List<Notification>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification_By_OWNER_ID(i_Params_Delete_Notification_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification_By_OWNER_ID");}
}
public void Delete_Notification_By_USER_ID(Params_Delete_Notification_By_USER_ID i_Params_Delete_Notification_By_USER_ID)
{
Params_Get_Notification_By_USER_ID oParams_Get_Notification_By_USER_ID = new Params_Get_Notification_By_USER_ID();
List<Notification> _List_Notification = new List<Notification>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification_By_USER_ID(i_Params_Delete_Notification_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification_By_USER_ID");}
}
public void Delete_Comment_By_OWNER_ID(Params_Delete_Comment_By_OWNER_ID i_Params_Delete_Comment_By_OWNER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_Execution)
{
_Stop_Delete_Comment_Execution = false;
return;
}
_AppContext.Delete_Comment_By_OWNER_ID(i_Params_Delete_Comment_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_By_OWNER_ID");}
}
public void Delete_Comment_By_PLAYER_ID(Params_Delete_Comment_By_PLAYER_ID i_Params_Delete_Comment_By_PLAYER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_Execution)
{
_Stop_Delete_Comment_Execution = false;
return;
}
_AppContext.Delete_Comment_By_PLAYER_ID(i_Params_Delete_Comment_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_By_PLAYER_ID");}
}
public void Delete_Comment_By_COACH_ID(Params_Delete_Comment_By_COACH_ID i_Params_Delete_Comment_By_COACH_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_Execution)
{
_Stop_Delete_Comment_Execution = false;
return;
}
_AppContext.Delete_Comment_By_COACH_ID(i_Params_Delete_Comment_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_By_COACH_ID");}
}
public void Delete_Report_coach_By_OWNER_ID(Params_Delete_Report_coach_By_OWNER_ID i_Params_Delete_Report_coach_By_OWNER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_coach_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_coach_Execution)
{
_Stop_Delete_Report_coach_Execution = false;
return;
}
_AppContext.Delete_Report_coach_By_OWNER_ID(i_Params_Delete_Report_coach_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_coach_By_OWNER_ID");}
}
public void Delete_Report_coach_By_USER_ID(Params_Delete_Report_coach_By_USER_ID i_Params_Delete_Report_coach_By_USER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_coach_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_coach_Execution)
{
_Stop_Delete_Report_coach_Execution = false;
return;
}
_AppContext.Delete_Report_coach_By_USER_ID(i_Params_Delete_Report_coach_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_coach_By_USER_ID");}
}
public void Delete_Report_coach_By_COACH_ID(Params_Delete_Report_coach_By_COACH_ID i_Params_Delete_Report_coach_By_COACH_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_coach_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_coach_Execution)
{
_Stop_Delete_Report_coach_Execution = false;
return;
}
_AppContext.Delete_Report_coach_By_COACH_ID(i_Params_Delete_Report_coach_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_coach_By_COACH_ID");}
}
public void Delete_Comment_report_By_OWNER_ID(Params_Delete_Comment_report_By_OWNER_ID i_Params_Delete_Comment_report_By_OWNER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_report_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_report_Execution)
{
_Stop_Delete_Comment_report_Execution = false;
return;
}
_AppContext.Delete_Comment_report_By_OWNER_ID(i_Params_Delete_Comment_report_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_report_By_OWNER_ID");}
}
public void Delete_Comment_report_By_PLAYER_ID(Params_Delete_Comment_report_By_PLAYER_ID i_Params_Delete_Comment_report_By_PLAYER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_report_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_report_Execution)
{
_Stop_Delete_Comment_report_Execution = false;
return;
}
_AppContext.Delete_Comment_report_By_PLAYER_ID(i_Params_Delete_Comment_report_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_report_By_PLAYER_ID");}
}
public void Delete_Comment_report_By_COACH_ID(Params_Delete_Comment_report_By_COACH_ID i_Params_Delete_Comment_report_By_COACH_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_report_By_COACH_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_report_Execution)
{
_Stop_Delete_Comment_report_Execution = false;
return;
}
_AppContext.Delete_Comment_report_By_COACH_ID(i_Params_Delete_Comment_report_By_COACH_ID.COACH_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_report_By_COACH_ID");}
}
public void Delete_Comment_report_By_COMMENT_ID(Params_Delete_Comment_report_By_COMMENT_ID i_Params_Delete_Comment_report_By_COMMENT_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_report_By_COMMENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Comment_report_Execution)
{
_Stop_Delete_Comment_report_Execution = false;
return;
}
_AppContext.Delete_Comment_report_By_COMMENT_ID(i_Params_Delete_Comment_report_By_COMMENT_ID.COMMENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_report_By_COMMENT_ID");}
}
public void Delete_User_By_OWNER_ID(Params_Delete_User_By_OWNER_ID i_Params_Delete_User_By_OWNER_ID)
{
Params_Get_User_By_OWNER_ID oParams_Get_User_By_OWNER_ID = new Params_Get_User_By_OWNER_ID();
List<User> _List_User = new List<User>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_User_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_User_Execution)
{
_Stop_Delete_User_Execution = false;
return;
}
_AppContext.Delete_User_By_OWNER_ID(i_Params_Delete_User_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_User_By_OWNER_ID");}
}
public void Delete_User_By_USERNAME(Params_Delete_User_By_USERNAME i_Params_Delete_User_By_USERNAME)
{
Params_Get_User_By_USERNAME oParams_Get_User_By_USERNAME = new Params_Get_User_By_USERNAME();
List<User> _List_User = new List<User>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_User_By_USERNAME");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_User_Execution)
{
_Stop_Delete_User_Execution = false;
return;
}
_AppContext.Delete_User_By_USERNAME(i_Params_Delete_User_By_USERNAME.USERNAME);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_User_By_USERNAME");}
}
public void Delete_Direct_message_By_OWNER_ID(Params_Delete_Direct_message_By_OWNER_ID i_Params_Delete_Direct_message_By_OWNER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Direct_message_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Direct_message_Execution)
{
_Stop_Delete_Direct_message_Execution = false;
return;
}
_AppContext.Delete_Direct_message_By_OWNER_ID(i_Params_Delete_Direct_message_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Direct_message_By_OWNER_ID");}
}
public void Delete_Direct_message_By_AUTHOR_ID(Params_Delete_Direct_message_By_AUTHOR_ID i_Params_Delete_Direct_message_By_AUTHOR_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Direct_message_By_AUTHOR_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Direct_message_Execution)
{
_Stop_Delete_Direct_message_Execution = false;
return;
}
_AppContext.Delete_Direct_message_By_AUTHOR_ID(i_Params_Delete_Direct_message_By_AUTHOR_ID.AUTHOR_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Direct_message_By_AUTHOR_ID");}
}
public void Delete_Direct_message_By_RECIPIENT_ID(Params_Delete_Direct_message_By_RECIPIENT_ID i_Params_Delete_Direct_message_By_RECIPIENT_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Direct_message_By_RECIPIENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Direct_message_Execution)
{
_Stop_Delete_Direct_message_Execution = false;
return;
}
_AppContext.Delete_Direct_message_By_RECIPIENT_ID(i_Params_Delete_Direct_message_By_RECIPIENT_ID.RECIPIENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Direct_message_By_RECIPIENT_ID");}
}
public void Delete_Report_player_By_OWNER_ID(Params_Delete_Report_player_By_OWNER_ID i_Params_Delete_Report_player_By_OWNER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_player_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_player_Execution)
{
_Stop_Delete_Report_player_Execution = false;
return;
}
_AppContext.Delete_Report_player_By_OWNER_ID(i_Params_Delete_Report_player_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_player_By_OWNER_ID");}
}
public void Delete_Report_player_By_USER_ID(Params_Delete_Report_player_By_USER_ID i_Params_Delete_Report_player_By_USER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_player_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_player_Execution)
{
_Stop_Delete_Report_player_Execution = false;
return;
}
_AppContext.Delete_Report_player_By_USER_ID(i_Params_Delete_Report_player_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_player_By_USER_ID");}
}
public void Delete_Report_player_By_PLAYER_ID(Params_Delete_Report_player_By_PLAYER_ID i_Params_Delete_Report_player_By_PLAYER_ID)
{
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_player_By_PLAYER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_player_Execution)
{
_Stop_Delete_Report_player_Execution = false;
return;
}
_AppContext.Delete_Report_player_By_PLAYER_ID(i_Params_Delete_Report_player_By_PLAYER_ID.PLAYER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_player_By_PLAYER_ID");}
}
public void Delete_Coach_By_OWNER_ID(Params_Delete_Coach_By_OWNER_ID i_Params_Delete_Coach_By_OWNER_ID)
{
Params_Get_Coach_By_OWNER_ID oParams_Get_Coach_By_OWNER_ID = new Params_Get_Coach_By_OWNER_ID();
List<Coach> _List_Coach = new List<Coach>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_Execution)
{
_Stop_Delete_Coach_Execution = false;
return;
}
_AppContext.Delete_Coach_By_OWNER_ID(i_Params_Delete_Coach_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_By_OWNER_ID");}
}
public void Delete_Coach_By_USER_ID(Params_Delete_Coach_By_USER_ID i_Params_Delete_Coach_By_USER_ID)
{
Params_Get_Coach_By_USER_ID oParams_Get_Coach_By_USER_ID = new Params_Get_Coach_By_USER_ID();
List<Coach> _List_Coach = new List<Coach>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Coach_Execution)
{
_Stop_Delete_Coach_Execution = false;
return;
}
_AppContext.Delete_Coach_By_USER_ID(i_Params_Delete_Coach_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_By_USER_ID");}
}
public void Delete_Player_By_OWNER_ID(Params_Delete_Player_By_OWNER_ID i_Params_Delete_Player_By_OWNER_ID)
{
Params_Get_Player_By_OWNER_ID oParams_Get_Player_By_OWNER_ID = new Params_Get_Player_By_OWNER_ID();
List<Player> _List_Player = new List<Player>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Player_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Player_Execution)
{
_Stop_Delete_Player_Execution = false;
return;
}
_AppContext.Delete_Player_By_OWNER_ID(i_Params_Delete_Player_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Player_By_OWNER_ID");}
}
public void Delete_Player_By_USER_ID(Params_Delete_Player_By_USER_ID i_Params_Delete_Player_By_USER_ID)
{
Params_Get_Player_By_USER_ID oParams_Get_Player_By_USER_ID = new Params_Get_Player_By_USER_ID();
List<Player> _List_Player = new List<Player>();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Player_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Player_Execution)
{
_Stop_Delete_Player_Execution = false;
return;
}
_AppContext.Delete_Player_By_USER_ID(i_Params_Delete_Player_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Player_By_USER_ID");}
}
public void Edit_Coach_leaderboards(Coach_leaderboards i_Coach_leaderboards) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Coach_leaderboards.COACH_LEADERBOARDS_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_leaderboards");}
#region Body Section.
if ((i_Coach_leaderboards.COACH_LEADERBOARDS_ID == null) || (i_Coach_leaderboards.COACH_LEADERBOARDS_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Coach_leaderboards"); }
i_Coach_leaderboards.ENTRY_USER_ID = this.UserID;
i_Coach_leaderboards.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Coach_leaderboards.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Coach_leaderboards_Execution)
{
_Stop_Edit_Coach_leaderboards_Execution = false;
return;
}
i_Coach_leaderboards.COACH_LEADERBOARDS_ID = _AppContext.Edit_Coach_leaderboards
(
i_Coach_leaderboards.COACH_LEADERBOARDS_ID
,i_Coach_leaderboards.COACH_ID
,i_Coach_leaderboards.POINTS
,i_Coach_leaderboards.STANDING
,i_Coach_leaderboards.ENTRY_USER_ID
,i_Coach_leaderboards.ENTRY_DATE
,i_Coach_leaderboards.OWNER_ID
,i_Coach_leaderboards.DESCRIPTION
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_leaderboards");}
}
public void Edit_Player_leaderboards(Player_leaderboards i_Player_leaderboards) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Player_leaderboards.PLAYER_LEADERBOARDS_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_leaderboards");}
#region Body Section.
if ((i_Player_leaderboards.PLAYER_LEADERBOARDS_ID == null) || (i_Player_leaderboards.PLAYER_LEADERBOARDS_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Player_leaderboards"); }
i_Player_leaderboards.ENTRY_USER_ID = this.UserID;
i_Player_leaderboards.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Player_leaderboards.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Player_leaderboards_Execution)
{
_Stop_Edit_Player_leaderboards_Execution = false;
return;
}
i_Player_leaderboards.PLAYER_LEADERBOARDS_ID = _AppContext.Edit_Player_leaderboards
(
i_Player_leaderboards.PLAYER_LEADERBOARDS_ID
,i_Player_leaderboards.PLAYER_ID
,i_Player_leaderboards.POINTS
,i_Player_leaderboards.STANDING
,i_Player_leaderboards.ENTRY_USER_ID
,i_Player_leaderboards.ENTRY_DATE
,i_Player_leaderboards.OWNER_ID
,i_Player_leaderboards.DESCRIPTION
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_leaderboards");}
}
public void Edit_Playersport(Playersport i_Playersport) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Playersport.PLAYERSPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Playersport");}
#region Body Section.
if ((i_Playersport.PLAYERSPORT_ID == null) || (i_Playersport.PLAYERSPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Playersport"); }
i_Playersport.ENTRY_USER_ID = this.UserID;
i_Playersport.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Playersport.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Playersport_Execution)
{
_Stop_Edit_Playersport_Execution = false;
return;
}
i_Playersport.PLAYERSPORT_ID = _AppContext.Edit_Playersport
(
i_Playersport.PLAYERSPORT_ID
,i_Playersport.PLAYER_ID
,i_Playersport.SPORT_ID
,i_Playersport.DESCRIPTION
,i_Playersport.ENTRY_USER_ID
,i_Playersport.ENTRY_DATE
,i_Playersport.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Playersport");}
}
public void Edit_Sport(Sport i_Sport) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Sport.SPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport");}
#region Body Section.
if ((i_Sport.SPORT_ID == null) || (i_Sport.SPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Sport"); }
i_Sport.ENTRY_USER_ID = this.UserID;
i_Sport.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Sport.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Sport
if (OnPreEvent_Edit_Sport != null)
{
OnPreEvent_Edit_Sport(i_Sport,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Sport_Execution)
{
_Stop_Edit_Sport_Execution = false;
return;
}
i_Sport.SPORT_ID = _AppContext.Edit_Sport
(
i_Sport.SPORT_ID
,i_Sport.SPORT_NAME
,i_Sport.DESCRIPTION
,i_Sport.ENTRY_USER_ID
,i_Sport.ENTRY_DATE
,i_Sport.OWNER_ID
);
#region PostEvent_Edit_Sport
if (OnPostEvent_Edit_Sport != null)
{
OnPostEvent_Edit_Sport(i_Sport,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport");}
}
public void Edit_Coachsport(Coachsport i_Coachsport) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Coachsport.COACHSPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coachsport");}
#region Body Section.
if ((i_Coachsport.COACHSPORT_ID == null) || (i_Coachsport.COACHSPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Coachsport"); }
i_Coachsport.ENTRY_USER_ID = this.UserID;
i_Coachsport.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Coachsport.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Coachsport
if (OnPreEvent_Edit_Coachsport != null)
{
OnPreEvent_Edit_Coachsport(i_Coachsport,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Coachsport_Execution)
{
_Stop_Edit_Coachsport_Execution = false;
return;
}
i_Coachsport.COACHSPORT_ID = _AppContext.Edit_Coachsport
(
i_Coachsport.COACHSPORT_ID
,i_Coachsport.SPORT_ID
,i_Coachsport.COACH_ID
,i_Coachsport.DESCRIPTION
,i_Coachsport.ENTRY_USER_ID
,i_Coachsport.ENTRY_DATE
,i_Coachsport.OWNER_ID
);
#region PostEvent_Edit_Coachsport
if (OnPostEvent_Edit_Coachsport != null)
{
OnPostEvent_Edit_Coachsport(i_Coachsport,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coachsport");}
}
public void Edit_Coach_evaluation(Coach_evaluation i_Coach_evaluation) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Coach_evaluation.COACH_EVALUATION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_evaluation");}
#region Body Section.
if ((i_Coach_evaluation.COACH_EVALUATION_ID == null) || (i_Coach_evaluation.COACH_EVALUATION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Coach_evaluation"); }
i_Coach_evaluation.ENTRY_USER_ID = this.UserID;
i_Coach_evaluation.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Coach_evaluation.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Coach_evaluation_Execution)
{
_Stop_Edit_Coach_evaluation_Execution = false;
return;
}
i_Coach_evaluation.COACH_EVALUATION_ID = _AppContext.Edit_Coach_evaluation
(
i_Coach_evaluation.COACH_EVALUATION_ID
,i_Coach_evaluation.PLAYER_ID
,i_Coach_evaluation.COACH_ID
,i_Coach_evaluation.RATING
,i_Coach_evaluation.DESCRIPTION
,i_Coach_evaluation.ENTRY_USER_ID
,i_Coach_evaluation.ENTRY_DATE
,i_Coach_evaluation.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_evaluation");}
}
public void Edit_Currency(Currency i_Currency) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Currency.CURRENCY_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Currency");}
#region Body Section.
if ((i_Currency.CURRENCY_ID == null) || (i_Currency.CURRENCY_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Currency"); }
i_Currency.ENTRY_USER_ID = this.UserID;
i_Currency.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Currency.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Currency_Execution)
{
_Stop_Edit_Currency_Execution = false;
return;
}
i_Currency.CURRENCY_ID = _AppContext.Edit_Currency
(
i_Currency.CURRENCY_ID
,i_Currency.CURRENCY_NAME
,i_Currency.TO_USD
,i_Currency.ENTRY_USER_ID
,i_Currency.ENTRY_DATE
,i_Currency.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Currency");}
}
public void Edit_Session_evaluation(Session_evaluation i_Session_evaluation) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Session_evaluation.SESSION_EVALUATION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Session_evaluation");}
#region Body Section.
if ((i_Session_evaluation.SESSION_EVALUATION_ID == null) || (i_Session_evaluation.SESSION_EVALUATION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Session_evaluation"); }
i_Session_evaluation.ENTRY_USER_ID = this.UserID;
i_Session_evaluation.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Session_evaluation.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Session_evaluation
if (OnPreEvent_Edit_Session_evaluation != null)
{
OnPreEvent_Edit_Session_evaluation(i_Session_evaluation,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Session_evaluation_Execution)
{
_Stop_Edit_Session_evaluation_Execution = false;
return;
}
i_Session_evaluation.SESSION_EVALUATION_ID = _AppContext.Edit_Session_evaluation
(
i_Session_evaluation.SESSION_EVALUATION_ID
,i_Session_evaluation.COACH_ID
,i_Session_evaluation.PLAYER_ID
,i_Session_evaluation.SESSION_RATING
,i_Session_evaluation.DESCRIPTION
,i_Session_evaluation.ENTRY_USER_ID
,i_Session_evaluation.ENTRY_DATE
,i_Session_evaluation.OWNER_ID
);
#region PostEvent_Edit_Session_evaluation
if (OnPostEvent_Edit_Session_evaluation != null)
{
OnPostEvent_Edit_Session_evaluation(i_Session_evaluation,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Session_evaluation");}
}
public void Edit_Taken_session(Taken_session i_Taken_session) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Taken_session.TAKEN_SESSION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Taken_session");}
#region Body Section.
if ((i_Taken_session.TAKEN_SESSION_ID == null) || (i_Taken_session.TAKEN_SESSION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Taken_session"); }
i_Taken_session.ENTRY_USER_ID = this.UserID;
i_Taken_session.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Taken_session.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Taken_session_Execution)
{
_Stop_Edit_Taken_session_Execution = false;
return;
}
i_Taken_session.TAKEN_SESSION_ID = _AppContext.Edit_Taken_session
(
i_Taken_session.TAKEN_SESSION_ID
,i_Taken_session.COACH_ID
,i_Taken_session.PLAYER_ID
,i_Taken_session.SPORT_ID
,i_Taken_session.DATETIME
,i_Taken_session.ENTRY_USER_ID
,i_Taken_session.ENTRY_DATE
,i_Taken_session.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Taken_session");}
}
public void Edit_Scheduled_session(Scheduled_session i_Scheduled_session) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Scheduled_session.SCHEDULED_SESSION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Scheduled_session");}
#region Body Section.
if ((i_Scheduled_session.SCHEDULED_SESSION_ID == null) || (i_Scheduled_session.SCHEDULED_SESSION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Scheduled_session"); }
i_Scheduled_session.ENTRY_USER_ID = this.UserID;
i_Scheduled_session.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Scheduled_session.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Scheduled_session
if (OnPreEvent_Edit_Scheduled_session != null)
{
OnPreEvent_Edit_Scheduled_session(i_Scheduled_session,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Scheduled_session_Execution)
{
_Stop_Edit_Scheduled_session_Execution = false;
return;
}
i_Scheduled_session.SCHEDULED_SESSION_ID = _AppContext.Edit_Scheduled_session
(
i_Scheduled_session.SCHEDULED_SESSION_ID
,i_Scheduled_session.PLAYER_ID
,i_Scheduled_session.COACH_ID
,i_Scheduled_session.SPORT_ID
,i_Scheduled_session.DATE_TIME
,i_Scheduled_session.DESCRIPTION
,i_Scheduled_session.ENTRY_USER_ID
,i_Scheduled_session.ENTRY_DATE
,i_Scheduled_session.OWNER_ID
);
#region PostEvent_Edit_Scheduled_session
if (OnPostEvent_Edit_Scheduled_session != null)
{
OnPostEvent_Edit_Scheduled_session(i_Scheduled_session,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Scheduled_session");}
}
public void Edit_Notification(Notification i_Notification) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Notification.NOTIFICATION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Notification");}
#region Body Section.
if ((i_Notification.NOTIFICATION_ID == null) || (i_Notification.NOTIFICATION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Notification"); }
i_Notification.ENTRY_USER_ID = this.UserID;
i_Notification.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Notification.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Notification_Execution)
{
_Stop_Edit_Notification_Execution = false;
return;
}
i_Notification.NOTIFICATION_ID = _AppContext.Edit_Notification
(
i_Notification.NOTIFICATION_ID
,i_Notification.USER_ID
,i_Notification.TITLE
,i_Notification.DESCRIPTION
,i_Notification.ENTRY_USER_ID
,i_Notification.ENTRY_DATE
,i_Notification.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Notification");}
}
public void Edit_Owner(Owner i_Owner) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Owner.OWNER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Owner");}
#region Body Section.
if ((i_Owner.OWNER_ID == null) || (i_Owner.OWNER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Owner"); }
i_Owner.ENTRY_DATE    = oTools.GetDateTimeString(DateTime.Now);
i_Owner.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Owner_Execution)
{
_Stop_Edit_Owner_Execution = false;
return;
}
i_Owner.OWNER_ID = _AppContext.Edit_Owner
(
i_Owner.OWNER_ID
,i_Owner.CODE
,i_Owner.MAINTENANCE_DUE_DATE
,i_Owner.DESCRIPTION
,i_Owner.ENTRY_DATE
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Owner");}
}
public void Edit_Comment(Comment i_Comment) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Comment.COMMENT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment");}
#region Body Section.
if ((i_Comment.COMMENT_ID == null) || (i_Comment.COMMENT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Comment"); }
i_Comment.ENTRY_USER_ID = this.UserID;
i_Comment.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Comment.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Comment_Execution)
{
_Stop_Edit_Comment_Execution = false;
return;
}
i_Comment.COMMENT_ID = _AppContext.Edit_Comment
(
i_Comment.COMMENT_ID
,i_Comment.PLAYER_ID
,i_Comment.COACH_ID
,i_Comment.IS_BLOCKED
,i_Comment.REPORTS
,i_Comment.TITLE
,i_Comment.DESCRIPTION
,i_Comment.ENTRY_USER_ID
,i_Comment.ENTRY_DATE
,i_Comment.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment");}
}
public void Edit_Report_coach(Report_coach i_Report_coach) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Report_coach.REPORT_COACH_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_coach");}
#region Body Section.
if ((i_Report_coach.REPORT_COACH_ID == null) || (i_Report_coach.REPORT_COACH_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Report_coach"); }
i_Report_coach.ENTRY_USER_ID = this.UserID;
i_Report_coach.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Report_coach.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Report_coach_Execution)
{
_Stop_Edit_Report_coach_Execution = false;
return;
}
i_Report_coach.REPORT_COACH_ID = _AppContext.Edit_Report_coach
(
i_Report_coach.REPORT_COACH_ID
,i_Report_coach.USER_ID
,i_Report_coach.COACH_ID
,i_Report_coach.DESCRIPTION
,i_Report_coach.ENTRY_USER_ID
,i_Report_coach.ENTRY_DATE
,i_Report_coach.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_coach");}
}
public void Edit_Comment_report(Comment_report i_Comment_report) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Comment_report.COMMENT_REPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment_report");}
#region Body Section.
if ((i_Comment_report.COMMENT_REPORT_ID == null) || (i_Comment_report.COMMENT_REPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Comment_report"); }
i_Comment_report.ENTRY_USER_ID = this.UserID;
i_Comment_report.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Comment_report.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Comment_report_Execution)
{
_Stop_Edit_Comment_report_Execution = false;
return;
}
i_Comment_report.COMMENT_REPORT_ID = _AppContext.Edit_Comment_report
(
i_Comment_report.COMMENT_REPORT_ID
,i_Comment_report.PLAYER_ID
,i_Comment_report.COACH_ID
,i_Comment_report.COMMENT_ID
,i_Comment_report.DESCRIPTION
,i_Comment_report.ENTRY_USER_ID
,i_Comment_report.ENTRY_DATE
,i_Comment_report.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment_report");}
}
public void Edit_User(User i_User) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_User.USER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_User");}
#region Body Section.
if ((i_User.USER_ID == null) || (i_User.USER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_User"); }
i_User.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_User.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_User_Execution)
{
_Stop_Edit_User_Execution = false;
return;
}
i_User.USER_ID = _AppContext.Edit_User
(
i_User.USER_ID
,i_User.OWNER_ID
,i_User.USERNAME
,i_User.PASSWORD
,i_User.USER_TYPE_CODE
,i_User.IS_LOGGED_IN
,i_User.IS_ACTIVE
,i_User.ENTRY_DATE
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_User");}
}
public void Edit_Direct_message(Direct_message i_Direct_message) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Direct_message.DIRECT_MESSAGE_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Direct_message");}
#region Body Section.
if ((i_Direct_message.DIRECT_MESSAGE_ID == null) || (i_Direct_message.DIRECT_MESSAGE_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Direct_message"); }
i_Direct_message.ENTRY_USER_ID = this.UserID;
i_Direct_message.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Direct_message.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Direct_message_Execution)
{
_Stop_Edit_Direct_message_Execution = false;
return;
}
i_Direct_message.DIRECT_MESSAGE_ID = _AppContext.Edit_Direct_message
(
i_Direct_message.DIRECT_MESSAGE_ID
,i_Direct_message.AUTHOR_ID
,i_Direct_message.RECIPIENT_ID
,i_Direct_message.DESCRIPTION
,i_Direct_message.IS_DELETED_BY_RECIPIENT
,i_Direct_message.DATETIME
,i_Direct_message.ENTRY_USER_ID
,i_Direct_message.ENTRY_DATE
,i_Direct_message.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Direct_message");}
}
public void Edit_Report_player(Report_player i_Report_player) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Report_player.REPORT_PLAYER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_player");}
#region Body Section.
if ((i_Report_player.REPORT_PLAYER_ID == null) || (i_Report_player.REPORT_PLAYER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Report_player"); }
i_Report_player.ENTRY_USER_ID = this.UserID;
i_Report_player.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Report_player.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Report_player_Execution)
{
_Stop_Edit_Report_player_Execution = false;
return;
}
i_Report_player.REPORT_PLAYER_ID = _AppContext.Edit_Report_player
(
i_Report_player.REPORT_PLAYER_ID
,i_Report_player.USER_ID
,i_Report_player.PLAYER_ID
,i_Report_player.DESCRIPTION
,i_Report_player.ENTRY_USER_ID
,i_Report_player.ENTRY_DATE
,i_Report_player.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_player");}
}
public void Edit_Coach(Coach i_Coach) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Coach.COACH_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach");}
#region Body Section.
if ((i_Coach.COACH_ID == null) || (i_Coach.COACH_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Coach"); }
i_Coach.ENTRY_USER_ID = this.UserID;
i_Coach.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Coach.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Coach
if (OnPreEvent_Edit_Coach != null)
{
OnPreEvent_Edit_Coach(i_Coach,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Coach_Execution)
{
_Stop_Edit_Coach_Execution = false;
return;
}
i_Coach.COACH_ID = _AppContext.Edit_Coach
(
i_Coach.COACH_ID
,i_Coach.USER_ID
,i_Coach.FIRSTNAME
,i_Coach.LASTNAME
,i_Coach.PRICE_PER_SESSION
,i_Coach.EMAIL
,i_Coach.MOBILE
,i_Coach.AGE
,i_Coach.GEO_LOCATION
,i_Coach.SCORE
,i_Coach.SESSIONS_COMPLETED
,i_Coach.REPORT
,i_Coach.IS_BLOCKED
,i_Coach.ENTRY_USER_ID
,i_Coach.ENTRY_DATE
,i_Coach.OWNER_ID
);
#region PostEvent_Edit_Coach
if (OnPostEvent_Edit_Coach != null)
{
OnPostEvent_Edit_Coach(i_Coach,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach");}
}
public void Edit_Player(Player i_Player) 
{
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Player.PLAYER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player");}
#region Body Section.
if ((i_Player.PLAYER_ID == null) || (i_Player.PLAYER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Player"); }
i_Player.ENTRY_USER_ID = this.UserID;
i_Player.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Player.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Player
if (OnPreEvent_Edit_Player != null)
{
OnPreEvent_Edit_Player(i_Player,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Player_Execution)
{
_Stop_Edit_Player_Execution = false;
return;
}
i_Player.PLAYER_ID = _AppContext.Edit_Player
(
i_Player.PLAYER_ID
,i_Player.FIRSTNAME
,i_Player.LASTNAME
,i_Player.USER_ID
,i_Player.EMAIL
,i_Player.MOBILE
,i_Player.AGE
,i_Player.GEO_LOCATION
,i_Player.SESSIONS_COMPLETED
,i_Player.IS_BLOCKED
,i_Player.REPORTS
,i_Player.ENTRY_USER_ID
,i_Player.ENTRY_DATE
,i_Player.OWNER_ID
);
#region PostEvent_Edit_Player
if (OnPostEvent_Edit_Player != null)
{
OnPostEvent_Edit_Player(i_Player,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player");}
}
public void Edit_Coach_leaderboards_List(List<Coach_leaderboards> i_List_Coach_leaderboards)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_leaderboards_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Coach_leaderboards != null)
{
foreach (var oRow in i_List_Coach_leaderboards)
{
Edit_Coach_leaderboards(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_leaderboards_List");}
}
public void Edit_Coach_leaderboards_List(Params_Edit_Coach_leaderboards_List i_Params_Edit_Coach_leaderboards_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_leaderboards_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Coach_leaderboards_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Coach_leaderboards_List.My_List_To_Delete)
{
Delete_Coach_leaderboards(new Params_Delete_Coach_leaderboards() { COACH_LEADERBOARDS_ID = oRow.COACH_LEADERBOARDS_ID });
}
}
if (i_Params_Edit_Coach_leaderboards_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Coach_leaderboards_List.My_List_To_Edit)
{
Edit_Coach_leaderboards(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_leaderboards_List");}
}
public void Edit_Player_leaderboards_List(List<Player_leaderboards> i_List_Player_leaderboards)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_leaderboards_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Player_leaderboards != null)
{
foreach (var oRow in i_List_Player_leaderboards)
{
Edit_Player_leaderboards(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_leaderboards_List");}
}
public void Edit_Player_leaderboards_List(Params_Edit_Player_leaderboards_List i_Params_Edit_Player_leaderboards_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_leaderboards_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Player_leaderboards_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Player_leaderboards_List.My_List_To_Delete)
{
Delete_Player_leaderboards(new Params_Delete_Player_leaderboards() { PLAYER_LEADERBOARDS_ID = oRow.PLAYER_LEADERBOARDS_ID });
}
}
if (i_Params_Edit_Player_leaderboards_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Player_leaderboards_List.My_List_To_Edit)
{
Edit_Player_leaderboards(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_leaderboards_List");}
}
public void Edit_Playersport_List(List<Playersport> i_List_Playersport)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Playersport_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Playersport != null)
{
foreach (var oRow in i_List_Playersport)
{
Edit_Playersport(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Playersport_List");}
}
public void Edit_Playersport_List(Params_Edit_Playersport_List i_Params_Edit_Playersport_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Playersport_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Playersport_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Playersport_List.My_List_To_Delete)
{
Delete_Playersport(new Params_Delete_Playersport() { PLAYERSPORT_ID = oRow.PLAYERSPORT_ID });
}
}
if (i_Params_Edit_Playersport_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Playersport_List.My_List_To_Edit)
{
Edit_Playersport(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Playersport_List");}
}
public void Edit_Sport_List(List<Sport> i_List_Sport)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Sport != null)
{
foreach (var oRow in i_List_Sport)
{
Edit_Sport(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport_List");}
}
public void Edit_Sport_List(Params_Edit_Sport_List i_Params_Edit_Sport_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Sport_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Sport_List.My_List_To_Delete)
{
Delete_Sport(new Params_Delete_Sport() { SPORT_ID = oRow.SPORT_ID });
}
}
if (i_Params_Edit_Sport_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Sport_List.My_List_To_Edit)
{
Edit_Sport(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport_List");}
}
public void Edit_Coachsport_List(List<Coachsport> i_List_Coachsport)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coachsport_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Coachsport != null)
{
foreach (var oRow in i_List_Coachsport)
{
Edit_Coachsport(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coachsport_List");}
}
public void Edit_Coachsport_List(Params_Edit_Coachsport_List i_Params_Edit_Coachsport_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coachsport_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Coachsport_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Coachsport_List.My_List_To_Delete)
{
Delete_Coachsport(new Params_Delete_Coachsport() { COACHSPORT_ID = oRow.COACHSPORT_ID });
}
}
if (i_Params_Edit_Coachsport_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Coachsport_List.My_List_To_Edit)
{
Edit_Coachsport(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coachsport_List");}
}
public void Edit_Coach_evaluation_List(List<Coach_evaluation> i_List_Coach_evaluation)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_evaluation_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Coach_evaluation != null)
{
foreach (var oRow in i_List_Coach_evaluation)
{
Edit_Coach_evaluation(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_evaluation_List");}
}
public void Edit_Coach_evaluation_List(Params_Edit_Coach_evaluation_List i_Params_Edit_Coach_evaluation_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_evaluation_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Coach_evaluation_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Coach_evaluation_List.My_List_To_Delete)
{
Delete_Coach_evaluation(new Params_Delete_Coach_evaluation() { COACH_EVALUATION_ID = oRow.COACH_EVALUATION_ID });
}
}
if (i_Params_Edit_Coach_evaluation_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Coach_evaluation_List.My_List_To_Edit)
{
Edit_Coach_evaluation(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_evaluation_List");}
}
public void Edit_Currency_List(List<Currency> i_List_Currency)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Currency_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Currency != null)
{
foreach (var oRow in i_List_Currency)
{
Edit_Currency(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Currency_List");}
}
public void Edit_Currency_List(Params_Edit_Currency_List i_Params_Edit_Currency_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Currency_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Currency_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Currency_List.My_List_To_Delete)
{
Delete_Currency(new Params_Delete_Currency() { CURRENCY_ID = oRow.CURRENCY_ID });
}
}
if (i_Params_Edit_Currency_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Currency_List.My_List_To_Edit)
{
Edit_Currency(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Currency_List");}
}
public void Edit_Session_evaluation_List(List<Session_evaluation> i_List_Session_evaluation)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Session_evaluation_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Session_evaluation != null)
{
foreach (var oRow in i_List_Session_evaluation)
{
Edit_Session_evaluation(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Session_evaluation_List");}
}
public void Edit_Session_evaluation_List(Params_Edit_Session_evaluation_List i_Params_Edit_Session_evaluation_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Session_evaluation_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Session_evaluation_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Session_evaluation_List.My_List_To_Delete)
{
Delete_Session_evaluation(new Params_Delete_Session_evaluation() { SESSION_EVALUATION_ID = oRow.SESSION_EVALUATION_ID });
}
}
if (i_Params_Edit_Session_evaluation_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Session_evaluation_List.My_List_To_Edit)
{
Edit_Session_evaluation(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Session_evaluation_List");}
}
public void Edit_Taken_session_List(List<Taken_session> i_List_Taken_session)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Taken_session_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Taken_session != null)
{
foreach (var oRow in i_List_Taken_session)
{
Edit_Taken_session(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Taken_session_List");}
}
public void Edit_Taken_session_List(Params_Edit_Taken_session_List i_Params_Edit_Taken_session_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Taken_session_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Taken_session_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Taken_session_List.My_List_To_Delete)
{
Delete_Taken_session(new Params_Delete_Taken_session() { TAKEN_SESSION_ID = oRow.TAKEN_SESSION_ID });
}
}
if (i_Params_Edit_Taken_session_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Taken_session_List.My_List_To_Edit)
{
Edit_Taken_session(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Taken_session_List");}
}
public void Edit_Scheduled_session_List(List<Scheduled_session> i_List_Scheduled_session)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Scheduled_session_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Scheduled_session != null)
{
foreach (var oRow in i_List_Scheduled_session)
{
Edit_Scheduled_session(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Scheduled_session_List");}
}
public void Edit_Scheduled_session_List(Params_Edit_Scheduled_session_List i_Params_Edit_Scheduled_session_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Scheduled_session_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Scheduled_session_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Scheduled_session_List.My_List_To_Delete)
{
Delete_Scheduled_session(new Params_Delete_Scheduled_session() { SCHEDULED_SESSION_ID = oRow.SCHEDULED_SESSION_ID });
}
}
if (i_Params_Edit_Scheduled_session_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Scheduled_session_List.My_List_To_Edit)
{
Edit_Scheduled_session(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Scheduled_session_List");}
}
public void Edit_Notification_List(List<Notification> i_List_Notification)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Notification_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Notification != null)
{
foreach (var oRow in i_List_Notification)
{
Edit_Notification(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Notification_List");}
}
public void Edit_Notification_List(Params_Edit_Notification_List i_Params_Edit_Notification_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Notification_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Notification_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Notification_List.My_List_To_Delete)
{
Delete_Notification(new Params_Delete_Notification() { NOTIFICATION_ID = oRow.NOTIFICATION_ID });
}
}
if (i_Params_Edit_Notification_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Notification_List.My_List_To_Edit)
{
Edit_Notification(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Notification_List");}
}
public void Edit_Owner_List(List<Owner> i_List_Owner)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Owner_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Owner != null)
{
foreach (var oRow in i_List_Owner)
{
Edit_Owner(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Owner_List");}
}
public void Edit_Owner_List(Params_Edit_Owner_List i_Params_Edit_Owner_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Owner_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Owner_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Owner_List.My_List_To_Delete)
{
Delete_Owner(new Params_Delete_Owner() { OWNER_ID = oRow.OWNER_ID });
}
}
if (i_Params_Edit_Owner_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Owner_List.My_List_To_Edit)
{
Edit_Owner(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Owner_List");}
}
public void Edit_Comment_List(List<Comment> i_List_Comment)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Comment != null)
{
foreach (var oRow in i_List_Comment)
{
Edit_Comment(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment_List");}
}
public void Edit_Comment_List(Params_Edit_Comment_List i_Params_Edit_Comment_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Comment_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Comment_List.My_List_To_Delete)
{
Delete_Comment(new Params_Delete_Comment() { COMMENT_ID = oRow.COMMENT_ID });
}
}
if (i_Params_Edit_Comment_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Comment_List.My_List_To_Edit)
{
Edit_Comment(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment_List");}
}
public void Edit_Report_coach_List(List<Report_coach> i_List_Report_coach)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_coach_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Report_coach != null)
{
foreach (var oRow in i_List_Report_coach)
{
Edit_Report_coach(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_coach_List");}
}
public void Edit_Report_coach_List(Params_Edit_Report_coach_List i_Params_Edit_Report_coach_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_coach_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Report_coach_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Report_coach_List.My_List_To_Delete)
{
Delete_Report_coach(new Params_Delete_Report_coach() { REPORT_COACH_ID = oRow.REPORT_COACH_ID });
}
}
if (i_Params_Edit_Report_coach_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Report_coach_List.My_List_To_Edit)
{
Edit_Report_coach(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_coach_List");}
}
public void Edit_Comment_report_List(List<Comment_report> i_List_Comment_report)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Comment_report != null)
{
foreach (var oRow in i_List_Comment_report)
{
Edit_Comment_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment_report_List");}
}
public void Edit_Comment_report_List(Params_Edit_Comment_report_List i_Params_Edit_Comment_report_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Comment_report_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Comment_report_List.My_List_To_Delete)
{
Delete_Comment_report(new Params_Delete_Comment_report() { COMMENT_REPORT_ID = oRow.COMMENT_REPORT_ID });
}
}
if (i_Params_Edit_Comment_report_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Comment_report_List.My_List_To_Edit)
{
Edit_Comment_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment_report_List");}
}
public void Edit_User_List(List<User> i_List_User)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_User_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_User != null)
{
foreach (var oRow in i_List_User)
{
Edit_User(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_User_List");}
}
public void Edit_User_List(Params_Edit_User_List i_Params_Edit_User_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_User_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_User_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_User_List.My_List_To_Delete)
{
Delete_User(new Params_Delete_User() { USER_ID = oRow.USER_ID });
}
}
if (i_Params_Edit_User_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_User_List.My_List_To_Edit)
{
Edit_User(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_User_List");}
}
public void Edit_Direct_message_List(List<Direct_message> i_List_Direct_message)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Direct_message_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Direct_message != null)
{
foreach (var oRow in i_List_Direct_message)
{
Edit_Direct_message(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Direct_message_List");}
}
public void Edit_Direct_message_List(Params_Edit_Direct_message_List i_Params_Edit_Direct_message_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Direct_message_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Direct_message_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Direct_message_List.My_List_To_Delete)
{
Delete_Direct_message(new Params_Delete_Direct_message() { DIRECT_MESSAGE_ID = oRow.DIRECT_MESSAGE_ID });
}
}
if (i_Params_Edit_Direct_message_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Direct_message_List.My_List_To_Edit)
{
Edit_Direct_message(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Direct_message_List");}
}
public void Edit_Report_player_List(List<Report_player> i_List_Report_player)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_player_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Report_player != null)
{
foreach (var oRow in i_List_Report_player)
{
Edit_Report_player(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_player_List");}
}
public void Edit_Report_player_List(Params_Edit_Report_player_List i_Params_Edit_Report_player_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_player_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Report_player_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Report_player_List.My_List_To_Delete)
{
Delete_Report_player(new Params_Delete_Report_player() { REPORT_PLAYER_ID = oRow.REPORT_PLAYER_ID });
}
}
if (i_Params_Edit_Report_player_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Report_player_List.My_List_To_Edit)
{
Edit_Report_player(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_player_List");}
}
public void Edit_Coach_List(List<Coach> i_List_Coach)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Coach != null)
{
foreach (var oRow in i_List_Coach)
{
Edit_Coach(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_List");}
}
public void Edit_Coach_List(Params_Edit_Coach_List i_Params_Edit_Coach_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Coach_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Coach_List.My_List_To_Delete)
{
Delete_Coach(new Params_Delete_Coach() { COACH_ID = oRow.COACH_ID });
}
}
if (i_Params_Edit_Coach_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Coach_List.My_List_To_Edit)
{
Edit_Coach(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_List");}
}
public void Edit_Player_List(List<Player> i_List_Player)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Player != null)
{
foreach (var oRow in i_List_Player)
{
Edit_Player(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_List");}
}
public void Edit_Player_List(Params_Edit_Player_List i_Params_Edit_Player_List)
{
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Player_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Player_List.My_List_To_Delete)
{
Delete_Player(new Params_Delete_Player() { PLAYER_ID = oRow.PLAYER_ID });
}
}
if (i_Params_Edit_Player_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Player_List.My_List_To_Edit)
{
Edit_Player(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_List");}
}
}
}
