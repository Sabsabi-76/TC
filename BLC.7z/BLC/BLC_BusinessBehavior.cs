using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
public partial class BLC
{
#region Reset_Coachsport_By_Sport
public void Reset_Coachsport_By_Sport(Sport i_Sport, List<Coachsport> i_Coachsport_List)
{
#region Declaration And Initialization Section.
Params_Delete_Coachsport_By_SPORT_ID oParams_Delete_Coachsport_By_SPORT_ID = new Params_Delete_Coachsport_By_SPORT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coachsport_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Coachsport
//---------------------------------
oParams_Delete_Coachsport_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Coachsport_By_SPORT_ID(oParams_Delete_Coachsport_By_SPORT_ID);
//---------------------------------
// Edit Coachsport
//---------------------------------
Edit_Sport_WithCoachsport(i_Sport, i_Coachsport_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coachsport_By_Sport");}
}
#endregion
#region Reset_Coachsport_By_Sport
public void Reset_Coachsport_By_Sport(Sport i_Sport, List<Coachsport> i_Coachsport_List_To_Delete,List<Coachsport> i_Coachsport_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Coachsport oParams_Delete_Coachsport = new Params_Delete_Coachsport();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coachsport_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Coachsport_List_To_Delete != null)
{
foreach (var oRow in i_Coachsport_List_To_Delete)
{
oParams_Delete_Coachsport.COACHSPORT_ID = oRow.COACHSPORT_ID;
Delete_Coachsport(oParams_Delete_Coachsport);
}
}
//---------------------------------
// Edit Coachsport
//---------------------------------
Edit_Sport_WithCoachsport(i_Sport, i_Coachsport_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coachsport_By_Sport");}
}
#endregion
#region Edit_Sport_With_Coachsport(Sport i_Sport,List<Coachsport> i_CoachsportList)
public void Edit_Sport_WithCoachsport(Sport i_Sport,List<Coachsport> i_List_Coachsport)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport_WithCoachsport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Sport(i_Sport);
if (i_List_Coachsport != null)
{
foreach(Coachsport oCoachsport in i_List_Coachsport)
{
oCoachsport.SPORT_ID = i_Sport.SPORT_ID;
Edit_Coachsport(oCoachsport);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport_WithCoachsport");}
}
#endregion
#region Reset_Playersport_By_Sport
public void Reset_Playersport_By_Sport(Sport i_Sport, List<Playersport> i_Playersport_List)
{
#region Declaration And Initialization Section.
Params_Delete_Playersport_By_SPORT_ID oParams_Delete_Playersport_By_SPORT_ID = new Params_Delete_Playersport_By_SPORT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Playersport_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Playersport
//---------------------------------
oParams_Delete_Playersport_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Playersport_By_SPORT_ID(oParams_Delete_Playersport_By_SPORT_ID);
//---------------------------------
// Edit Playersport
//---------------------------------
Edit_Sport_WithPlayersport(i_Sport, i_Playersport_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Playersport_By_Sport");}
}
#endregion
#region Reset_Playersport_By_Sport
public void Reset_Playersport_By_Sport(Sport i_Sport, List<Playersport> i_Playersport_List_To_Delete,List<Playersport> i_Playersport_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Playersport oParams_Delete_Playersport = new Params_Delete_Playersport();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Playersport_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Playersport_List_To_Delete != null)
{
foreach (var oRow in i_Playersport_List_To_Delete)
{
oParams_Delete_Playersport.PLAYERSPORT_ID = oRow.PLAYERSPORT_ID;
Delete_Playersport(oParams_Delete_Playersport);
}
}
//---------------------------------
// Edit Playersport
//---------------------------------
Edit_Sport_WithPlayersport(i_Sport, i_Playersport_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Playersport_By_Sport");}
}
#endregion
#region Edit_Sport_With_Playersport(Sport i_Sport,List<Playersport> i_PlayersportList)
public void Edit_Sport_WithPlayersport(Sport i_Sport,List<Playersport> i_List_Playersport)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport_WithPlayersport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Sport(i_Sport);
if (i_List_Playersport != null)
{
foreach(Playersport oPlayersport in i_List_Playersport)
{
oPlayersport.SPORT_ID = i_Sport.SPORT_ID;
Edit_Playersport(oPlayersport);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport_WithPlayersport");}
}
#endregion
#region Reset_Scheduled_session_By_Sport
public void Reset_Scheduled_session_By_Sport(Sport i_Sport, List<Scheduled_session> i_Scheduled_session_List)
{
#region Declaration And Initialization Section.
Params_Delete_Scheduled_session_By_SPORT_ID oParams_Delete_Scheduled_session_By_SPORT_ID = new Params_Delete_Scheduled_session_By_SPORT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Scheduled_session_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Scheduled_session
//---------------------------------
oParams_Delete_Scheduled_session_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Scheduled_session_By_SPORT_ID(oParams_Delete_Scheduled_session_By_SPORT_ID);
//---------------------------------
// Edit Scheduled_session
//---------------------------------
Edit_Sport_WithScheduled_session(i_Sport, i_Scheduled_session_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Scheduled_session_By_Sport");}
}
#endregion
#region Reset_Scheduled_session_By_Sport
public void Reset_Scheduled_session_By_Sport(Sport i_Sport, List<Scheduled_session> i_Scheduled_session_List_To_Delete,List<Scheduled_session> i_Scheduled_session_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Scheduled_session oParams_Delete_Scheduled_session = new Params_Delete_Scheduled_session();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Scheduled_session_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Scheduled_session_List_To_Delete != null)
{
foreach (var oRow in i_Scheduled_session_List_To_Delete)
{
oParams_Delete_Scheduled_session.SCHEDULED_SESSION_ID = oRow.SCHEDULED_SESSION_ID;
Delete_Scheduled_session(oParams_Delete_Scheduled_session);
}
}
//---------------------------------
// Edit Scheduled_session
//---------------------------------
Edit_Sport_WithScheduled_session(i_Sport, i_Scheduled_session_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Scheduled_session_By_Sport");}
}
#endregion
#region Edit_Sport_With_Scheduled_session(Sport i_Sport,List<Scheduled_session> i_Scheduled_sessionList)
public void Edit_Sport_WithScheduled_session(Sport i_Sport,List<Scheduled_session> i_List_Scheduled_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport_WithScheduled_session");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Sport(i_Sport);
if (i_List_Scheduled_session != null)
{
foreach(Scheduled_session oScheduled_session in i_List_Scheduled_session)
{
oScheduled_session.SPORT_ID = i_Sport.SPORT_ID;
Edit_Scheduled_session(oScheduled_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport_WithScheduled_session");}
}
#endregion
#region Reset_Taken_session_By_Sport
public void Reset_Taken_session_By_Sport(Sport i_Sport, List<Taken_session> i_Taken_session_List)
{
#region Declaration And Initialization Section.
Params_Delete_Taken_session_By_SPORT_ID oParams_Delete_Taken_session_By_SPORT_ID = new Params_Delete_Taken_session_By_SPORT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Taken_session_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Taken_session
//---------------------------------
oParams_Delete_Taken_session_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Taken_session_By_SPORT_ID(oParams_Delete_Taken_session_By_SPORT_ID);
//---------------------------------
// Edit Taken_session
//---------------------------------
Edit_Sport_WithTaken_session(i_Sport, i_Taken_session_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Taken_session_By_Sport");}
}
#endregion
#region Reset_Taken_session_By_Sport
public void Reset_Taken_session_By_Sport(Sport i_Sport, List<Taken_session> i_Taken_session_List_To_Delete,List<Taken_session> i_Taken_session_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Taken_session oParams_Delete_Taken_session = new Params_Delete_Taken_session();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Taken_session_By_Sport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Taken_session_List_To_Delete != null)
{
foreach (var oRow in i_Taken_session_List_To_Delete)
{
oParams_Delete_Taken_session.TAKEN_SESSION_ID = oRow.TAKEN_SESSION_ID;
Delete_Taken_session(oParams_Delete_Taken_session);
}
}
//---------------------------------
// Edit Taken_session
//---------------------------------
Edit_Sport_WithTaken_session(i_Sport, i_Taken_session_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Taken_session_By_Sport");}
}
#endregion
#region Edit_Sport_With_Taken_session(Sport i_Sport,List<Taken_session> i_Taken_sessionList)
public void Edit_Sport_WithTaken_session(Sport i_Sport,List<Taken_session> i_List_Taken_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport_WithTaken_session");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Sport(i_Sport);
if (i_List_Taken_session != null)
{
foreach(Taken_session oTaken_session in i_List_Taken_session)
{
oTaken_session.SPORT_ID = i_Sport.SPORT_ID;
Edit_Taken_session(oTaken_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport_WithTaken_session");}
}
#endregion
#region Edit_Sport_WithRelatedData(Sport i_Sport,List<Coachsport> i_List_Coachsport,List<Playersport> i_List_Playersport,List<Scheduled_session> i_List_Scheduled_session,List<Taken_session> i_List_Taken_session)
public void Edit_Sport_WithRelatedData(Sport i_Sport,List<Coachsport> i_List_Coachsport,List<Playersport> i_List_Playersport,List<Scheduled_session> i_List_Scheduled_session,List<Taken_session> i_List_Taken_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Sport_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Sport(i_Sport);
if (i_List_Coachsport != null)
{
foreach(Coachsport oCoachsport in i_List_Coachsport)
{
oCoachsport.SPORT_ID = i_Sport.SPORT_ID;
Edit_Coachsport(oCoachsport);
}
}
if (i_List_Playersport != null)
{
foreach(Playersport oPlayersport in i_List_Playersport)
{
oPlayersport.SPORT_ID = i_Sport.SPORT_ID;
Edit_Playersport(oPlayersport);
}
}
if (i_List_Scheduled_session != null)
{
foreach(Scheduled_session oScheduled_session in i_List_Scheduled_session)
{
oScheduled_session.SPORT_ID = i_Sport.SPORT_ID;
Edit_Scheduled_session(oScheduled_session);
}
}
if (i_List_Taken_session != null)
{
foreach(Taken_session oTaken_session in i_List_Taken_session)
{
oTaken_session.SPORT_ID = i_Sport.SPORT_ID;
Edit_Taken_session(oTaken_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Sport_WithRelatedData");}
}
#endregion
#region Delete_Sport_With_Children(Sport i_Sport)
public void Delete_Sport_With_Children(Sport i_Sport)
{
 #region Declaration And Initialization Section.
Params_Delete_Sport oParams_Delete_Sport = new Params_Delete_Sport();
Params_Delete_Coachsport_By_SPORT_ID oParams_Delete_Coachsport_By_SPORT_ID = new Params_Delete_Coachsport_By_SPORT_ID();
Params_Delete_Playersport_By_SPORT_ID oParams_Delete_Playersport_By_SPORT_ID = new Params_Delete_Playersport_By_SPORT_ID();
Params_Delete_Scheduled_session_By_SPORT_ID oParams_Delete_Scheduled_session_By_SPORT_ID = new Params_Delete_Scheduled_session_By_SPORT_ID();
Params_Delete_Taken_session_By_SPORT_ID oParams_Delete_Taken_session_By_SPORT_ID = new Params_Delete_Taken_session_By_SPORT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Sport_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Coachsport_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Coachsport_By_SPORT_ID(oParams_Delete_Coachsport_By_SPORT_ID);
oParams_Delete_Playersport_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Playersport_By_SPORT_ID(oParams_Delete_Playersport_By_SPORT_ID);
oParams_Delete_Scheduled_session_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Scheduled_session_By_SPORT_ID(oParams_Delete_Scheduled_session_By_SPORT_ID);
oParams_Delete_Taken_session_By_SPORT_ID.SPORT_ID = i_Sport.SPORT_ID;
Delete_Taken_session_By_SPORT_ID(oParams_Delete_Taken_session_By_SPORT_ID);
//-------------------------

//-------------------------
oParams_Delete_Sport.SPORT_ID = i_Sport.SPORT_ID;
Delete_Sport(oParams_Delete_Sport);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Sport_With_Children");}
}
#endregion
#region Reset_Comment_report_By_Comment
public void Reset_Comment_report_By_Comment(Comment i_Comment, List<Comment_report> i_Comment_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_report_By_COMMENT_ID oParams_Delete_Comment_report_By_COMMENT_ID = new Params_Delete_Comment_report_By_COMMENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_report_By_Comment");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Comment_report
//---------------------------------
oParams_Delete_Comment_report_By_COMMENT_ID.COMMENT_ID = i_Comment.COMMENT_ID;
Delete_Comment_report_By_COMMENT_ID(oParams_Delete_Comment_report_By_COMMENT_ID);
//---------------------------------
// Edit Comment_report
//---------------------------------
Edit_Comment_WithComment_report(i_Comment, i_Comment_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_report_By_Comment");}
}
#endregion
#region Reset_Comment_report_By_Comment
public void Reset_Comment_report_By_Comment(Comment i_Comment, List<Comment_report> i_Comment_report_List_To_Delete,List<Comment_report> i_Comment_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_report oParams_Delete_Comment_report = new Params_Delete_Comment_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_report_By_Comment");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Comment_report_List_To_Delete != null)
{
foreach (var oRow in i_Comment_report_List_To_Delete)
{
oParams_Delete_Comment_report.COMMENT_REPORT_ID = oRow.COMMENT_REPORT_ID;
Delete_Comment_report(oParams_Delete_Comment_report);
}
}
//---------------------------------
// Edit Comment_report
//---------------------------------
Edit_Comment_WithComment_report(i_Comment, i_Comment_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_report_By_Comment");}
}
#endregion
#region Edit_Comment_With_Comment_report(Comment i_Comment,List<Comment_report> i_Comment_reportList)
public void Edit_Comment_WithComment_report(Comment i_Comment,List<Comment_report> i_List_Comment_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment_WithComment_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Comment(i_Comment);
if (i_List_Comment_report != null)
{
foreach(Comment_report oComment_report in i_List_Comment_report)
{
oComment_report.COMMENT_ID = i_Comment.COMMENT_ID;
Edit_Comment_report(oComment_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment_WithComment_report");}
}
#endregion
#region Edit_Comment_WithRelatedData(Comment i_Comment,List<Comment_report> i_List_Comment_report)
public void Edit_Comment_WithRelatedData(Comment i_Comment,List<Comment_report> i_List_Comment_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Comment_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Comment(i_Comment);
if (i_List_Comment_report != null)
{
foreach(Comment_report oComment_report in i_List_Comment_report)
{
oComment_report.COMMENT_ID = i_Comment.COMMENT_ID;
Edit_Comment_report(oComment_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Comment_WithRelatedData");}
}
#endregion
#region Delete_Comment_With_Children(Comment i_Comment)
public void Delete_Comment_With_Children(Comment i_Comment)
{
 #region Declaration And Initialization Section.
Params_Delete_Comment oParams_Delete_Comment = new Params_Delete_Comment();
Params_Delete_Comment_report_By_COMMENT_ID oParams_Delete_Comment_report_By_COMMENT_ID = new Params_Delete_Comment_report_By_COMMENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Comment_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Comment_report_By_COMMENT_ID.COMMENT_ID = i_Comment.COMMENT_ID;
Delete_Comment_report_By_COMMENT_ID(oParams_Delete_Comment_report_By_COMMENT_ID);
//-------------------------

//-------------------------
oParams_Delete_Comment.COMMENT_ID = i_Comment.COMMENT_ID;
Delete_Comment(oParams_Delete_Comment);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Comment_With_Children");}
}
#endregion
#region Reset_Coach_evaluation_By_Coach
public void Reset_Coach_evaluation_By_Coach(Coach i_Coach, List<Coach_evaluation> i_Coach_evaluation_List)
{
#region Declaration And Initialization Section.
Params_Delete_Coach_evaluation_By_COACH_ID oParams_Delete_Coach_evaluation_By_COACH_ID = new Params_Delete_Coach_evaluation_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coach_evaluation_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Coach_evaluation
//---------------------------------
oParams_Delete_Coach_evaluation_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Coach_evaluation_By_COACH_ID(oParams_Delete_Coach_evaluation_By_COACH_ID);
//---------------------------------
// Edit Coach_evaluation
//---------------------------------
Edit_Coach_WithCoach_evaluation(i_Coach, i_Coach_evaluation_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coach_evaluation_By_Coach");}
}
#endregion
#region Reset_Coach_evaluation_By_Coach
public void Reset_Coach_evaluation_By_Coach(Coach i_Coach, List<Coach_evaluation> i_Coach_evaluation_List_To_Delete,List<Coach_evaluation> i_Coach_evaluation_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Coach_evaluation oParams_Delete_Coach_evaluation = new Params_Delete_Coach_evaluation();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coach_evaluation_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Coach_evaluation_List_To_Delete != null)
{
foreach (var oRow in i_Coach_evaluation_List_To_Delete)
{
oParams_Delete_Coach_evaluation.COACH_EVALUATION_ID = oRow.COACH_EVALUATION_ID;
Delete_Coach_evaluation(oParams_Delete_Coach_evaluation);
}
}
//---------------------------------
// Edit Coach_evaluation
//---------------------------------
Edit_Coach_WithCoach_evaluation(i_Coach, i_Coach_evaluation_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coach_evaluation_By_Coach");}
}
#endregion
#region Edit_Coach_With_Coach_evaluation(Coach i_Coach,List<Coach_evaluation> i_Coach_evaluationList)
public void Edit_Coach_WithCoach_evaluation(Coach i_Coach,List<Coach_evaluation> i_List_Coach_evaluation)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithCoach_evaluation");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Coach_evaluation != null)
{
foreach(Coach_evaluation oCoach_evaluation in i_List_Coach_evaluation)
{
oCoach_evaluation.COACH_ID = i_Coach.COACH_ID;
Edit_Coach_evaluation(oCoach_evaluation);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithCoach_evaluation");}
}
#endregion
#region Reset_Coach_leaderboards_By_Coach
public void Reset_Coach_leaderboards_By_Coach(Coach i_Coach, List<Coach_leaderboards> i_Coach_leaderboards_List)
{
#region Declaration And Initialization Section.
Params_Delete_Coach_leaderboards_By_COACH_ID oParams_Delete_Coach_leaderboards_By_COACH_ID = new Params_Delete_Coach_leaderboards_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coach_leaderboards_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Coach_leaderboards
//---------------------------------
oParams_Delete_Coach_leaderboards_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Coach_leaderboards_By_COACH_ID(oParams_Delete_Coach_leaderboards_By_COACH_ID);
//---------------------------------
// Edit Coach_leaderboards
//---------------------------------
Edit_Coach_WithCoach_leaderboards(i_Coach, i_Coach_leaderboards_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coach_leaderboards_By_Coach");}
}
#endregion
#region Reset_Coach_leaderboards_By_Coach
public void Reset_Coach_leaderboards_By_Coach(Coach i_Coach, List<Coach_leaderboards> i_Coach_leaderboards_List_To_Delete,List<Coach_leaderboards> i_Coach_leaderboards_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Coach_leaderboards oParams_Delete_Coach_leaderboards = new Params_Delete_Coach_leaderboards();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coach_leaderboards_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Coach_leaderboards_List_To_Delete != null)
{
foreach (var oRow in i_Coach_leaderboards_List_To_Delete)
{
oParams_Delete_Coach_leaderboards.COACH_LEADERBOARDS_ID = oRow.COACH_LEADERBOARDS_ID;
Delete_Coach_leaderboards(oParams_Delete_Coach_leaderboards);
}
}
//---------------------------------
// Edit Coach_leaderboards
//---------------------------------
Edit_Coach_WithCoach_leaderboards(i_Coach, i_Coach_leaderboards_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coach_leaderboards_By_Coach");}
}
#endregion
#region Edit_Coach_With_Coach_leaderboards(Coach i_Coach,List<Coach_leaderboards> i_Coach_leaderboardsList)
public void Edit_Coach_WithCoach_leaderboards(Coach i_Coach,List<Coach_leaderboards> i_List_Coach_leaderboards)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithCoach_leaderboards");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Coach_leaderboards != null)
{
foreach(Coach_leaderboards oCoach_leaderboards in i_List_Coach_leaderboards)
{
oCoach_leaderboards.COACH_ID = i_Coach.COACH_ID;
Edit_Coach_leaderboards(oCoach_leaderboards);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithCoach_leaderboards");}
}
#endregion
#region Reset_Coachsport_By_Coach
public void Reset_Coachsport_By_Coach(Coach i_Coach, List<Coachsport> i_Coachsport_List)
{
#region Declaration And Initialization Section.
Params_Delete_Coachsport_By_COACH_ID oParams_Delete_Coachsport_By_COACH_ID = new Params_Delete_Coachsport_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coachsport_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Coachsport
//---------------------------------
oParams_Delete_Coachsport_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Coachsport_By_COACH_ID(oParams_Delete_Coachsport_By_COACH_ID);
//---------------------------------
// Edit Coachsport
//---------------------------------
Edit_Coach_WithCoachsport(i_Coach, i_Coachsport_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coachsport_By_Coach");}
}
#endregion
#region Reset_Coachsport_By_Coach
public void Reset_Coachsport_By_Coach(Coach i_Coach, List<Coachsport> i_Coachsport_List_To_Delete,List<Coachsport> i_Coachsport_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Coachsport oParams_Delete_Coachsport = new Params_Delete_Coachsport();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coachsport_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Coachsport_List_To_Delete != null)
{
foreach (var oRow in i_Coachsport_List_To_Delete)
{
oParams_Delete_Coachsport.COACHSPORT_ID = oRow.COACHSPORT_ID;
Delete_Coachsport(oParams_Delete_Coachsport);
}
}
//---------------------------------
// Edit Coachsport
//---------------------------------
Edit_Coach_WithCoachsport(i_Coach, i_Coachsport_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coachsport_By_Coach");}
}
#endregion
#region Edit_Coach_With_Coachsport(Coach i_Coach,List<Coachsport> i_CoachsportList)
public void Edit_Coach_WithCoachsport(Coach i_Coach,List<Coachsport> i_List_Coachsport)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithCoachsport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Coachsport != null)
{
foreach(Coachsport oCoachsport in i_List_Coachsport)
{
oCoachsport.COACH_ID = i_Coach.COACH_ID;
Edit_Coachsport(oCoachsport);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithCoachsport");}
}
#endregion
#region Reset_Comment_By_Coach
public void Reset_Comment_By_Coach(Coach i_Coach, List<Comment> i_Comment_List)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_By_COACH_ID oParams_Delete_Comment_By_COACH_ID = new Params_Delete_Comment_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Comment
//---------------------------------
oParams_Delete_Comment_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Comment_By_COACH_ID(oParams_Delete_Comment_By_COACH_ID);
//---------------------------------
// Edit Comment
//---------------------------------
Edit_Coach_WithComment(i_Coach, i_Comment_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_By_Coach");}
}
#endregion
#region Reset_Comment_By_Coach
public void Reset_Comment_By_Coach(Coach i_Coach, List<Comment> i_Comment_List_To_Delete,List<Comment> i_Comment_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Comment oParams_Delete_Comment = new Params_Delete_Comment();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Comment_List_To_Delete != null)
{
foreach (var oRow in i_Comment_List_To_Delete)
{
oParams_Delete_Comment.COMMENT_ID = oRow.COMMENT_ID;
Delete_Comment(oParams_Delete_Comment);
}
}
//---------------------------------
// Edit Comment
//---------------------------------
Edit_Coach_WithComment(i_Coach, i_Comment_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_By_Coach");}
}
#endregion
#region Edit_Coach_With_Comment(Coach i_Coach,List<Comment> i_CommentList)
public void Edit_Coach_WithComment(Coach i_Coach,List<Comment> i_List_Comment)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithComment");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Comment != null)
{
foreach(Comment oComment in i_List_Comment)
{
oComment.COACH_ID = i_Coach.COACH_ID;
Edit_Comment(oComment);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithComment");}
}
#endregion
#region Reset_Comment_report_By_Coach
public void Reset_Comment_report_By_Coach(Coach i_Coach, List<Comment_report> i_Comment_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_report_By_COACH_ID oParams_Delete_Comment_report_By_COACH_ID = new Params_Delete_Comment_report_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_report_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Comment_report
//---------------------------------
oParams_Delete_Comment_report_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Comment_report_By_COACH_ID(oParams_Delete_Comment_report_By_COACH_ID);
//---------------------------------
// Edit Comment_report
//---------------------------------
Edit_Coach_WithComment_report(i_Coach, i_Comment_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_report_By_Coach");}
}
#endregion
#region Reset_Comment_report_By_Coach
public void Reset_Comment_report_By_Coach(Coach i_Coach, List<Comment_report> i_Comment_report_List_To_Delete,List<Comment_report> i_Comment_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_report oParams_Delete_Comment_report = new Params_Delete_Comment_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_report_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Comment_report_List_To_Delete != null)
{
foreach (var oRow in i_Comment_report_List_To_Delete)
{
oParams_Delete_Comment_report.COMMENT_REPORT_ID = oRow.COMMENT_REPORT_ID;
Delete_Comment_report(oParams_Delete_Comment_report);
}
}
//---------------------------------
// Edit Comment_report
//---------------------------------
Edit_Coach_WithComment_report(i_Coach, i_Comment_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_report_By_Coach");}
}
#endregion
#region Edit_Coach_With_Comment_report(Coach i_Coach,List<Comment_report> i_Comment_reportList)
public void Edit_Coach_WithComment_report(Coach i_Coach,List<Comment_report> i_List_Comment_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithComment_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Comment_report != null)
{
foreach(Comment_report oComment_report in i_List_Comment_report)
{
oComment_report.COACH_ID = i_Coach.COACH_ID;
Edit_Comment_report(oComment_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithComment_report");}
}
#endregion
#region Reset_Report_coach_By_Coach
public void Reset_Report_coach_By_Coach(Coach i_Coach, List<Report_coach> i_Report_coach_List)
{
#region Declaration And Initialization Section.
Params_Delete_Report_coach_By_COACH_ID oParams_Delete_Report_coach_By_COACH_ID = new Params_Delete_Report_coach_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_coach_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Report_coach
//---------------------------------
oParams_Delete_Report_coach_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Report_coach_By_COACH_ID(oParams_Delete_Report_coach_By_COACH_ID);
//---------------------------------
// Edit Report_coach
//---------------------------------
Edit_Coach_WithReport_coach(i_Coach, i_Report_coach_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_coach_By_Coach");}
}
#endregion
#region Reset_Report_coach_By_Coach
public void Reset_Report_coach_By_Coach(Coach i_Coach, List<Report_coach> i_Report_coach_List_To_Delete,List<Report_coach> i_Report_coach_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Report_coach oParams_Delete_Report_coach = new Params_Delete_Report_coach();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_coach_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Report_coach_List_To_Delete != null)
{
foreach (var oRow in i_Report_coach_List_To_Delete)
{
oParams_Delete_Report_coach.REPORT_COACH_ID = oRow.REPORT_COACH_ID;
Delete_Report_coach(oParams_Delete_Report_coach);
}
}
//---------------------------------
// Edit Report_coach
//---------------------------------
Edit_Coach_WithReport_coach(i_Coach, i_Report_coach_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_coach_By_Coach");}
}
#endregion
#region Edit_Coach_With_Report_coach(Coach i_Coach,List<Report_coach> i_Report_coachList)
public void Edit_Coach_WithReport_coach(Coach i_Coach,List<Report_coach> i_List_Report_coach)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithReport_coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Report_coach != null)
{
foreach(Report_coach oReport_coach in i_List_Report_coach)
{
oReport_coach.COACH_ID = i_Coach.COACH_ID;
Edit_Report_coach(oReport_coach);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithReport_coach");}
}
#endregion
#region Reset_Scheduled_session_By_Coach
public void Reset_Scheduled_session_By_Coach(Coach i_Coach, List<Scheduled_session> i_Scheduled_session_List)
{
#region Declaration And Initialization Section.
Params_Delete_Scheduled_session_By_COACH_ID oParams_Delete_Scheduled_session_By_COACH_ID = new Params_Delete_Scheduled_session_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Scheduled_session_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Scheduled_session
//---------------------------------
oParams_Delete_Scheduled_session_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Scheduled_session_By_COACH_ID(oParams_Delete_Scheduled_session_By_COACH_ID);
//---------------------------------
// Edit Scheduled_session
//---------------------------------
Edit_Coach_WithScheduled_session(i_Coach, i_Scheduled_session_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Scheduled_session_By_Coach");}
}
#endregion
#region Reset_Scheduled_session_By_Coach
public void Reset_Scheduled_session_By_Coach(Coach i_Coach, List<Scheduled_session> i_Scheduled_session_List_To_Delete,List<Scheduled_session> i_Scheduled_session_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Scheduled_session oParams_Delete_Scheduled_session = new Params_Delete_Scheduled_session();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Scheduled_session_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Scheduled_session_List_To_Delete != null)
{
foreach (var oRow in i_Scheduled_session_List_To_Delete)
{
oParams_Delete_Scheduled_session.SCHEDULED_SESSION_ID = oRow.SCHEDULED_SESSION_ID;
Delete_Scheduled_session(oParams_Delete_Scheduled_session);
}
}
//---------------------------------
// Edit Scheduled_session
//---------------------------------
Edit_Coach_WithScheduled_session(i_Coach, i_Scheduled_session_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Scheduled_session_By_Coach");}
}
#endregion
#region Edit_Coach_With_Scheduled_session(Coach i_Coach,List<Scheduled_session> i_Scheduled_sessionList)
public void Edit_Coach_WithScheduled_session(Coach i_Coach,List<Scheduled_session> i_List_Scheduled_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithScheduled_session");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Scheduled_session != null)
{
foreach(Scheduled_session oScheduled_session in i_List_Scheduled_session)
{
oScheduled_session.COACH_ID = i_Coach.COACH_ID;
Edit_Scheduled_session(oScheduled_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithScheduled_session");}
}
#endregion
#region Reset_Session_evaluation_By_Coach
public void Reset_Session_evaluation_By_Coach(Coach i_Coach, List<Session_evaluation> i_Session_evaluation_List)
{
#region Declaration And Initialization Section.
Params_Delete_Session_evaluation_By_COACH_ID oParams_Delete_Session_evaluation_By_COACH_ID = new Params_Delete_Session_evaluation_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Session_evaluation_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Session_evaluation
//---------------------------------
oParams_Delete_Session_evaluation_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Session_evaluation_By_COACH_ID(oParams_Delete_Session_evaluation_By_COACH_ID);
//---------------------------------
// Edit Session_evaluation
//---------------------------------
Edit_Coach_WithSession_evaluation(i_Coach, i_Session_evaluation_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Session_evaluation_By_Coach");}
}
#endregion
#region Reset_Session_evaluation_By_Coach
public void Reset_Session_evaluation_By_Coach(Coach i_Coach, List<Session_evaluation> i_Session_evaluation_List_To_Delete,List<Session_evaluation> i_Session_evaluation_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Session_evaluation oParams_Delete_Session_evaluation = new Params_Delete_Session_evaluation();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Session_evaluation_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Session_evaluation_List_To_Delete != null)
{
foreach (var oRow in i_Session_evaluation_List_To_Delete)
{
oParams_Delete_Session_evaluation.SESSION_EVALUATION_ID = oRow.SESSION_EVALUATION_ID;
Delete_Session_evaluation(oParams_Delete_Session_evaluation);
}
}
//---------------------------------
// Edit Session_evaluation
//---------------------------------
Edit_Coach_WithSession_evaluation(i_Coach, i_Session_evaluation_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Session_evaluation_By_Coach");}
}
#endregion
#region Edit_Coach_With_Session_evaluation(Coach i_Coach,List<Session_evaluation> i_Session_evaluationList)
public void Edit_Coach_WithSession_evaluation(Coach i_Coach,List<Session_evaluation> i_List_Session_evaluation)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithSession_evaluation");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Session_evaluation != null)
{
foreach(Session_evaluation oSession_evaluation in i_List_Session_evaluation)
{
oSession_evaluation.COACH_ID = i_Coach.COACH_ID;
Edit_Session_evaluation(oSession_evaluation);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithSession_evaluation");}
}
#endregion
#region Reset_Taken_session_By_Coach
public void Reset_Taken_session_By_Coach(Coach i_Coach, List<Taken_session> i_Taken_session_List)
{
#region Declaration And Initialization Section.
Params_Delete_Taken_session_By_COACH_ID oParams_Delete_Taken_session_By_COACH_ID = new Params_Delete_Taken_session_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Taken_session_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Taken_session
//---------------------------------
oParams_Delete_Taken_session_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Taken_session_By_COACH_ID(oParams_Delete_Taken_session_By_COACH_ID);
//---------------------------------
// Edit Taken_session
//---------------------------------
Edit_Coach_WithTaken_session(i_Coach, i_Taken_session_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Taken_session_By_Coach");}
}
#endregion
#region Reset_Taken_session_By_Coach
public void Reset_Taken_session_By_Coach(Coach i_Coach, List<Taken_session> i_Taken_session_List_To_Delete,List<Taken_session> i_Taken_session_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Taken_session oParams_Delete_Taken_session = new Params_Delete_Taken_session();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Taken_session_By_Coach");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Taken_session_List_To_Delete != null)
{
foreach (var oRow in i_Taken_session_List_To_Delete)
{
oParams_Delete_Taken_session.TAKEN_SESSION_ID = oRow.TAKEN_SESSION_ID;
Delete_Taken_session(oParams_Delete_Taken_session);
}
}
//---------------------------------
// Edit Taken_session
//---------------------------------
Edit_Coach_WithTaken_session(i_Coach, i_Taken_session_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Taken_session_By_Coach");}
}
#endregion
#region Edit_Coach_With_Taken_session(Coach i_Coach,List<Taken_session> i_Taken_sessionList)
public void Edit_Coach_WithTaken_session(Coach i_Coach,List<Taken_session> i_List_Taken_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithTaken_session");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Taken_session != null)
{
foreach(Taken_session oTaken_session in i_List_Taken_session)
{
oTaken_session.COACH_ID = i_Coach.COACH_ID;
Edit_Taken_session(oTaken_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithTaken_session");}
}
#endregion
#region Edit_Coach_WithRelatedData(Coach i_Coach,List<Coach_evaluation> i_List_Coach_evaluation,List<Coach_leaderboards> i_List_Coach_leaderboards,List<Coachsport> i_List_Coachsport,List<Comment> i_List_Comment,List<Comment_report> i_List_Comment_report,List<Report_coach> i_List_Report_coach,List<Scheduled_session> i_List_Scheduled_session,List<Session_evaluation> i_List_Session_evaluation,List<Taken_session> i_List_Taken_session)
public void Edit_Coach_WithRelatedData(Coach i_Coach,List<Coach_evaluation> i_List_Coach_evaluation,List<Coach_leaderboards> i_List_Coach_leaderboards,List<Coachsport> i_List_Coachsport,List<Comment> i_List_Comment,List<Comment_report> i_List_Comment_report,List<Report_coach> i_List_Report_coach,List<Scheduled_session> i_List_Scheduled_session,List<Session_evaluation> i_List_Session_evaluation,List<Taken_session> i_List_Taken_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Coach_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Coach(i_Coach);
if (i_List_Coach_evaluation != null)
{
foreach(Coach_evaluation oCoach_evaluation in i_List_Coach_evaluation)
{
oCoach_evaluation.COACH_ID = i_Coach.COACH_ID;
Edit_Coach_evaluation(oCoach_evaluation);
}
}
if (i_List_Coach_leaderboards != null)
{
foreach(Coach_leaderboards oCoach_leaderboards in i_List_Coach_leaderboards)
{
oCoach_leaderboards.COACH_ID = i_Coach.COACH_ID;
Edit_Coach_leaderboards(oCoach_leaderboards);
}
}
if (i_List_Coachsport != null)
{
foreach(Coachsport oCoachsport in i_List_Coachsport)
{
oCoachsport.COACH_ID = i_Coach.COACH_ID;
Edit_Coachsport(oCoachsport);
}
}
if (i_List_Comment != null)
{
foreach(Comment oComment in i_List_Comment)
{
oComment.COACH_ID = i_Coach.COACH_ID;
Edit_Comment(oComment);
}
}
if (i_List_Comment_report != null)
{
foreach(Comment_report oComment_report in i_List_Comment_report)
{
oComment_report.COACH_ID = i_Coach.COACH_ID;
Edit_Comment_report(oComment_report);
}
}
if (i_List_Report_coach != null)
{
foreach(Report_coach oReport_coach in i_List_Report_coach)
{
oReport_coach.COACH_ID = i_Coach.COACH_ID;
Edit_Report_coach(oReport_coach);
}
}
if (i_List_Scheduled_session != null)
{
foreach(Scheduled_session oScheduled_session in i_List_Scheduled_session)
{
oScheduled_session.COACH_ID = i_Coach.COACH_ID;
Edit_Scheduled_session(oScheduled_session);
}
}
if (i_List_Session_evaluation != null)
{
foreach(Session_evaluation oSession_evaluation in i_List_Session_evaluation)
{
oSession_evaluation.COACH_ID = i_Coach.COACH_ID;
Edit_Session_evaluation(oSession_evaluation);
}
}
if (i_List_Taken_session != null)
{
foreach(Taken_session oTaken_session in i_List_Taken_session)
{
oTaken_session.COACH_ID = i_Coach.COACH_ID;
Edit_Taken_session(oTaken_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Coach_WithRelatedData");}
}
#endregion
#region Delete_Coach_With_Children(Coach i_Coach)
public void Delete_Coach_With_Children(Coach i_Coach)
{
 #region Declaration And Initialization Section.
Params_Delete_Coach oParams_Delete_Coach = new Params_Delete_Coach();
Params_Delete_Coach_evaluation_By_COACH_ID oParams_Delete_Coach_evaluation_By_COACH_ID = new Params_Delete_Coach_evaluation_By_COACH_ID();
Params_Delete_Coach_leaderboards_By_COACH_ID oParams_Delete_Coach_leaderboards_By_COACH_ID = new Params_Delete_Coach_leaderboards_By_COACH_ID();
Params_Delete_Coachsport_By_COACH_ID oParams_Delete_Coachsport_By_COACH_ID = new Params_Delete_Coachsport_By_COACH_ID();
Params_Delete_Comment_By_COACH_ID oParams_Delete_Comment_By_COACH_ID = new Params_Delete_Comment_By_COACH_ID();
Params_Delete_Comment_report_By_COACH_ID oParams_Delete_Comment_report_By_COACH_ID = new Params_Delete_Comment_report_By_COACH_ID();
Params_Delete_Report_coach_By_COACH_ID oParams_Delete_Report_coach_By_COACH_ID = new Params_Delete_Report_coach_By_COACH_ID();
Params_Delete_Scheduled_session_By_COACH_ID oParams_Delete_Scheduled_session_By_COACH_ID = new Params_Delete_Scheduled_session_By_COACH_ID();
Params_Delete_Session_evaluation_By_COACH_ID oParams_Delete_Session_evaluation_By_COACH_ID = new Params_Delete_Session_evaluation_By_COACH_ID();
Params_Delete_Taken_session_By_COACH_ID oParams_Delete_Taken_session_By_COACH_ID = new Params_Delete_Taken_session_By_COACH_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Coach_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Coach_evaluation_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Coach_evaluation_By_COACH_ID(oParams_Delete_Coach_evaluation_By_COACH_ID);
oParams_Delete_Coach_leaderboards_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Coach_leaderboards_By_COACH_ID(oParams_Delete_Coach_leaderboards_By_COACH_ID);
oParams_Delete_Coachsport_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Coachsport_By_COACH_ID(oParams_Delete_Coachsport_By_COACH_ID);
oParams_Delete_Comment_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Comment_By_COACH_ID(oParams_Delete_Comment_By_COACH_ID);
oParams_Delete_Comment_report_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Comment_report_By_COACH_ID(oParams_Delete_Comment_report_By_COACH_ID);
oParams_Delete_Report_coach_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Report_coach_By_COACH_ID(oParams_Delete_Report_coach_By_COACH_ID);
oParams_Delete_Scheduled_session_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Scheduled_session_By_COACH_ID(oParams_Delete_Scheduled_session_By_COACH_ID);
oParams_Delete_Session_evaluation_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Session_evaluation_By_COACH_ID(oParams_Delete_Session_evaluation_By_COACH_ID);
oParams_Delete_Taken_session_By_COACH_ID.COACH_ID = i_Coach.COACH_ID;
Delete_Taken_session_By_COACH_ID(oParams_Delete_Taken_session_By_COACH_ID);
//-------------------------

//-------------------------
oParams_Delete_Coach.COACH_ID = i_Coach.COACH_ID;
Delete_Coach(oParams_Delete_Coach);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Coach_With_Children");}
}
#endregion
#region Reset_Coach_evaluation_By_Player
public void Reset_Coach_evaluation_By_Player(Player i_Player, List<Coach_evaluation> i_Coach_evaluation_List)
{
#region Declaration And Initialization Section.
Params_Delete_Coach_evaluation_By_PLAYER_ID oParams_Delete_Coach_evaluation_By_PLAYER_ID = new Params_Delete_Coach_evaluation_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coach_evaluation_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Coach_evaluation
//---------------------------------
oParams_Delete_Coach_evaluation_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Coach_evaluation_By_PLAYER_ID(oParams_Delete_Coach_evaluation_By_PLAYER_ID);
//---------------------------------
// Edit Coach_evaluation
//---------------------------------
Edit_Player_WithCoach_evaluation(i_Player, i_Coach_evaluation_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coach_evaluation_By_Player");}
}
#endregion
#region Reset_Coach_evaluation_By_Player
public void Reset_Coach_evaluation_By_Player(Player i_Player, List<Coach_evaluation> i_Coach_evaluation_List_To_Delete,List<Coach_evaluation> i_Coach_evaluation_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Coach_evaluation oParams_Delete_Coach_evaluation = new Params_Delete_Coach_evaluation();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Coach_evaluation_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Coach_evaluation_List_To_Delete != null)
{
foreach (var oRow in i_Coach_evaluation_List_To_Delete)
{
oParams_Delete_Coach_evaluation.COACH_EVALUATION_ID = oRow.COACH_EVALUATION_ID;
Delete_Coach_evaluation(oParams_Delete_Coach_evaluation);
}
}
//---------------------------------
// Edit Coach_evaluation
//---------------------------------
Edit_Player_WithCoach_evaluation(i_Player, i_Coach_evaluation_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Coach_evaluation_By_Player");}
}
#endregion
#region Edit_Player_With_Coach_evaluation(Player i_Player,List<Coach_evaluation> i_Coach_evaluationList)
public void Edit_Player_WithCoach_evaluation(Player i_Player,List<Coach_evaluation> i_List_Coach_evaluation)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithCoach_evaluation");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Coach_evaluation != null)
{
foreach(Coach_evaluation oCoach_evaluation in i_List_Coach_evaluation)
{
oCoach_evaluation.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Coach_evaluation(oCoach_evaluation);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithCoach_evaluation");}
}
#endregion
#region Reset_Comment_By_Player
public void Reset_Comment_By_Player(Player i_Player, List<Comment> i_Comment_List)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_By_PLAYER_ID oParams_Delete_Comment_By_PLAYER_ID = new Params_Delete_Comment_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Comment
//---------------------------------
oParams_Delete_Comment_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Comment_By_PLAYER_ID(oParams_Delete_Comment_By_PLAYER_ID);
//---------------------------------
// Edit Comment
//---------------------------------
Edit_Player_WithComment(i_Player, i_Comment_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_By_Player");}
}
#endregion
#region Reset_Comment_By_Player
public void Reset_Comment_By_Player(Player i_Player, List<Comment> i_Comment_List_To_Delete,List<Comment> i_Comment_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Comment oParams_Delete_Comment = new Params_Delete_Comment();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Comment_List_To_Delete != null)
{
foreach (var oRow in i_Comment_List_To_Delete)
{
oParams_Delete_Comment.COMMENT_ID = oRow.COMMENT_ID;
Delete_Comment(oParams_Delete_Comment);
}
}
//---------------------------------
// Edit Comment
//---------------------------------
Edit_Player_WithComment(i_Player, i_Comment_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_By_Player");}
}
#endregion
#region Edit_Player_With_Comment(Player i_Player,List<Comment> i_CommentList)
public void Edit_Player_WithComment(Player i_Player,List<Comment> i_List_Comment)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithComment");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Comment != null)
{
foreach(Comment oComment in i_List_Comment)
{
oComment.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Comment(oComment);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithComment");}
}
#endregion
#region Reset_Comment_report_By_Player
public void Reset_Comment_report_By_Player(Player i_Player, List<Comment_report> i_Comment_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_report_By_PLAYER_ID oParams_Delete_Comment_report_By_PLAYER_ID = new Params_Delete_Comment_report_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_report_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Comment_report
//---------------------------------
oParams_Delete_Comment_report_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Comment_report_By_PLAYER_ID(oParams_Delete_Comment_report_By_PLAYER_ID);
//---------------------------------
// Edit Comment_report
//---------------------------------
Edit_Player_WithComment_report(i_Player, i_Comment_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_report_By_Player");}
}
#endregion
#region Reset_Comment_report_By_Player
public void Reset_Comment_report_By_Player(Player i_Player, List<Comment_report> i_Comment_report_List_To_Delete,List<Comment_report> i_Comment_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Comment_report oParams_Delete_Comment_report = new Params_Delete_Comment_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Comment_report_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Comment_report_List_To_Delete != null)
{
foreach (var oRow in i_Comment_report_List_To_Delete)
{
oParams_Delete_Comment_report.COMMENT_REPORT_ID = oRow.COMMENT_REPORT_ID;
Delete_Comment_report(oParams_Delete_Comment_report);
}
}
//---------------------------------
// Edit Comment_report
//---------------------------------
Edit_Player_WithComment_report(i_Player, i_Comment_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Comment_report_By_Player");}
}
#endregion
#region Edit_Player_With_Comment_report(Player i_Player,List<Comment_report> i_Comment_reportList)
public void Edit_Player_WithComment_report(Player i_Player,List<Comment_report> i_List_Comment_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithComment_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Comment_report != null)
{
foreach(Comment_report oComment_report in i_List_Comment_report)
{
oComment_report.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Comment_report(oComment_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithComment_report");}
}
#endregion
#region Reset_Player_leaderboards_By_Player
public void Reset_Player_leaderboards_By_Player(Player i_Player, List<Player_leaderboards> i_Player_leaderboards_List)
{
#region Declaration And Initialization Section.
Params_Delete_Player_leaderboards_By_PLAYER_ID oParams_Delete_Player_leaderboards_By_PLAYER_ID = new Params_Delete_Player_leaderboards_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Player_leaderboards_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Player_leaderboards
//---------------------------------
oParams_Delete_Player_leaderboards_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Player_leaderboards_By_PLAYER_ID(oParams_Delete_Player_leaderboards_By_PLAYER_ID);
//---------------------------------
// Edit Player_leaderboards
//---------------------------------
Edit_Player_WithPlayer_leaderboards(i_Player, i_Player_leaderboards_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Player_leaderboards_By_Player");}
}
#endregion
#region Reset_Player_leaderboards_By_Player
public void Reset_Player_leaderboards_By_Player(Player i_Player, List<Player_leaderboards> i_Player_leaderboards_List_To_Delete,List<Player_leaderboards> i_Player_leaderboards_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Player_leaderboards oParams_Delete_Player_leaderboards = new Params_Delete_Player_leaderboards();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Player_leaderboards_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Player_leaderboards_List_To_Delete != null)
{
foreach (var oRow in i_Player_leaderboards_List_To_Delete)
{
oParams_Delete_Player_leaderboards.PLAYER_LEADERBOARDS_ID = oRow.PLAYER_LEADERBOARDS_ID;
Delete_Player_leaderboards(oParams_Delete_Player_leaderboards);
}
}
//---------------------------------
// Edit Player_leaderboards
//---------------------------------
Edit_Player_WithPlayer_leaderboards(i_Player, i_Player_leaderboards_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Player_leaderboards_By_Player");}
}
#endregion
#region Edit_Player_With_Player_leaderboards(Player i_Player,List<Player_leaderboards> i_Player_leaderboardsList)
public void Edit_Player_WithPlayer_leaderboards(Player i_Player,List<Player_leaderboards> i_List_Player_leaderboards)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithPlayer_leaderboards");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Player_leaderboards != null)
{
foreach(Player_leaderboards oPlayer_leaderboards in i_List_Player_leaderboards)
{
oPlayer_leaderboards.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Player_leaderboards(oPlayer_leaderboards);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithPlayer_leaderboards");}
}
#endregion
#region Reset_Playersport_By_Player
public void Reset_Playersport_By_Player(Player i_Player, List<Playersport> i_Playersport_List)
{
#region Declaration And Initialization Section.
Params_Delete_Playersport_By_PLAYER_ID oParams_Delete_Playersport_By_PLAYER_ID = new Params_Delete_Playersport_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Playersport_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Playersport
//---------------------------------
oParams_Delete_Playersport_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Playersport_By_PLAYER_ID(oParams_Delete_Playersport_By_PLAYER_ID);
//---------------------------------
// Edit Playersport
//---------------------------------
Edit_Player_WithPlayersport(i_Player, i_Playersport_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Playersport_By_Player");}
}
#endregion
#region Reset_Playersport_By_Player
public void Reset_Playersport_By_Player(Player i_Player, List<Playersport> i_Playersport_List_To_Delete,List<Playersport> i_Playersport_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Playersport oParams_Delete_Playersport = new Params_Delete_Playersport();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Playersport_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Playersport_List_To_Delete != null)
{
foreach (var oRow in i_Playersport_List_To_Delete)
{
oParams_Delete_Playersport.PLAYERSPORT_ID = oRow.PLAYERSPORT_ID;
Delete_Playersport(oParams_Delete_Playersport);
}
}
//---------------------------------
// Edit Playersport
//---------------------------------
Edit_Player_WithPlayersport(i_Player, i_Playersport_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Playersport_By_Player");}
}
#endregion
#region Edit_Player_With_Playersport(Player i_Player,List<Playersport> i_PlayersportList)
public void Edit_Player_WithPlayersport(Player i_Player,List<Playersport> i_List_Playersport)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithPlayersport");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Playersport != null)
{
foreach(Playersport oPlayersport in i_List_Playersport)
{
oPlayersport.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Playersport(oPlayersport);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithPlayersport");}
}
#endregion
#region Reset_Report_player_By_Player
public void Reset_Report_player_By_Player(Player i_Player, List<Report_player> i_Report_player_List)
{
#region Declaration And Initialization Section.
Params_Delete_Report_player_By_PLAYER_ID oParams_Delete_Report_player_By_PLAYER_ID = new Params_Delete_Report_player_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_player_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Report_player
//---------------------------------
oParams_Delete_Report_player_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Report_player_By_PLAYER_ID(oParams_Delete_Report_player_By_PLAYER_ID);
//---------------------------------
// Edit Report_player
//---------------------------------
Edit_Player_WithReport_player(i_Player, i_Report_player_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_player_By_Player");}
}
#endregion
#region Reset_Report_player_By_Player
public void Reset_Report_player_By_Player(Player i_Player, List<Report_player> i_Report_player_List_To_Delete,List<Report_player> i_Report_player_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Report_player oParams_Delete_Report_player = new Params_Delete_Report_player();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_player_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Report_player_List_To_Delete != null)
{
foreach (var oRow in i_Report_player_List_To_Delete)
{
oParams_Delete_Report_player.REPORT_PLAYER_ID = oRow.REPORT_PLAYER_ID;
Delete_Report_player(oParams_Delete_Report_player);
}
}
//---------------------------------
// Edit Report_player
//---------------------------------
Edit_Player_WithReport_player(i_Player, i_Report_player_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_player_By_Player");}
}
#endregion
#region Edit_Player_With_Report_player(Player i_Player,List<Report_player> i_Report_playerList)
public void Edit_Player_WithReport_player(Player i_Player,List<Report_player> i_List_Report_player)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithReport_player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Report_player != null)
{
foreach(Report_player oReport_player in i_List_Report_player)
{
oReport_player.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Report_player(oReport_player);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithReport_player");}
}
#endregion
#region Reset_Scheduled_session_By_Player
public void Reset_Scheduled_session_By_Player(Player i_Player, List<Scheduled_session> i_Scheduled_session_List)
{
#region Declaration And Initialization Section.
Params_Delete_Scheduled_session_By_PLAYER_ID oParams_Delete_Scheduled_session_By_PLAYER_ID = new Params_Delete_Scheduled_session_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Scheduled_session_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Scheduled_session
//---------------------------------
oParams_Delete_Scheduled_session_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Scheduled_session_By_PLAYER_ID(oParams_Delete_Scheduled_session_By_PLAYER_ID);
//---------------------------------
// Edit Scheduled_session
//---------------------------------
Edit_Player_WithScheduled_session(i_Player, i_Scheduled_session_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Scheduled_session_By_Player");}
}
#endregion
#region Reset_Scheduled_session_By_Player
public void Reset_Scheduled_session_By_Player(Player i_Player, List<Scheduled_session> i_Scheduled_session_List_To_Delete,List<Scheduled_session> i_Scheduled_session_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Scheduled_session oParams_Delete_Scheduled_session = new Params_Delete_Scheduled_session();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Scheduled_session_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Scheduled_session_List_To_Delete != null)
{
foreach (var oRow in i_Scheduled_session_List_To_Delete)
{
oParams_Delete_Scheduled_session.SCHEDULED_SESSION_ID = oRow.SCHEDULED_SESSION_ID;
Delete_Scheduled_session(oParams_Delete_Scheduled_session);
}
}
//---------------------------------
// Edit Scheduled_session
//---------------------------------
Edit_Player_WithScheduled_session(i_Player, i_Scheduled_session_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Scheduled_session_By_Player");}
}
#endregion
#region Edit_Player_With_Scheduled_session(Player i_Player,List<Scheduled_session> i_Scheduled_sessionList)
public void Edit_Player_WithScheduled_session(Player i_Player,List<Scheduled_session> i_List_Scheduled_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithScheduled_session");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Scheduled_session != null)
{
foreach(Scheduled_session oScheduled_session in i_List_Scheduled_session)
{
oScheduled_session.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Scheduled_session(oScheduled_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithScheduled_session");}
}
#endregion
#region Reset_Session_evaluation_By_Player
public void Reset_Session_evaluation_By_Player(Player i_Player, List<Session_evaluation> i_Session_evaluation_List)
{
#region Declaration And Initialization Section.
Params_Delete_Session_evaluation_By_PLAYER_ID oParams_Delete_Session_evaluation_By_PLAYER_ID = new Params_Delete_Session_evaluation_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Session_evaluation_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Session_evaluation
//---------------------------------
oParams_Delete_Session_evaluation_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Session_evaluation_By_PLAYER_ID(oParams_Delete_Session_evaluation_By_PLAYER_ID);
//---------------------------------
// Edit Session_evaluation
//---------------------------------
Edit_Player_WithSession_evaluation(i_Player, i_Session_evaluation_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Session_evaluation_By_Player");}
}
#endregion
#region Reset_Session_evaluation_By_Player
public void Reset_Session_evaluation_By_Player(Player i_Player, List<Session_evaluation> i_Session_evaluation_List_To_Delete,List<Session_evaluation> i_Session_evaluation_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Session_evaluation oParams_Delete_Session_evaluation = new Params_Delete_Session_evaluation();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Session_evaluation_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Session_evaluation_List_To_Delete != null)
{
foreach (var oRow in i_Session_evaluation_List_To_Delete)
{
oParams_Delete_Session_evaluation.SESSION_EVALUATION_ID = oRow.SESSION_EVALUATION_ID;
Delete_Session_evaluation(oParams_Delete_Session_evaluation);
}
}
//---------------------------------
// Edit Session_evaluation
//---------------------------------
Edit_Player_WithSession_evaluation(i_Player, i_Session_evaluation_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Session_evaluation_By_Player");}
}
#endregion
#region Edit_Player_With_Session_evaluation(Player i_Player,List<Session_evaluation> i_Session_evaluationList)
public void Edit_Player_WithSession_evaluation(Player i_Player,List<Session_evaluation> i_List_Session_evaluation)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithSession_evaluation");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Session_evaluation != null)
{
foreach(Session_evaluation oSession_evaluation in i_List_Session_evaluation)
{
oSession_evaluation.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Session_evaluation(oSession_evaluation);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithSession_evaluation");}
}
#endregion
#region Reset_Taken_session_By_Player
public void Reset_Taken_session_By_Player(Player i_Player, List<Taken_session> i_Taken_session_List)
{
#region Declaration And Initialization Section.
Params_Delete_Taken_session_By_PLAYER_ID oParams_Delete_Taken_session_By_PLAYER_ID = new Params_Delete_Taken_session_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Taken_session_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Taken_session
//---------------------------------
oParams_Delete_Taken_session_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Taken_session_By_PLAYER_ID(oParams_Delete_Taken_session_By_PLAYER_ID);
//---------------------------------
// Edit Taken_session
//---------------------------------
Edit_Player_WithTaken_session(i_Player, i_Taken_session_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Taken_session_By_Player");}
}
#endregion
#region Reset_Taken_session_By_Player
public void Reset_Taken_session_By_Player(Player i_Player, List<Taken_session> i_Taken_session_List_To_Delete,List<Taken_session> i_Taken_session_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Taken_session oParams_Delete_Taken_session = new Params_Delete_Taken_session();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Taken_session_By_Player");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Taken_session_List_To_Delete != null)
{
foreach (var oRow in i_Taken_session_List_To_Delete)
{
oParams_Delete_Taken_session.TAKEN_SESSION_ID = oRow.TAKEN_SESSION_ID;
Delete_Taken_session(oParams_Delete_Taken_session);
}
}
//---------------------------------
// Edit Taken_session
//---------------------------------
Edit_Player_WithTaken_session(i_Player, i_Taken_session_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Taken_session_By_Player");}
}
#endregion
#region Edit_Player_With_Taken_session(Player i_Player,List<Taken_session> i_Taken_sessionList)
public void Edit_Player_WithTaken_session(Player i_Player,List<Taken_session> i_List_Taken_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithTaken_session");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Taken_session != null)
{
foreach(Taken_session oTaken_session in i_List_Taken_session)
{
oTaken_session.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Taken_session(oTaken_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithTaken_session");}
}
#endregion
#region Edit_Player_WithRelatedData(Player i_Player,List<Coach_evaluation> i_List_Coach_evaluation,List<Comment> i_List_Comment,List<Comment_report> i_List_Comment_report,List<Player_leaderboards> i_List_Player_leaderboards,List<Playersport> i_List_Playersport,List<Report_player> i_List_Report_player,List<Scheduled_session> i_List_Scheduled_session,List<Session_evaluation> i_List_Session_evaluation,List<Taken_session> i_List_Taken_session)
public void Edit_Player_WithRelatedData(Player i_Player,List<Coach_evaluation> i_List_Coach_evaluation,List<Comment> i_List_Comment,List<Comment_report> i_List_Comment_report,List<Player_leaderboards> i_List_Player_leaderboards,List<Playersport> i_List_Playersport,List<Report_player> i_List_Report_player,List<Scheduled_session> i_List_Scheduled_session,List<Session_evaluation> i_List_Session_evaluation,List<Taken_session> i_List_Taken_session)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Player_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Player(i_Player);
if (i_List_Coach_evaluation != null)
{
foreach(Coach_evaluation oCoach_evaluation in i_List_Coach_evaluation)
{
oCoach_evaluation.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Coach_evaluation(oCoach_evaluation);
}
}
if (i_List_Comment != null)
{
foreach(Comment oComment in i_List_Comment)
{
oComment.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Comment(oComment);
}
}
if (i_List_Comment_report != null)
{
foreach(Comment_report oComment_report in i_List_Comment_report)
{
oComment_report.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Comment_report(oComment_report);
}
}
if (i_List_Player_leaderboards != null)
{
foreach(Player_leaderboards oPlayer_leaderboards in i_List_Player_leaderboards)
{
oPlayer_leaderboards.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Player_leaderboards(oPlayer_leaderboards);
}
}
if (i_List_Playersport != null)
{
foreach(Playersport oPlayersport in i_List_Playersport)
{
oPlayersport.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Playersport(oPlayersport);
}
}
if (i_List_Report_player != null)
{
foreach(Report_player oReport_player in i_List_Report_player)
{
oReport_player.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Report_player(oReport_player);
}
}
if (i_List_Scheduled_session != null)
{
foreach(Scheduled_session oScheduled_session in i_List_Scheduled_session)
{
oScheduled_session.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Scheduled_session(oScheduled_session);
}
}
if (i_List_Session_evaluation != null)
{
foreach(Session_evaluation oSession_evaluation in i_List_Session_evaluation)
{
oSession_evaluation.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Session_evaluation(oSession_evaluation);
}
}
if (i_List_Taken_session != null)
{
foreach(Taken_session oTaken_session in i_List_Taken_session)
{
oTaken_session.PLAYER_ID = i_Player.PLAYER_ID;
Edit_Taken_session(oTaken_session);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Player_WithRelatedData");}
}
#endregion
#region Delete_Player_With_Children(Player i_Player)
public void Delete_Player_With_Children(Player i_Player)
{
 #region Declaration And Initialization Section.
Params_Delete_Player oParams_Delete_Player = new Params_Delete_Player();
Params_Delete_Coach_evaluation_By_PLAYER_ID oParams_Delete_Coach_evaluation_By_PLAYER_ID = new Params_Delete_Coach_evaluation_By_PLAYER_ID();
Params_Delete_Comment_By_PLAYER_ID oParams_Delete_Comment_By_PLAYER_ID = new Params_Delete_Comment_By_PLAYER_ID();
Params_Delete_Comment_report_By_PLAYER_ID oParams_Delete_Comment_report_By_PLAYER_ID = new Params_Delete_Comment_report_By_PLAYER_ID();
Params_Delete_Player_leaderboards_By_PLAYER_ID oParams_Delete_Player_leaderboards_By_PLAYER_ID = new Params_Delete_Player_leaderboards_By_PLAYER_ID();
Params_Delete_Playersport_By_PLAYER_ID oParams_Delete_Playersport_By_PLAYER_ID = new Params_Delete_Playersport_By_PLAYER_ID();
Params_Delete_Report_player_By_PLAYER_ID oParams_Delete_Report_player_By_PLAYER_ID = new Params_Delete_Report_player_By_PLAYER_ID();
Params_Delete_Scheduled_session_By_PLAYER_ID oParams_Delete_Scheduled_session_By_PLAYER_ID = new Params_Delete_Scheduled_session_By_PLAYER_ID();
Params_Delete_Session_evaluation_By_PLAYER_ID oParams_Delete_Session_evaluation_By_PLAYER_ID = new Params_Delete_Session_evaluation_By_PLAYER_ID();
Params_Delete_Taken_session_By_PLAYER_ID oParams_Delete_Taken_session_By_PLAYER_ID = new Params_Delete_Taken_session_By_PLAYER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Player_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Coach_evaluation_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Coach_evaluation_By_PLAYER_ID(oParams_Delete_Coach_evaluation_By_PLAYER_ID);
oParams_Delete_Comment_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Comment_By_PLAYER_ID(oParams_Delete_Comment_By_PLAYER_ID);
oParams_Delete_Comment_report_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Comment_report_By_PLAYER_ID(oParams_Delete_Comment_report_By_PLAYER_ID);
oParams_Delete_Player_leaderboards_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Player_leaderboards_By_PLAYER_ID(oParams_Delete_Player_leaderboards_By_PLAYER_ID);
oParams_Delete_Playersport_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Playersport_By_PLAYER_ID(oParams_Delete_Playersport_By_PLAYER_ID);
oParams_Delete_Report_player_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Report_player_By_PLAYER_ID(oParams_Delete_Report_player_By_PLAYER_ID);
oParams_Delete_Scheduled_session_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Scheduled_session_By_PLAYER_ID(oParams_Delete_Scheduled_session_By_PLAYER_ID);
oParams_Delete_Session_evaluation_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Session_evaluation_By_PLAYER_ID(oParams_Delete_Session_evaluation_By_PLAYER_ID);
oParams_Delete_Taken_session_By_PLAYER_ID.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Taken_session_By_PLAYER_ID(oParams_Delete_Taken_session_By_PLAYER_ID);
//-------------------------

//-------------------------
oParams_Delete_Player.PLAYER_ID = i_Player.PLAYER_ID;
Delete_Player(oParams_Delete_Player);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Player_With_Children");}
}
#endregion
}
}
