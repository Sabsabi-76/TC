using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
#region Coach_leaderboards
public partial class Coach_leaderboards
{
#region Advanced Properties
public Coach My_Coach {get;set;}
#endregion
}
#endregion
#region Player_leaderboards
public partial class Player_leaderboards
{
#region Advanced Properties
public Player My_Player {get;set;}
#endregion
}
#endregion
#region Playersport
public partial class Playersport
{
#region Advanced Properties
public Player My_Player {get;set;}
public Sport My_Sport {get;set;}
#endregion
}
#endregion
#region Sport
public partial class Sport
{
#region Advanced Properties
#endregion
}
#endregion
#region Coachsport
public partial class Coachsport
{
#region Advanced Properties
public Sport My_Sport {get;set;}
public Coach My_Coach {get;set;}
#endregion
}
#endregion
#region Coach_evaluation
public partial class Coach_evaluation
{
#region Advanced Properties
public Coach_evaluation My_Coach_evaluation {get;set;}
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
#endregion
}
#endregion
#region Currency
public partial class Currency
{
#region Advanced Properties
#endregion
}
#endregion
#region Session_evaluation
public partial class Session_evaluation
{
#region Advanced Properties
public Coach My_Coach {get;set;}
public Player My_Player {get;set;}
#endregion
}
#endregion
#region Taken_session
public partial class Taken_session
{
#region Advanced Properties
public Coach My_Coach {get;set;}
public Player My_Player {get;set;}
public Sport My_Sport {get;set;}
#endregion
}
#endregion
#region Scheduled_session
public partial class Scheduled_session
{
#region Advanced Properties
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
public Sport My_Sport {get;set;}
#endregion
}
#endregion
#region Notification
public partial class Notification
{
#region Advanced Properties
#endregion
}
#endregion
#region Owner
public partial class Owner
{
#region Advanced Properties
#endregion
}
#endregion
#region Comment
public partial class Comment
{
#region Advanced Properties
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
#endregion
}
#endregion
#region Report_coach
public partial class Report_coach
{
#region Advanced Properties
public Coach My_Coach {get;set;}
#endregion
}
#endregion
#region Comment_report
public partial class Comment_report
{
#region Advanced Properties
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
public Comment My_Comment {get;set;}
#endregion
}
#endregion
#region User
public partial class User
{
#region Advanced Properties
#endregion
}
#endregion
#region Direct_message
public partial class Direct_message
{
#region Advanced Properties
#endregion
}
#endregion
#region Report_player
public partial class Report_player
{
#region Advanced Properties
public Player My_Player {get;set;}
#endregion
}
#endregion
#region Coach
public partial class Coach
{
#region Advanced Properties
#endregion
}
#endregion
#region Player
public partial class Player
{
#region Advanced Properties
#endregion
}
#endregion
}
