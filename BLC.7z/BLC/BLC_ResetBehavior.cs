using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
public partial class BLC
{
#region Initialize_Reset_Mechanism
public void Initialize_Reset_Mechanism()
{
#region Declaration And Initialization Section.
#endregion
#region Body Section.

#endregion
}
#endregion
}
}
