using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace BLC
{
    #region Enumeration
    public enum Enum_EntityNameFormat
    {
        FML,
        FLM,
        MFL,
        MLF,
        LFM,
        LMF
    }
    #endregion
    public partial class BLC
    {
        #region Members
        #endregion        
        #region Setup
        #region EditSetup
        #region EditSetup
        public void EditSetup(SetupEntry i_SetupEntry)
        {
            #region Declaration And Initialization Section.
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "EditSetup";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                oMethodInfo.Invoke(this, new object[] { i_SetupEntry });
                return;
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("EditSetup");
            }
            #endregion
            #region Body Section.
            i_SetupEntry.ENTRY_USER_ID = this.UserID;
            i_SetupEntry.OWNER_ID = this.OwnerID;
            i_SetupEntry.ENTRY_DATE = oTools.GetDateString(DateTime.Today);
            oTools.InvokeMethod(_AppContext, "UP_EDIT_SETUP", i_SetupEntry);
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("EditSetup");
            }
            #endregion
        }
        #endregion
        #endregion
        #endregion
        #region Ticket
        #region ResolveTicket
        public Dictionary<string, string> ResolveTicket(string i_Input)
        {
            #region Declaration And Initialization Section.
            Dictionary<string, string> oList = new Dictionary<string, string>();
            string str_Ticket_PlainText = string.Empty;
            Crypto.Crypto oCrypto = new Crypto.Crypto();
            string[] oMainTempList = null;
            string[] oSubTempList = null;
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("ResolveTicket");
            }
            #endregion
            #region Body Section.
            if (!string.IsNullOrEmpty(i_Input))
            {
                //str_Ticket_PlainText = oCrypto.Decrypt(i_Input, _KeySet);
                str_Ticket_PlainText = i_Input;

                if (!string.IsNullOrEmpty(str_Ticket_PlainText))
                {
                    oMainTempList = str_Ticket_PlainText.Split(new string[] { "[~!@]" }, StringSplitOptions.RemoveEmptyEntries);

                    var oQuery = from oItem in oMainTempList
                                 select oItem;

                    foreach (var oRow in oQuery)
                    {
                        oSubTempList = oRow.Split(new string[] { ":" }, StringSplitOptions.None);
                        oList.Add(oSubTempList[0], oSubTempList[1]);
                    }
                }
            }
            else
            {
                oList.Add("USER_ID", "1");
                oList.Add("OWNER_ID", "1");
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("ResolveTicket");
            }
            #endregion
            #region Return Section.
            return oList;
            #endregion
        }
        #endregion
        #region IsValidTicket
        public bool IsValidTicket(string i_Input)
        {
            #region Declaration And Initialization Section.
            bool Is_ValidTicket = false;
            long? i_MinutesElapsedSinceMidnight = 0;
            string str_CurrentDate = string.Empty;
            Tools.Tools oTools = new Tools.Tools();
            Dictionary<string, string> oTicketParts = new Dictionary<string, string>();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "IsValidTicket";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return Convert.ToBoolean(oMethodInfo.Invoke(this, new object[] { i_Input }));
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("IsValidTicket");
            }
            #endregion
            #region Body Section.
            try
            {
                oTicketParts = ResolveTicket(i_Input);
                str_CurrentDate = oTools.GetDateString(DateTime.Today);

                if (oTicketParts["START_DATE"] == str_CurrentDate) // Session Started In Different Day.
                {
                    i_MinutesElapsedSinceMidnight = (long?)(DateTime.Now - DateTime.Today).TotalMinutes;

                    if (i_MinutesElapsedSinceMidnight <= Convert.ToInt32(oTicketParts["START_MINUTE"]) + Convert.ToInt32(oTicketParts["SESSION_PERIOD"]))
                    {
                        Is_ValidTicket = true;
                    }
                }

            }
            catch (Exception ex)
            {
                Is_ValidTicket = false;
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("IsValidTicket");
            }
            #endregion
            #region Return Section.
            return Is_ValidTicket;
            #endregion
        }
        #endregion
        #endregion


        #region Authenticate
        public User Authenticate(Params_Authenticate i_Params_Authenticate)
        {
            Tools.Tools oTools = new Tools.Tools();
            User oUser = new User();
            User UsertoEdit = new User();
            Crypto.MiniCryptoHelper oCrypto = new Crypto.MiniCryptoHelper();

            List<dynamic> oList = _AppContext.UP_GET_USER_BY_USERNAME(i_Params_Authenticate.USERNAME);
            if ((oList != null) && (oList.Count > 0))
            {
                if (oCrypto.Encrypt(i_Params_Authenticate.PASSWORD) == oList[0].PASSWORD)
                {
                    // check if not already logged in
                    //if (oList[0].IS_LOGGED_IN != true)
                    //{
                    //    UsertoEdit.USER_ID = oList[0].USER_ID;
                    //    UsertoEdit.USERNAME = oList[0].USERNAME;
                    //    UsertoEdit.PASSWORD = oList[0].PASSWORD;
                    //    UsertoEdit.OWNER_ID = oList[0].OWNER_ID;
                    //    UsertoEdit.ENTRY_DATE = oList[0].ENTRY_DATE;
                    //    UsertoEdit.IS_ACTIVE = oList[0].IS_ACTIVE;
                    //    UsertoEdit.USER_TYPE_CODE = oList[0].USER_TYPE_CODE;
                    //    UsertoEdit.IS_LOGGED_IN = true;
                    oUser.USER_ID = oList[0].USER_ID;
                    oUser.OWNER_ID = oList[0].OWNER_ID;
                    oUser.USER_TYPE_CODE = oList[0].USER_TYPE_CODE;

                    var i_MinutesElapsedSinceMidnight = (long?)(DateTime.Now - DateTime.Today).TotalMinutes;
                    string My_Ticket_PlainText = string.Format("USER_ID:{0}[~!@]OWNER_ID:{1}[~!@]START_DATE:{2}[~!@]START_MINUTE:{3}[~!@]" +
                        "SESSION_PERIOD:{4}[~!@]", oUser.USER_ID, oUser.OWNER_ID, oTools.GetDateTimeString(DateTime.Today),
                        i_MinutesElapsedSinceMidnight.ToString(), 60);
                    string str_Enc_Ticket = oCrypto.Encrypt(My_Ticket_PlainText);
                    oUser.My_ticket = System.Net.WebUtility.UrlEncode(str_Enc_Ticket);
                    // oUser.My_ticket = System.Net.WebUtility.UrlEncode(str_Enc_Ticket);
                    // Edit_User(UsertoEdit);

                    // }
                    // if user already logged in throw exception
                    //else
                    //{
                    //    // user already logged in message
                    //    throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0010));
                    //}
                }
                else
                {
                    throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_9999));
                }
            }
            else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0002));
            }



            return oUser;
        }

        #endregion
        #region De-Authenticate
        public User Deauthenticate(Params_Deauthenticate i_Params_Deauthenticate)
        {
            // Edit User ISLOGGED IN = false;

            Params_Get_User_By_USER_ID params_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
            params_Get_User_By_USER_ID.USER_ID = i_Params_Deauthenticate.USER_ID;

            User oUser = Get_User_By_USER_ID(params_Get_User_By_USER_ID);
            oUser.IS_LOGGED_IN = false;
            Edit_User(oUser);
            return oUser;
        }

        #endregion

        #region Sign in Player
        public void Sign_in_Player(Params_Sign_in_Player i_Params_Sign_in_Player)
        {
            Crypto.MiniCryptoHelper oCrypto = new Crypto.MiniCryptoHelper();
            i_Params_Sign_in_Player.Sign_in_User = new User();
            i_Params_Sign_in_Player.Sign_in_Player = new Player();
            //Check if username does not exist before 
            List<dynamic> oList = _AppContext.UP_GET_USER_BY_USERNAME(i_Params_Sign_in_Player.Sign_in_User.USERNAME);
            if (oList.Count == 0)
            {
                //Create User
                User oUser = new User();

                oUser.USER_ID = -1;
                oUser.USERNAME = i_Params_Sign_in_Player.Sign_in_User.USERNAME;
                oUser.PASSWORD = oCrypto.Encrypt(i_Params_Sign_in_Player.Sign_in_User.PASSWORD);
                oUser.USER_TYPE_CODE = "003";
                oUser.IS_ACTIVE = true;
                oUser.IS_LOGGED_IN = false;
                oUser.OWNER_ID = this.OwnerID;

                Edit_User(oUser);

                // Create Player
                Params_Get_User_By_USERNAME params_Get_User_By_USERNAME = new Params_Get_User_By_USERNAME();
                params_Get_User_By_USERNAME.USERNAME = oUser.USERNAME;
                List<User> user = Get_User_By_USERNAME(params_Get_User_By_USERNAME);

                Player oPlayer = new Player();
                oPlayer.PLAYER_ID = -1;
                oPlayer.USER_ID = Convert.ToInt32(user[0].USER_ID);
                oPlayer.FIRSTNAME = i_Params_Sign_in_Player.Sign_in_Player.FIRSTNAME;
                oPlayer.LASTNAME = i_Params_Sign_in_Player.Sign_in_Player.LASTNAME;
                oPlayer.EMAIL = i_Params_Sign_in_Player.Sign_in_Player.EMAIL;
                oPlayer.IS_BLOCKED = true;
                
                oPlayer.OWNER_ID = this.OwnerID;
                Edit_Player(oPlayer);

                // Notification for BACK-OFFICE
                Notification oNote = new Notification();
                oNote.OWNER_ID = this.OwnerID;
                oNote.NOTIFICATION_ID = -1;
                oNote.USER_ID = 1;
                oNote.DESCRIPTION = String.Format("Player: {0} {1} have just Signed in. Please take necessary actions to unblock", oPlayer.FIRSTNAME, oPlayer.LASTNAME);
                Edit_Notification(oNote);

            }
            else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0002));
            }

        }
        #endregion

        #region Sign in Coach
        public void Sign_in_Coach(Params_Sign_in_Coach i_Params_Sign_in_Coach)
        {
            Crypto.MiniCryptoHelper oCrypto = new Crypto.MiniCryptoHelper();
            i_Params_Sign_in_Coach.Sign_in_User = new User();
            i_Params_Sign_in_Coach.Sign_in_Coach = new Coach();
            //Check if username does not exist before 
            List<dynamic> oList = _AppContext.UP_GET_USER_BY_USERNAME(i_Params_Sign_in_Coach.Sign_in_User.USERNAME);
            if (oList.Count == 0)
            {
                //Create User
                User oUser = new User();
                oUser.USER_ID = -1;
                oUser.USERNAME = i_Params_Sign_in_Coach.Sign_in_User.USERNAME;
                oUser.PASSWORD = oCrypto.Encrypt(i_Params_Sign_in_Coach.Sign_in_User.PASSWORD);
                oUser.USER_TYPE_CODE = "002";
                oUser.IS_ACTIVE = true;
                oUser.IS_LOGGED_IN = false;
                oUser.OWNER_ID = this.OwnerID;

                Edit_User(oUser);

                // Create Student
                Params_Get_User_By_USERNAME params_Get_User_By_USERNAME = new Params_Get_User_By_USERNAME();
                params_Get_User_By_USERNAME.USERNAME = oUser.USERNAME;
                List<User> user = Get_User_By_USERNAME(params_Get_User_By_USERNAME);

                
               


                Coach oCoach = new Coach();
                oCoach.COACH_ID = -1;
                oCoach.USER_ID = Convert.ToInt32(user[0].USER_ID);
                oCoach.FIRSTNAME = i_Params_Sign_in_Coach.Sign_in_Coach.FIRSTNAME;
                oCoach.LASTNAME = i_Params_Sign_in_Coach.Sign_in_Coach.LASTNAME;
                oCoach.EMAIL = i_Params_Sign_in_Coach.Sign_in_Coach.EMAIL;
                oCoach.MOBILE = i_Params_Sign_in_Coach.Sign_in_Coach.MOBILE;
                oCoach.SCORE = 0;
                oCoach.IS_BLOCKED = true;
                oCoach.OWNER_ID = this.OwnerID;
                Edit_Coach(oCoach);

                Params_Get_Coach_By_USER_ID params_Get_Coach_By_USER_ID = new Params_Get_Coach_By_USER_ID();
                params_Get_Coach_By_USER_ID.USER_ID = Convert.ToInt32(user[0].USER_ID);
                List<Coach> Coach = Get_Coach_By_USER_ID(params_Get_Coach_By_USER_ID);
                foreach (int Cat in i_Params_Sign_in_Coach.Sports)
                {
                    Coachsport tCat = new Coachsport();
                    tCat.COACHSPORT_ID = -1;
                    tCat.COACH_ID = Coach[0].COACH_ID;
                    tCat.SPORT_ID = Cat;
                    tCat.OWNER_ID = this.OwnerID;
                }
                // Notification for BACK-OFFICE
                Notification oNote = new Notification();
                oNote.OWNER_ID = this.OwnerID;
                oNote.NOTIFICATION_ID = -1;
                oNote.USER_ID = 1;
                oNote.DESCRIPTION = String.Format("Coach: {0} {1} have just Signed in. Please take necessary actions to unblock", oCoach.FIRSTNAME, oCoach.LASTNAME);
                Edit_Notification(oNote);
            }
            else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0002));
            }

        }
        #endregion
    }

    #region Params_Authenticate
    public class Params_Authenticate
    {
        public string USERNAME { get; set; }
        public string PASSWORD { get; set; }
    }
    #endregion
    #region Params_Deauthenticate

    public class Params_Deauthenticate
    {
        public int USER_ID { get; set; }
    }
    #endregion
    #region Params Sign in Player
    public class Params_Sign_in_Player
    {
        public Player Sign_in_Player { get; set; }
        public User Sign_in_User { get; set; }
    }
    #endregion
    #region Params Sign in Coach
    public class Params_Sign_in_Coach
    {
        public Coach Sign_in_Coach { get; set; }
        public User Sign_in_User { get; set; }

        public List<Int32?> Sports { get; set; }
    }
    #endregion

    #region My_Classes
    #region User
    public partial class User
    {
        public string My_ticket { get; set; }
    }
    #endregion

    public partial class Direct_message
    {
        public User My_Author { get; set; }

        public User My_Recipient { get; set; }
    }

    public partial class Report_coach
    {
        public User My_User { get; set; }
        //public Coach My_Coach { get; set; }
    }

    public partial class Report_player
    {
        public User My_User { get; set; }
       // public Player My_Player { get; set; }
    }

    public partial class Coach
    {
        public User My_User { get; set; }
        public Player My_Player { get; set; }
    }

    public partial class Notification
    {
        public User My_User { get; set; }
    }

    public partial class Player
    {
        public Coach My_Coach { get; set; }

        public User My_User { get; set; }
    }

    #endregion
    #region Business Entities
    #region Setup
    #region SetupEntry
    public class SetupEntry
    {
        #region Properties
        public Int32? OWNER_ID { get; set; }
        public string TBL_NAME { get; set; }
        public string CODE_NAME { get; set; }
        public bool? ISSYSTEM { get; set; }
        public bool? ISDELETEABLE { get; set; }
        public bool? ISUPDATEABLE { get; set; }
        public bool? ISVISIBLE { get; set; }
        public bool? ISDELETED { get; set; }
        public Int32? DISPLAY_ORDER { get; set; }
        public string CODE_VALUE_EN { get; set; }
        public string CODE_VALUE_FR { get; set; }
        public string CODE_VALUE_AR { get; set; }
        public string ENTRY_DATE { get; set; }
        public long? ENTRY_USER_ID { get; set; }
        public string NOTES { get; set; }

        public string INVARIANT_VALUE { get; set; }
        #endregion
    }
    #endregion    
    #endregion
    #region Uploaded_file
    public partial class Uploaded_file
    {
        public string My_URL { get; set; }
    }
    #endregion
    #endregion
}


