using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
public partial class BLC
{
public Coach_leaderboards Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_Adv(Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID)
{
Coach_leaderboards oCoach_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_Adv");}
#region Body Section.
DALC.Coach_leaderboards oDBEntry = _AppContext.Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_Adv(i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID.COACH_LEADERBOARDS_ID);
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_Adv");}
return oCoach_leaderboards;
}
public Player_leaderboards Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_Adv(Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID)
{
Player_leaderboards oPlayer_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_Adv");}
#region Body Section.
DALC.Player_leaderboards oDBEntry = _AppContext.Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_Adv(i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID.PLAYER_LEADERBOARDS_ID);
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_Adv");}
return oPlayer_leaderboards;
}
public Playersport Get_Playersport_By_PLAYERSPORT_ID_Adv(Params_Get_Playersport_By_PLAYERSPORT_ID i_Params_Get_Playersport_By_PLAYERSPORT_ID)
{
Playersport oPlayersport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYERSPORT_ID_Adv");}
#region Body Section.
DALC.Playersport oDBEntry = _AppContext.Get_Playersport_By_PLAYERSPORT_ID_Adv(i_Params_Get_Playersport_By_PLAYERSPORT_ID.PLAYERSPORT_ID);
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYERSPORT_ID_Adv");}
return oPlayersport;
}
public Sport Get_Sport_By_SPORT_ID_Adv(Params_Get_Sport_By_SPORT_ID i_Params_Get_Sport_By_SPORT_ID)
{
Sport oSport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_SPORT_ID_Adv");}
#region Body Section.
DALC.Sport oDBEntry = _AppContext.Get_Sport_By_SPORT_ID_Adv(i_Params_Get_Sport_By_SPORT_ID.SPORT_ID);
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_SPORT_ID_Adv");}
return oSport;
}
public Coachsport Get_Coachsport_By_COACHSPORT_ID_Adv(Params_Get_Coachsport_By_COACHSPORT_ID i_Params_Get_Coachsport_By_COACHSPORT_ID)
{
Coachsport oCoachsport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACHSPORT_ID_Adv");}
#region Body Section.
DALC.Coachsport oDBEntry = _AppContext.Get_Coachsport_By_COACHSPORT_ID_Adv(i_Params_Get_Coachsport_By_COACHSPORT_ID.COACHSPORT_ID);
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACHSPORT_ID_Adv");}
return oCoachsport;
}
public Coach_evaluation Get_Coach_evaluation_By_COACH_EVALUATION_ID_Adv(Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID)
{
Coach_evaluation oCoach_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID_Adv");}
#region Body Section.
DALC.Coach_evaluation oDBEntry = _AppContext.Get_Coach_evaluation_By_COACH_EVALUATION_ID_Adv(i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID.COACH_EVALUATION_ID);
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID_Adv");}
return oCoach_evaluation;
}
public Currency Get_Currency_By_CURRENCY_ID_Adv(Params_Get_Currency_By_CURRENCY_ID i_Params_Get_Currency_By_CURRENCY_ID)
{
Currency oCurrency = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_CURRENCY_ID_Adv");}
#region Body Section.
DALC.Currency oDBEntry = _AppContext.Get_Currency_By_CURRENCY_ID_Adv(i_Params_Get_Currency_By_CURRENCY_ID.CURRENCY_ID);
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_CURRENCY_ID_Adv");}
return oCurrency;
}
public Session_evaluation Get_Session_evaluation_By_SESSION_EVALUATION_ID_Adv(Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID)
{
Session_evaluation oSession_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID_Adv");}
#region Body Section.
DALC.Session_evaluation oDBEntry = _AppContext.Get_Session_evaluation_By_SESSION_EVALUATION_ID_Adv(i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID.SESSION_EVALUATION_ID);
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID_Adv");}
return oSession_evaluation;
}
public Taken_session Get_Taken_session_By_TAKEN_SESSION_ID_Adv(Params_Get_Taken_session_By_TAKEN_SESSION_ID i_Params_Get_Taken_session_By_TAKEN_SESSION_ID)
{
Taken_session oTaken_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID_Adv");}
#region Body Section.
DALC.Taken_session oDBEntry = _AppContext.Get_Taken_session_By_TAKEN_SESSION_ID_Adv(i_Params_Get_Taken_session_By_TAKEN_SESSION_ID.TAKEN_SESSION_ID);
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID_Adv");}
return oTaken_session;
}
public Scheduled_session Get_Scheduled_session_By_SCHEDULED_SESSION_ID_Adv(Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID)
{
Scheduled_session oScheduled_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID_Adv");}
#region Body Section.
DALC.Scheduled_session oDBEntry = _AppContext.Get_Scheduled_session_By_SCHEDULED_SESSION_ID_Adv(i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID.SCHEDULED_SESSION_ID);
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID_Adv");}
return oScheduled_session;
}
public Notification Get_Notification_By_NOTIFICATION_ID_Adv(Params_Get_Notification_By_NOTIFICATION_ID i_Params_Get_Notification_By_NOTIFICATION_ID)
{
Notification oNotification = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID_Adv");}
#region Body Section.
DALC.Notification oDBEntry = _AppContext.Get_Notification_By_NOTIFICATION_ID_Adv(i_Params_Get_Notification_By_NOTIFICATION_ID.NOTIFICATION_ID);
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID_Adv");}
return oNotification;
}
public Comment Get_Comment_By_COMMENT_ID_Adv(Params_Get_Comment_By_COMMENT_ID i_Params_Get_Comment_By_COMMENT_ID)
{
Comment oComment = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COMMENT_ID_Adv");}
#region Body Section.
DALC.Comment oDBEntry = _AppContext.Get_Comment_By_COMMENT_ID_Adv(i_Params_Get_Comment_By_COMMENT_ID.COMMENT_ID);
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COMMENT_ID_Adv");}
return oComment;
}
public Report_coach Get_Report_coach_By_REPORT_COACH_ID_Adv(Params_Get_Report_coach_By_REPORT_COACH_ID i_Params_Get_Report_coach_By_REPORT_COACH_ID)
{
Report_coach oReport_coach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_REPORT_COACH_ID_Adv");}
#region Body Section.
DALC.Report_coach oDBEntry = _AppContext.Get_Report_coach_By_REPORT_COACH_ID_Adv(i_Params_Get_Report_coach_By_REPORT_COACH_ID.REPORT_COACH_ID);
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_REPORT_COACH_ID_Adv");}
return oReport_coach;
}
public Comment_report Get_Comment_report_By_COMMENT_REPORT_ID_Adv(Params_Get_Comment_report_By_COMMENT_REPORT_ID i_Params_Get_Comment_report_By_COMMENT_REPORT_ID)
{
Comment_report oComment_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID_Adv");}
#region Body Section.
DALC.Comment_report oDBEntry = _AppContext.Get_Comment_report_By_COMMENT_REPORT_ID_Adv(i_Params_Get_Comment_report_By_COMMENT_REPORT_ID.COMMENT_REPORT_ID);
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID_Adv");}
return oComment_report;
}
public User Get_User_By_USER_ID_Adv(Params_Get_User_By_USER_ID i_Params_Get_User_By_USER_ID)
{
User oUser = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID_Adv");}
#region Body Section.
DALC.User oDBEntry = _AppContext.Get_User_By_USER_ID_Adv(i_Params_Get_User_By_USER_ID.USER_ID);
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID_Adv");}
return oUser;
}
public Direct_message Get_Direct_message_By_DIRECT_MESSAGE_ID_Adv(Params_Get_Direct_message_By_DIRECT_MESSAGE_ID i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID)
{
Direct_message oDirect_message = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID_Adv");}
#region Body Section.
DALC.Direct_message oDBEntry = _AppContext.Get_Direct_message_By_DIRECT_MESSAGE_ID_Adv(i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID.DIRECT_MESSAGE_ID);
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID_Adv");}
return oDirect_message;
}
public Report_player Get_Report_player_By_REPORT_PLAYER_ID_Adv(Params_Get_Report_player_By_REPORT_PLAYER_ID i_Params_Get_Report_player_By_REPORT_PLAYER_ID)
{
Report_player oReport_player = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_REPORT_PLAYER_ID_Adv");}
#region Body Section.
DALC.Report_player oDBEntry = _AppContext.Get_Report_player_By_REPORT_PLAYER_ID_Adv(i_Params_Get_Report_player_By_REPORT_PLAYER_ID.REPORT_PLAYER_ID);
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_REPORT_PLAYER_ID_Adv");}
return oReport_player;
}
public Coach Get_Coach_By_COACH_ID_Adv(Params_Get_Coach_By_COACH_ID i_Params_Get_Coach_By_COACH_ID)
{
Coach oCoach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_COACH_ID_Adv");}
#region Body Section.
DALC.Coach oDBEntry = _AppContext.Get_Coach_By_COACH_ID_Adv(i_Params_Get_Coach_By_COACH_ID.COACH_ID);
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oCoach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oCoach.My_User);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_COACH_ID_Adv");}
return oCoach;
}
public Player Get_Player_By_PLAYER_ID_Adv(Params_Get_Player_By_PLAYER_ID i_Params_Get_Player_By_PLAYER_ID)
{
Player oPlayer = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_PLAYER_ID_Adv");}
#region Body Section.
DALC.Player oDBEntry = _AppContext.Get_Player_By_PLAYER_ID_Adv(i_Params_Get_Player_By_PLAYER_ID.PLAYER_ID);
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oPlayer.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oPlayer.My_User);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_PLAYER_ID_Adv");}
return oPlayer;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_Adv(Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List)
{
Coach_leaderboards oCoach_leaderboards = null;
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_SP oParams_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_SP = new Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_Adv");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_Adv(i_Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List.COACH_LEADERBOARDS_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_Adv(Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List)
{
Player_leaderboards oPlayer_leaderboards = null;
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_SP oParams_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_SP = new Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_Adv");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_Adv(i_Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List.PLAYER_LEADERBOARDS_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYERSPORT_ID_List_Adv(Params_Get_Playersport_By_PLAYERSPORT_ID_List i_Params_Get_Playersport_By_PLAYERSPORT_ID_List)
{
Playersport oPlayersport = null;
List<Playersport> oList = new List<Playersport>();
Params_Get_Playersport_By_PLAYERSPORT_ID_List_SP oParams_Get_Playersport_By_PLAYERSPORT_ID_List_SP = new Params_Get_Playersport_By_PLAYERSPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYERSPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_PLAYERSPORT_ID_List_Adv(i_Params_Get_Playersport_By_PLAYERSPORT_ID_List.PLAYERSPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYERSPORT_ID_List_Adv");}
return oList;
}
public List<Sport> Get_Sport_By_SPORT_ID_List_Adv(Params_Get_Sport_By_SPORT_ID_List i_Params_Get_Sport_By_SPORT_ID_List)
{
Sport oSport = null;
List<Sport> oList = new List<Sport>();
Params_Get_Sport_By_SPORT_ID_List_SP oParams_Get_Sport_By_SPORT_ID_List_SP = new Params_Get_Sport_By_SPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_SPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_SPORT_ID_List_Adv(i_Params_Get_Sport_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_SPORT_ID_List_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACHSPORT_ID_List_Adv(Params_Get_Coachsport_By_COACHSPORT_ID_List i_Params_Get_Coachsport_By_COACHSPORT_ID_List)
{
Coachsport oCoachsport = null;
List<Coachsport> oList = new List<Coachsport>();
Params_Get_Coachsport_By_COACHSPORT_ID_List_SP oParams_Get_Coachsport_By_COACHSPORT_ID_List_SP = new Params_Get_Coachsport_By_COACHSPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACHSPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_COACHSPORT_ID_List_Adv(i_Params_Get_Coachsport_By_COACHSPORT_ID_List.COACHSPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACHSPORT_ID_List_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_Adv(Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List)
{
Coach_evaluation oCoach_evaluation = null;
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_SP oParams_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_SP = new Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_Adv");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_Adv(i_Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List.COACH_EVALUATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_Adv");}
return oList;
}
public List<Currency> Get_Currency_By_CURRENCY_ID_List_Adv(Params_Get_Currency_By_CURRENCY_ID_List i_Params_Get_Currency_By_CURRENCY_ID_List)
{
Currency oCurrency = null;
List<Currency> oList = new List<Currency>();
Params_Get_Currency_By_CURRENCY_ID_List_SP oParams_Get_Currency_By_CURRENCY_ID_List_SP = new Params_Get_Currency_By_CURRENCY_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_CURRENCY_ID_List_Adv");}
#region Body Section.
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_CURRENCY_ID_List_Adv(i_Params_Get_Currency_By_CURRENCY_ID_List.CURRENCY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_CURRENCY_ID_List_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_Adv(Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List)
{
Session_evaluation oSession_evaluation = null;
List<Session_evaluation> oList = new List<Session_evaluation>();
Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_SP oParams_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_SP = new Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_Adv");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_Adv(i_Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List.SESSION_EVALUATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_TAKEN_SESSION_ID_List_Adv(Params_Get_Taken_session_By_TAKEN_SESSION_ID_List i_Params_Get_Taken_session_By_TAKEN_SESSION_ID_List)
{
Taken_session oTaken_session = null;
List<Taken_session> oList = new List<Taken_session>();
Params_Get_Taken_session_By_TAKEN_SESSION_ID_List_SP oParams_Get_Taken_session_By_TAKEN_SESSION_ID_List_SP = new Params_Get_Taken_session_By_TAKEN_SESSION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID_List_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_TAKEN_SESSION_ID_List_Adv(i_Params_Get_Taken_session_By_TAKEN_SESSION_ID_List.TAKEN_SESSION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_TAKEN_SESSION_ID_List_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_Adv(Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List)
{
Scheduled_session oScheduled_session = null;
List<Scheduled_session> oList = new List<Scheduled_session>();
Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_SP oParams_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_SP = new Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_Adv(i_Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List.SCHEDULED_SESSION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List_Adv(Params_Get_Notification_By_NOTIFICATION_ID_List i_Params_Get_Notification_By_NOTIFICATION_ID_List)
{
Notification oNotification = null;
List<Notification> oList = new List<Notification>();
Params_Get_Notification_By_NOTIFICATION_ID_List_SP oParams_Get_Notification_By_NOTIFICATION_ID_List_SP = new Params_Get_Notification_By_NOTIFICATION_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID_List_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_NOTIFICATION_ID_List_Adv(i_Params_Get_Notification_By_NOTIFICATION_ID_List.NOTIFICATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID_List_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_COMMENT_ID_List_Adv(Params_Get_Comment_By_COMMENT_ID_List i_Params_Get_Comment_By_COMMENT_ID_List)
{
Comment oComment = null;
List<Comment> oList = new List<Comment>();
Params_Get_Comment_By_COMMENT_ID_List_SP oParams_Get_Comment_By_COMMENT_ID_List_SP = new Params_Get_Comment_By_COMMENT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COMMENT_ID_List_Adv");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_COMMENT_ID_List_Adv(i_Params_Get_Comment_By_COMMENT_ID_List.COMMENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COMMENT_ID_List_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_REPORT_COACH_ID_List_Adv(Params_Get_Report_coach_By_REPORT_COACH_ID_List i_Params_Get_Report_coach_By_REPORT_COACH_ID_List)
{
Report_coach oReport_coach = null;
List<Report_coach> oList = new List<Report_coach>();
Params_Get_Report_coach_By_REPORT_COACH_ID_List_SP oParams_Get_Report_coach_By_REPORT_COACH_ID_List_SP = new Params_Get_Report_coach_By_REPORT_COACH_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_REPORT_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_REPORT_COACH_ID_List_Adv(i_Params_Get_Report_coach_By_REPORT_COACH_ID_List.REPORT_COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_REPORT_COACH_ID_List_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_REPORT_ID_List_Adv(Params_Get_Comment_report_By_COMMENT_REPORT_ID_List i_Params_Get_Comment_report_By_COMMENT_REPORT_ID_List)
{
Comment_report oComment_report = null;
List<Comment_report> oList = new List<Comment_report>();
Params_Get_Comment_report_By_COMMENT_REPORT_ID_List_SP oParams_Get_Comment_report_By_COMMENT_REPORT_ID_List_SP = new Params_Get_Comment_report_By_COMMENT_REPORT_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COMMENT_REPORT_ID_List_Adv(i_Params_Get_Comment_report_By_COMMENT_REPORT_ID_List.COMMENT_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_REPORT_ID_List_Adv");}
return oList;
}
public List<User> Get_User_By_USER_ID_List_Adv(Params_Get_User_By_USER_ID_List i_Params_Get_User_By_USER_ID_List)
{
User oUser = null;
List<User> oList = new List<User>();
Params_Get_User_By_USER_ID_List_SP oParams_Get_User_By_USER_ID_List_SP = new Params_Get_User_By_USER_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USER_ID_List_Adv(i_Params_Get_User_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID_List_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_DIRECT_MESSAGE_ID_List_Adv(Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List)
{
Direct_message oDirect_message = null;
List<Direct_message> oList = new List<Direct_message>();
Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List_SP oParams_Get_Direct_message_By_DIRECT_MESSAGE_ID_List_SP = new Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID_List_Adv");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_DIRECT_MESSAGE_ID_List_Adv(i_Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List.DIRECT_MESSAGE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_DIRECT_MESSAGE_ID_List_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_REPORT_PLAYER_ID_List_Adv(Params_Get_Report_player_By_REPORT_PLAYER_ID_List i_Params_Get_Report_player_By_REPORT_PLAYER_ID_List)
{
Report_player oReport_player = null;
List<Report_player> oList = new List<Report_player>();
Params_Get_Report_player_By_REPORT_PLAYER_ID_List_SP oParams_Get_Report_player_By_REPORT_PLAYER_ID_List_SP = new Params_Get_Report_player_By_REPORT_PLAYER_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_REPORT_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_REPORT_PLAYER_ID_List_Adv(i_Params_Get_Report_player_By_REPORT_PLAYER_ID_List.REPORT_PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_REPORT_PLAYER_ID_List_Adv");}
return oList;
}
public List<Coach> Get_Coach_By_COACH_ID_List_Adv(Params_Get_Coach_By_COACH_ID_List i_Params_Get_Coach_By_COACH_ID_List)
{
Coach oCoach = null;
List<Coach> oList = new List<Coach>();
Params_Get_Coach_By_COACH_ID_List_SP oParams_Get_Coach_By_COACH_ID_List_SP = new Params_Get_Coach_By_COACH_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_COACH_ID_List_Adv(i_Params_Get_Coach_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oCoach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oCoach.My_User);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_COACH_ID_List_Adv");}
return oList;
}
public List<Player> Get_Player_By_PLAYER_ID_List_Adv(Params_Get_Player_By_PLAYER_ID_List i_Params_Get_Player_By_PLAYER_ID_List)
{
Player oPlayer = null;
List<Player> oList = new List<Player>();
Params_Get_Player_By_PLAYER_ID_List_SP oParams_Get_Player_By_PLAYER_ID_List_SP = new Params_Get_Player_By_PLAYER_ID_List_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_PLAYER_ID_List_Adv(i_Params_Get_Player_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oPlayer.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oPlayer.My_User);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_OWNER_ID_Adv(Params_Get_Coach_leaderboards_By_OWNER_ID i_Params_Get_Coach_leaderboards_By_OWNER_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_OWNER_ID_Adv(i_Params_Get_Coach_leaderboards_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_OWNER_ID_Adv");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_Adv(Params_Get_Coach_leaderboards_By_COACH_ID i_Params_Get_Coach_leaderboards_By_COACH_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_COACH_ID_Adv(i_Params_Get_Coach_leaderboards_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_ID_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_OWNER_ID_Adv(Params_Get_Player_leaderboards_By_OWNER_ID i_Params_Get_Player_leaderboards_By_OWNER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_OWNER_ID_Adv(i_Params_Get_Player_leaderboards_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_OWNER_ID_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_Adv(Params_Get_Player_leaderboards_By_PLAYER_ID i_Params_Get_Player_leaderboards_By_PLAYER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_PLAYER_ID_Adv(i_Params_Get_Player_leaderboards_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_ID_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_OWNER_ID_Adv(Params_Get_Playersport_By_OWNER_ID i_Params_Get_Playersport_By_OWNER_ID)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_OWNER_ID_Adv(i_Params_Get_Playersport_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_OWNER_ID_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID_Adv(Params_Get_Playersport_By_PLAYER_ID i_Params_Get_Playersport_By_PLAYER_ID)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_PLAYER_ID_Adv(i_Params_Get_Playersport_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYER_ID_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID_Adv(Params_Get_Playersport_By_SPORT_ID i_Params_Get_Playersport_By_SPORT_ID)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_SPORT_ID_Adv");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_SPORT_ID_Adv(i_Params_Get_Playersport_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_SPORT_ID_Adv");}
return oList;
}
public List<Sport> Get_Sport_By_OWNER_ID_Adv(Params_Get_Sport_By_OWNER_ID i_Params_Get_Sport_By_OWNER_ID)
{
List<Sport> oList = new List<Sport>();
Sport oSport = new Sport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_OWNER_ID_Adv(i_Params_Get_Sport_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_OWNER_ID_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_OWNER_ID_Adv(Params_Get_Coachsport_By_OWNER_ID i_Params_Get_Coachsport_By_OWNER_ID)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_OWNER_ID_Adv(i_Params_Get_Coachsport_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_OWNER_ID_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID_Adv(Params_Get_Coachsport_By_SPORT_ID i_Params_Get_Coachsport_By_SPORT_ID)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_SPORT_ID_Adv");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_SPORT_ID_Adv(i_Params_Get_Coachsport_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_SPORT_ID_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID_Adv(Params_Get_Coachsport_By_COACH_ID i_Params_Get_Coachsport_By_COACH_ID)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_COACH_ID_Adv(i_Params_Get_Coachsport_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACH_ID_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_OWNER_ID_Adv(Params_Get_Coach_evaluation_By_OWNER_ID i_Params_Get_Coach_evaluation_By_OWNER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_OWNER_ID_Adv(i_Params_Get_Coach_evaluation_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_OWNER_ID_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_Adv(Params_Get_Coach_evaluation_By_PLAYER_ID i_Params_Get_Coach_evaluation_By_PLAYER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_PLAYER_ID_Adv(i_Params_Get_Coach_evaluation_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_PLAYER_ID_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_Adv(Params_Get_Coach_evaluation_By_COACH_ID i_Params_Get_Coach_evaluation_By_COACH_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_COACH_ID_Adv(i_Params_Get_Coach_evaluation_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_ID_Adv");}
return oList;
}
public List<Currency> Get_Currency_By_OWNER_ID_Adv(Params_Get_Currency_By_OWNER_ID i_Params_Get_Currency_By_OWNER_ID)
{
List<Currency> oList = new List<Currency>();
Currency oCurrency = new Currency();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_OWNER_ID_Adv(i_Params_Get_Currency_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_OWNER_ID_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_OWNER_ID_Adv(Params_Get_Session_evaluation_By_OWNER_ID i_Params_Get_Session_evaluation_By_OWNER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_OWNER_ID_Adv(i_Params_Get_Session_evaluation_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_OWNER_ID_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_Adv(Params_Get_Session_evaluation_By_COACH_ID i_Params_Get_Session_evaluation_By_COACH_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_COACH_ID_Adv(i_Params_Get_Session_evaluation_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_COACH_ID_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_Adv(Params_Get_Session_evaluation_By_PLAYER_ID i_Params_Get_Session_evaluation_By_PLAYER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_PLAYER_ID_Adv(i_Params_Get_Session_evaluation_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_PLAYER_ID_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_OWNER_ID_Adv(Params_Get_Taken_session_By_OWNER_ID i_Params_Get_Taken_session_By_OWNER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_OWNER_ID_Adv(i_Params_Get_Taken_session_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_OWNER_ID_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID_Adv(Params_Get_Taken_session_By_COACH_ID i_Params_Get_Taken_session_By_COACH_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_COACH_ID_Adv(i_Params_Get_Taken_session_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_COACH_ID_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID_Adv(Params_Get_Taken_session_By_PLAYER_ID i_Params_Get_Taken_session_By_PLAYER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_PLAYER_ID_Adv(i_Params_Get_Taken_session_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_PLAYER_ID_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID_Adv(Params_Get_Taken_session_By_SPORT_ID i_Params_Get_Taken_session_By_SPORT_ID)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_SPORT_ID_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_SPORT_ID_Adv(i_Params_Get_Taken_session_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_SPORT_ID_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_OWNER_ID_Adv(Params_Get_Scheduled_session_By_OWNER_ID i_Params_Get_Scheduled_session_By_OWNER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_OWNER_ID_Adv(i_Params_Get_Scheduled_session_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_OWNER_ID_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_Adv(Params_Get_Scheduled_session_By_PLAYER_ID i_Params_Get_Scheduled_session_By_PLAYER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_PLAYER_ID_Adv(i_Params_Get_Scheduled_session_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_PLAYER_ID_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_Adv(Params_Get_Scheduled_session_By_COACH_ID i_Params_Get_Scheduled_session_By_COACH_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_COACH_ID_Adv(i_Params_Get_Scheduled_session_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_COACH_ID_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_Adv(Params_Get_Scheduled_session_By_SPORT_ID i_Params_Get_Scheduled_session_By_SPORT_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SPORT_ID_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_SPORT_ID_Adv(i_Params_Get_Scheduled_session_By_SPORT_ID.SPORT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SPORT_ID_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID_Adv(Params_Get_Notification_By_OWNER_ID i_Params_Get_Notification_By_OWNER_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_OWNER_ID_Adv(i_Params_Get_Notification_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_OWNER_ID_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_Adv(Params_Get_Notification_By_USER_ID i_Params_Get_Notification_By_USER_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID_Adv(i_Params_Get_Notification_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_OWNER_ID_Adv(Params_Get_Comment_By_OWNER_ID i_Params_Get_Comment_By_OWNER_ID)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_OWNER_ID_Adv(i_Params_Get_Comment_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_OWNER_ID_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID_Adv(Params_Get_Comment_By_PLAYER_ID i_Params_Get_Comment_By_PLAYER_ID)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_PLAYER_ID_Adv(i_Params_Get_Comment_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_PLAYER_ID_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID_Adv(Params_Get_Comment_By_COACH_ID i_Params_Get_Comment_By_COACH_ID)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_COACH_ID_Adv(i_Params_Get_Comment_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COACH_ID_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_OWNER_ID_Adv(Params_Get_Report_coach_By_OWNER_ID i_Params_Get_Report_coach_By_OWNER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_OWNER_ID_Adv(i_Params_Get_Report_coach_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_OWNER_ID_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID_Adv(Params_Get_Report_coach_By_USER_ID i_Params_Get_Report_coach_By_USER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_USER_ID_Adv(i_Params_Get_Report_coach_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_USER_ID_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID_Adv(Params_Get_Report_coach_By_COACH_ID i_Params_Get_Report_coach_By_COACH_ID)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_COACH_ID_Adv(i_Params_Get_Report_coach_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_COACH_ID_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_OWNER_ID_Adv(Params_Get_Comment_report_By_OWNER_ID i_Params_Get_Comment_report_By_OWNER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_OWNER_ID_Adv(i_Params_Get_Comment_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_OWNER_ID_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID_Adv(Params_Get_Comment_report_By_PLAYER_ID i_Params_Get_Comment_report_By_PLAYER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_PLAYER_ID_Adv(i_Params_Get_Comment_report_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_PLAYER_ID_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID_Adv(Params_Get_Comment_report_By_COACH_ID i_Params_Get_Comment_report_By_COACH_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COACH_ID_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COACH_ID_Adv(i_Params_Get_Comment_report_By_COACH_ID.COACH_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COACH_ID_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID_Adv(Params_Get_Comment_report_By_COMMENT_ID i_Params_Get_Comment_report_By_COMMENT_ID)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_ID_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COMMENT_ID_Adv(i_Params_Get_Comment_report_By_COMMENT_ID.COMMENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_ID_Adv");}
return oList;
}
public List<User> Get_User_By_OWNER_ID_Adv(Params_Get_User_By_OWNER_ID i_Params_Get_User_By_OWNER_ID)
{
List<User> oList = new List<User>();
User oUser = new User();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_OWNER_ID_Adv(i_Params_Get_User_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_OWNER_ID_Adv");}
return oList;
}
public List<User> Get_User_By_USERNAME_Adv(Params_Get_User_By_USERNAME i_Params_Get_User_By_USERNAME)
{
List<User> oList = new List<User>();
User oUser = new User();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USERNAME_Adv");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USERNAME_Adv(i_Params_Get_User_By_USERNAME.USERNAME);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USERNAME_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_OWNER_ID_Adv(Params_Get_Direct_message_By_OWNER_ID i_Params_Get_Direct_message_By_OWNER_ID)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_OWNER_ID_Adv(i_Params_Get_Direct_message_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_OWNER_ID_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID_Adv(Params_Get_Direct_message_By_AUTHOR_ID i_Params_Get_Direct_message_By_AUTHOR_ID)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_AUTHOR_ID_Adv");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_AUTHOR_ID_Adv(i_Params_Get_Direct_message_By_AUTHOR_ID.AUTHOR_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_AUTHOR_ID_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_Adv(Params_Get_Direct_message_By_RECIPIENT_ID i_Params_Get_Direct_message_By_RECIPIENT_ID)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_RECIPIENT_ID_Adv");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_RECIPIENT_ID_Adv(i_Params_Get_Direct_message_By_RECIPIENT_ID.RECIPIENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_RECIPIENT_ID_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_OWNER_ID_Adv(Params_Get_Report_player_By_OWNER_ID i_Params_Get_Report_player_By_OWNER_ID)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_OWNER_ID_Adv(i_Params_Get_Report_player_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_OWNER_ID_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID_Adv(Params_Get_Report_player_By_USER_ID i_Params_Get_Report_player_By_USER_ID)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_USER_ID_Adv(i_Params_Get_Report_player_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_USER_ID_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID_Adv(Params_Get_Report_player_By_PLAYER_ID i_Params_Get_Report_player_By_PLAYER_ID)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_PLAYER_ID_Adv");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_PLAYER_ID_Adv(i_Params_Get_Report_player_By_PLAYER_ID.PLAYER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_PLAYER_ID_Adv");}
return oList;
}
public List<Coach> Get_Coach_By_OWNER_ID_Adv(Params_Get_Coach_By_OWNER_ID i_Params_Get_Coach_By_OWNER_ID)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_OWNER_ID_Adv(i_Params_Get_Coach_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oCoach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oCoach.My_User);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_OWNER_ID_Adv");}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID_Adv(Params_Get_Coach_By_USER_ID i_Params_Get_Coach_By_USER_ID)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_USER_ID_Adv(i_Params_Get_Coach_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oCoach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oCoach.My_User);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_USER_ID_Adv");}
return oList;
}
public List<Player> Get_Player_By_OWNER_ID_Adv(Params_Get_Player_By_OWNER_ID i_Params_Get_Player_By_OWNER_ID)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_OWNER_ID_Adv(i_Params_Get_Player_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oPlayer.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oPlayer.My_User);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_OWNER_ID_Adv");}
return oList;
}
public List<Player> Get_Player_By_USER_ID_Adv(Params_Get_Player_By_USER_ID i_Params_Get_Player_By_USER_ID)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_USER_ID_Adv(i_Params_Get_Player_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oPlayer.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oPlayer.My_User);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_USER_ID_Adv");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_List_Adv(Params_Get_Coach_leaderboards_By_COACH_ID_List i_Params_Get_Coach_leaderboards_By_COACH_ID_List)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_COACH_ID_List_Adv(i_Params_Get_Coach_leaderboards_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_COACH_ID_List_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_List_Adv(Params_Get_Player_leaderboards_By_PLAYER_ID_List i_Params_Get_Player_leaderboards_By_PLAYER_ID_List)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_PLAYER_ID_List_Adv(i_Params_Get_Player_leaderboards_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID_List_Adv(Params_Get_Playersport_By_PLAYER_ID_List i_Params_Get_Playersport_By_PLAYER_ID_List)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_PLAYER_ID_List_Adv(i_Params_Get_Playersport_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID_List_Adv(Params_Get_Playersport_By_SPORT_ID_List i_Params_Get_Playersport_By_SPORT_ID_List)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_SPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_SPORT_ID_List_Adv(i_Params_Get_Playersport_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_SPORT_ID_List_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID_List_Adv(Params_Get_Coachsport_By_SPORT_ID_List i_Params_Get_Coachsport_By_SPORT_ID_List)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_SPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_SPORT_ID_List_Adv(i_Params_Get_Coachsport_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_SPORT_ID_List_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID_List_Adv(Params_Get_Coachsport_By_COACH_ID_List i_Params_Get_Coachsport_By_COACH_ID_List)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_COACH_ID_List_Adv(i_Params_Get_Coachsport_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_COACH_ID_List_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_List_Adv(Params_Get_Coach_evaluation_By_PLAYER_ID_List i_Params_Get_Coach_evaluation_By_PLAYER_ID_List)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_PLAYER_ID_List_Adv(i_Params_Get_Coach_evaluation_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_List_Adv(Params_Get_Coach_evaluation_By_COACH_ID_List i_Params_Get_Coach_evaluation_By_COACH_ID_List)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_COACH_ID_List_Adv(i_Params_Get_Coach_evaluation_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_COACH_ID_List_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_List_Adv(Params_Get_Session_evaluation_By_COACH_ID_List i_Params_Get_Session_evaluation_By_COACH_ID_List)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_COACH_ID_List_Adv(i_Params_Get_Session_evaluation_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_COACH_ID_List_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_List_Adv(Params_Get_Session_evaluation_By_PLAYER_ID_List i_Params_Get_Session_evaluation_By_PLAYER_ID_List)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_PLAYER_ID_List_Adv(i_Params_Get_Session_evaluation_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID_List_Adv(Params_Get_Taken_session_By_COACH_ID_List i_Params_Get_Taken_session_By_COACH_ID_List)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_COACH_ID_List_Adv(i_Params_Get_Taken_session_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_COACH_ID_List_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID_List_Adv(Params_Get_Taken_session_By_PLAYER_ID_List i_Params_Get_Taken_session_By_PLAYER_ID_List)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_PLAYER_ID_List_Adv(i_Params_Get_Taken_session_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID_List_Adv(Params_Get_Taken_session_By_SPORT_ID_List i_Params_Get_Taken_session_By_SPORT_ID_List)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_SPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_SPORT_ID_List_Adv(i_Params_Get_Taken_session_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_SPORT_ID_List_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_List_Adv(Params_Get_Scheduled_session_By_PLAYER_ID_List i_Params_Get_Scheduled_session_By_PLAYER_ID_List)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_PLAYER_ID_List_Adv(i_Params_Get_Scheduled_session_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_List_Adv(Params_Get_Scheduled_session_By_COACH_ID_List i_Params_Get_Scheduled_session_By_COACH_ID_List)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_COACH_ID_List_Adv(i_Params_Get_Scheduled_session_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_COACH_ID_List_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_List_Adv(Params_Get_Scheduled_session_By_SPORT_ID_List i_Params_Get_Scheduled_session_By_SPORT_ID_List)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_SPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_SPORT_ID_List_Adv(i_Params_Get_Scheduled_session_By_SPORT_ID_List.SPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_SPORT_ID_List_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List_Adv(Params_Get_Notification_By_USER_ID_List i_Params_Get_Notification_By_USER_ID_List)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID_List_Adv(i_Params_Get_Notification_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID_List_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID_List_Adv(Params_Get_Comment_By_PLAYER_ID_List i_Params_Get_Comment_By_PLAYER_ID_List)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_PLAYER_ID_List_Adv(i_Params_Get_Comment_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID_List_Adv(Params_Get_Comment_By_COACH_ID_List i_Params_Get_Comment_By_COACH_ID_List)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_COACH_ID_List_Adv(i_Params_Get_Comment_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_COACH_ID_List_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID_List_Adv(Params_Get_Report_coach_By_USER_ID_List i_Params_Get_Report_coach_By_USER_ID_List)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_USER_ID_List_Adv(i_Params_Get_Report_coach_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_USER_ID_List_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID_List_Adv(Params_Get_Report_coach_By_COACH_ID_List i_Params_Get_Report_coach_By_COACH_ID_List)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_COACH_ID_List_Adv(i_Params_Get_Report_coach_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_COACH_ID_List_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID_List_Adv(Params_Get_Comment_report_By_PLAYER_ID_List i_Params_Get_Comment_report_By_PLAYER_ID_List)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_PLAYER_ID_List_Adv(i_Params_Get_Comment_report_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID_List_Adv(Params_Get_Comment_report_By_COACH_ID_List i_Params_Get_Comment_report_By_COACH_ID_List)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COACH_ID_List_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COACH_ID_List_Adv(i_Params_Get_Comment_report_By_COACH_ID_List.COACH_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COACH_ID_List_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID_List_Adv(Params_Get_Comment_report_By_COMMENT_ID_List i_Params_Get_Comment_report_By_COMMENT_ID_List)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_COMMENT_ID_List_Adv");}
#region Body Section.
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_COMMENT_ID_List_Adv(i_Params_Get_Comment_report_By_COMMENT_ID_List.COMMENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_COMMENT_ID_List_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID_List_Adv(Params_Get_Direct_message_By_AUTHOR_ID_List i_Params_Get_Direct_message_By_AUTHOR_ID_List)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_AUTHOR_ID_List_Adv");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_AUTHOR_ID_List_Adv(i_Params_Get_Direct_message_By_AUTHOR_ID_List.AUTHOR_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_AUTHOR_ID_List_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_List_Adv(Params_Get_Direct_message_By_RECIPIENT_ID_List i_Params_Get_Direct_message_By_RECIPIENT_ID_List)
{
List<Direct_message> oList = new List<Direct_message>();
Direct_message oDirect_message = new Direct_message();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_RECIPIENT_ID_List_Adv");}
#region Body Section.
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_RECIPIENT_ID_List_Adv(i_Params_Get_Direct_message_By_RECIPIENT_ID_List.RECIPIENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_RECIPIENT_ID_List_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID_List_Adv(Params_Get_Report_player_By_USER_ID_List i_Params_Get_Report_player_By_USER_ID_List)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_USER_ID_List_Adv(i_Params_Get_Report_player_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_USER_ID_List_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID_List_Adv(Params_Get_Report_player_By_PLAYER_ID_List i_Params_Get_Report_player_By_PLAYER_ID_List)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_PLAYER_ID_List_Adv");}
#region Body Section.
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_PLAYER_ID_List_Adv(i_Params_Get_Report_player_By_PLAYER_ID_List.PLAYER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_PLAYER_ID_List_Adv");}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID_List_Adv(Params_Get_Coach_By_USER_ID_List i_Params_Get_Coach_By_USER_ID_List)
{
List<Coach> oList = new List<Coach>();
Coach oCoach = new Coach();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_USER_ID_List_Adv(i_Params_Get_Coach_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oCoach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oCoach.My_User);
oList.Add(oCoach);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_USER_ID_List_Adv");}
return oList;
}
public List<Player> Get_Player_By_USER_ID_List_Adv(Params_Get_Player_By_USER_ID_List i_Params_Get_Player_By_USER_ID_List)
{
List<Player> oList = new List<Player>();
Player oPlayer = new Player();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_USER_ID_List_Adv(i_Params_Get_Player_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oPlayer.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oPlayer.My_User);
oList.Add(oPlayer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_USER_ID_List_Adv");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_Adv(Params_Get_Coach_leaderboards_By_Criteria i_Params_Get_Coach_leaderboards_By_Criteria)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
long? tmp_TOTAL_COUNT = 0;
Coach_leaderboards oCoach_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Criteria.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW = 1000000; }
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Criteria_Adv(i_Params_Get_Coach_leaderboards_By_Criteria.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Criteria.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Criteria.START_ROW,i_Params_Get_Coach_leaderboards_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Criteria_Adv");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_Adv(Params_Get_Coach_leaderboards_By_Where i_Params_Get_Coach_leaderboards_By_Where)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
long? tmp_TOTAL_COUNT = 0;
Coach_leaderboards oCoach_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Where.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Where.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Where.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Where.END_ROW = 1000000; }
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Where_Adv(i_Params_Get_Coach_leaderboards_By_Where.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Where.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Where.START_ROW,i_Params_Get_Coach_leaderboards_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Where_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_Adv(Params_Get_Player_leaderboards_By_Criteria i_Params_Get_Player_leaderboards_By_Criteria)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
long? tmp_TOTAL_COUNT = 0;
Player_leaderboards oPlayer_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Criteria.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Criteria.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Criteria.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Criteria.END_ROW = 1000000; }
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Criteria_Adv(i_Params_Get_Player_leaderboards_By_Criteria.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Criteria.OWNER_ID,i_Params_Get_Player_leaderboards_By_Criteria.START_ROW,i_Params_Get_Player_leaderboards_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Criteria_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where_Adv(Params_Get_Player_leaderboards_By_Where i_Params_Get_Player_leaderboards_By_Where)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
long? tmp_TOTAL_COUNT = 0;
Player_leaderboards oPlayer_leaderboards = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Where.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Where.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Where.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Where.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Where.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Where.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Where.END_ROW = 1000000; }
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Where_Adv(i_Params_Get_Player_leaderboards_By_Where.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Where.OWNER_ID,i_Params_Get_Player_leaderboards_By_Where.START_ROW,i_Params_Get_Player_leaderboards_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Where_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria_Adv(Params_Get_Playersport_By_Criteria i_Params_Get_Playersport_By_Criteria)
{
List<Playersport> oList = new List<Playersport>();
long? tmp_TOTAL_COUNT = 0;
Playersport oPlayersport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Criteria.OWNER_ID == null) || (i_Params_Get_Playersport_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Criteria.START_ROW == null) { i_Params_Get_Playersport_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Criteria.END_ROW == null) || (i_Params_Get_Playersport_By_Criteria.END_ROW == 0)) { i_Params_Get_Playersport_By_Criteria.END_ROW = 1000000; }
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Criteria_Adv(i_Params_Get_Playersport_By_Criteria.DESCRIPTION,i_Params_Get_Playersport_By_Criteria.OWNER_ID,i_Params_Get_Playersport_By_Criteria.START_ROW,i_Params_Get_Playersport_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Criteria_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_Where_Adv(Params_Get_Playersport_By_Where i_Params_Get_Playersport_By_Where)
{
List<Playersport> oList = new List<Playersport>();
long? tmp_TOTAL_COUNT = 0;
Playersport oPlayersport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Where.OWNER_ID == null) || (i_Params_Get_Playersport_By_Where.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Where.START_ROW == null) { i_Params_Get_Playersport_By_Where.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Where.END_ROW == null) || (i_Params_Get_Playersport_By_Where.END_ROW == 0)) { i_Params_Get_Playersport_By_Where.END_ROW = 1000000; }
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Where_Adv(i_Params_Get_Playersport_By_Where.DESCRIPTION,i_Params_Get_Playersport_By_Where.OWNER_ID,i_Params_Get_Playersport_By_Where.START_ROW,i_Params_Get_Playersport_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Where_Adv");}
return oList;
}
public List<Sport> Get_Sport_By_Criteria_Adv(Params_Get_Sport_By_Criteria i_Params_Get_Sport_By_Criteria)
{
List<Sport> oList = new List<Sport>();
long? tmp_TOTAL_COUNT = 0;
Sport oSport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Sport_By_Criteria.OWNER_ID == null) || (i_Params_Get_Sport_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Sport_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Sport_By_Criteria.START_ROW == null) { i_Params_Get_Sport_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Sport_By_Criteria.END_ROW == null) || (i_Params_Get_Sport_By_Criteria.END_ROW == 0)) { i_Params_Get_Sport_By_Criteria.END_ROW = 1000000; }
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_Criteria_Adv(i_Params_Get_Sport_By_Criteria.SPORT_NAME,i_Params_Get_Sport_By_Criteria.DESCRIPTION,i_Params_Get_Sport_By_Criteria.OWNER_ID,i_Params_Get_Sport_By_Criteria.START_ROW,i_Params_Get_Sport_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
i_Params_Get_Sport_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_Criteria_Adv");}
return oList;
}
public List<Sport> Get_Sport_By_Where_Adv(Params_Get_Sport_By_Where i_Params_Get_Sport_By_Where)
{
List<Sport> oList = new List<Sport>();
long? tmp_TOTAL_COUNT = 0;
Sport oSport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Sport_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Sport_By_Where.OWNER_ID == null) || (i_Params_Get_Sport_By_Where.OWNER_ID == 0)) { i_Params_Get_Sport_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Sport_By_Where.START_ROW == null) { i_Params_Get_Sport_By_Where.START_ROW = 0; }
if ((i_Params_Get_Sport_By_Where.END_ROW == null) || (i_Params_Get_Sport_By_Where.END_ROW == 0)) { i_Params_Get_Sport_By_Where.END_ROW = 1000000; }
List<DALC.Sport> oList_DBEntries = _AppContext.Get_Sport_By_Where_Adv(i_Params_Get_Sport_By_Where.SPORT_NAME,i_Params_Get_Sport_By_Where.DESCRIPTION,i_Params_Get_Sport_By_Where.OWNER_ID,i_Params_Get_Sport_By_Where.START_ROW,i_Params_Get_Sport_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSport = new Sport();
oTools.CopyPropValues(oDBEntry, oSport);
oList.Add(oSport);
}
}
i_Params_Get_Sport_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Sport_By_Where_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria_Adv(Params_Get_Coachsport_By_Criteria i_Params_Get_Coachsport_By_Criteria)
{
List<Coachsport> oList = new List<Coachsport>();
long? tmp_TOTAL_COUNT = 0;
Coachsport oCoachsport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Criteria.START_ROW == null) { i_Params_Get_Coachsport_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Criteria.END_ROW == null) || (i_Params_Get_Coachsport_By_Criteria.END_ROW == 0)) { i_Params_Get_Coachsport_By_Criteria.END_ROW = 1000000; }
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Criteria_Adv(i_Params_Get_Coachsport_By_Criteria.DESCRIPTION,i_Params_Get_Coachsport_By_Criteria.OWNER_ID,i_Params_Get_Coachsport_By_Criteria.START_ROW,i_Params_Get_Coachsport_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Criteria_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where_Adv(Params_Get_Coachsport_By_Where i_Params_Get_Coachsport_By_Where)
{
List<Coachsport> oList = new List<Coachsport>();
long? tmp_TOTAL_COUNT = 0;
Coachsport oCoachsport = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Where.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Where.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Where.START_ROW == null) { i_Params_Get_Coachsport_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Where.END_ROW == null) || (i_Params_Get_Coachsport_By_Where.END_ROW == 0)) { i_Params_Get_Coachsport_By_Where.END_ROW = 1000000; }
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Where_Adv(i_Params_Get_Coachsport_By_Where.DESCRIPTION,i_Params_Get_Coachsport_By_Where.OWNER_ID,i_Params_Get_Coachsport_By_Where.START_ROW,i_Params_Get_Coachsport_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Where_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_Adv(Params_Get_Coach_evaluation_By_Criteria i_Params_Get_Coach_evaluation_By_Criteria)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
long? tmp_TOTAL_COUNT = 0;
Coach_evaluation oCoach_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Criteria.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Criteria.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Criteria.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Criteria.END_ROW = 1000000; }
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Criteria_Adv(i_Params_Get_Coach_evaluation_By_Criteria.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Criteria.OWNER_ID,i_Params_Get_Coach_evaluation_By_Criteria.START_ROW,i_Params_Get_Coach_evaluation_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Criteria_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where_Adv(Params_Get_Coach_evaluation_By_Where i_Params_Get_Coach_evaluation_By_Where)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
long? tmp_TOTAL_COUNT = 0;
Coach_evaluation oCoach_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Where.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Where.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Where.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Where.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Where.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Where.END_ROW = 1000000; }
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Where_Adv(i_Params_Get_Coach_evaluation_By_Where.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Where.OWNER_ID,i_Params_Get_Coach_evaluation_By_Where.START_ROW,i_Params_Get_Coach_evaluation_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Where_Adv");}
return oList;
}
public List<Currency> Get_Currency_By_Criteria_Adv(Params_Get_Currency_By_Criteria i_Params_Get_Currency_By_Criteria)
{
List<Currency> oList = new List<Currency>();
long? tmp_TOTAL_COUNT = 0;
Currency oCurrency = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Currency_By_Criteria.OWNER_ID == null) || (i_Params_Get_Currency_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Currency_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Currency_By_Criteria.START_ROW == null) { i_Params_Get_Currency_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Currency_By_Criteria.END_ROW == null) || (i_Params_Get_Currency_By_Criteria.END_ROW == 0)) { i_Params_Get_Currency_By_Criteria.END_ROW = 1000000; }
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_Criteria_Adv(i_Params_Get_Currency_By_Criteria.CURRENCY_NAME,i_Params_Get_Currency_By_Criteria.OWNER_ID,i_Params_Get_Currency_By_Criteria.START_ROW,i_Params_Get_Currency_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
i_Params_Get_Currency_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_Criteria_Adv");}
return oList;
}
public List<Currency> Get_Currency_By_Where_Adv(Params_Get_Currency_By_Where i_Params_Get_Currency_By_Where)
{
List<Currency> oList = new List<Currency>();
long? tmp_TOTAL_COUNT = 0;
Currency oCurrency = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Currency_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Currency_By_Where.OWNER_ID == null) || (i_Params_Get_Currency_By_Where.OWNER_ID == 0)) { i_Params_Get_Currency_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Currency_By_Where.START_ROW == null) { i_Params_Get_Currency_By_Where.START_ROW = 0; }
if ((i_Params_Get_Currency_By_Where.END_ROW == null) || (i_Params_Get_Currency_By_Where.END_ROW == 0)) { i_Params_Get_Currency_By_Where.END_ROW = 1000000; }
List<DALC.Currency> oList_DBEntries = _AppContext.Get_Currency_By_Where_Adv(i_Params_Get_Currency_By_Where.CURRENCY_NAME,i_Params_Get_Currency_By_Where.OWNER_ID,i_Params_Get_Currency_By_Where.START_ROW,i_Params_Get_Currency_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCurrency = new Currency();
oTools.CopyPropValues(oDBEntry, oCurrency);
oList.Add(oCurrency);
}
}
i_Params_Get_Currency_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Currency_By_Where_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria_Adv(Params_Get_Session_evaluation_By_Criteria i_Params_Get_Session_evaluation_By_Criteria)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
long? tmp_TOTAL_COUNT = 0;
Session_evaluation oSession_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Criteria.START_ROW == null) { i_Params_Get_Session_evaluation_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Criteria.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Criteria.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Criteria.END_ROW = 1000000; }
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Criteria_Adv(i_Params_Get_Session_evaluation_By_Criteria.DESCRIPTION,i_Params_Get_Session_evaluation_By_Criteria.OWNER_ID,i_Params_Get_Session_evaluation_By_Criteria.START_ROW,i_Params_Get_Session_evaluation_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Criteria_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where_Adv(Params_Get_Session_evaluation_By_Where i_Params_Get_Session_evaluation_By_Where)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
long? tmp_TOTAL_COUNT = 0;
Session_evaluation oSession_evaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Where.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Where.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Where.START_ROW == null) { i_Params_Get_Session_evaluation_By_Where.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Where.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Where.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Where.END_ROW = 1000000; }
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Where_Adv(i_Params_Get_Session_evaluation_By_Where.DESCRIPTION,i_Params_Get_Session_evaluation_By_Where.OWNER_ID,i_Params_Get_Session_evaluation_By_Where.START_ROW,i_Params_Get_Session_evaluation_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Where_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria_Adv(Params_Get_Taken_session_By_Criteria i_Params_Get_Taken_session_By_Criteria)
{
List<Taken_session> oList = new List<Taken_session>();
long? tmp_TOTAL_COUNT = 0;
Taken_session oTaken_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Criteria.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Criteria.START_ROW == null) { i_Params_Get_Taken_session_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Criteria.END_ROW == null) || (i_Params_Get_Taken_session_By_Criteria.END_ROW == 0)) { i_Params_Get_Taken_session_By_Criteria.END_ROW = 1000000; }
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Criteria_Adv(i_Params_Get_Taken_session_By_Criteria.DATETIME,i_Params_Get_Taken_session_By_Criteria.OWNER_ID,i_Params_Get_Taken_session_By_Criteria.START_ROW,i_Params_Get_Taken_session_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Criteria_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where_Adv(Params_Get_Taken_session_By_Where i_Params_Get_Taken_session_By_Where)
{
List<Taken_session> oList = new List<Taken_session>();
long? tmp_TOTAL_COUNT = 0;
Taken_session oTaken_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Where.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Where.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Where.START_ROW == null) { i_Params_Get_Taken_session_By_Where.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Where.END_ROW == null) || (i_Params_Get_Taken_session_By_Where.END_ROW == 0)) { i_Params_Get_Taken_session_By_Where.END_ROW = 1000000; }
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Where_Adv(i_Params_Get_Taken_session_By_Where.DATETIME,i_Params_Get_Taken_session_By_Where.OWNER_ID,i_Params_Get_Taken_session_By_Where.START_ROW,i_Params_Get_Taken_session_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Where_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria_Adv(Params_Get_Scheduled_session_By_Criteria i_Params_Get_Scheduled_session_By_Criteria)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
long? tmp_TOTAL_COUNT = 0;
Scheduled_session oScheduled_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Criteria.START_ROW == null) { i_Params_Get_Scheduled_session_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Criteria.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Criteria.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Criteria.END_ROW = 1000000; }
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Criteria_Adv(i_Params_Get_Scheduled_session_By_Criteria.DATE_TIME,i_Params_Get_Scheduled_session_By_Criteria.DESCRIPTION,i_Params_Get_Scheduled_session_By_Criteria.OWNER_ID,i_Params_Get_Scheduled_session_By_Criteria.START_ROW,i_Params_Get_Scheduled_session_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Criteria_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where_Adv(Params_Get_Scheduled_session_By_Where i_Params_Get_Scheduled_session_By_Where)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
long? tmp_TOTAL_COUNT = 0;
Scheduled_session oScheduled_session = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Where.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Where.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Where.START_ROW == null) { i_Params_Get_Scheduled_session_By_Where.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Where.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Where.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Where.END_ROW = 1000000; }
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Where_Adv(i_Params_Get_Scheduled_session_By_Where.DATE_TIME,i_Params_Get_Scheduled_session_By_Where.DESCRIPTION,i_Params_Get_Scheduled_session_By_Where.OWNER_ID,i_Params_Get_Scheduled_session_By_Where.START_ROW,i_Params_Get_Scheduled_session_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Where_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_Criteria_Adv(Params_Get_Notification_By_Criteria i_Params_Get_Notification_By_Criteria)
{
List<Notification> oList = new List<Notification>();
long? tmp_TOTAL_COUNT = 0;
Notification oNotification = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Notification_By_Criteria.OWNER_ID == null) || (i_Params_Get_Notification_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Notification_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Criteria.START_ROW == null) { i_Params_Get_Notification_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Criteria.END_ROW == null) || (i_Params_Get_Notification_By_Criteria.END_ROW == 0)) { i_Params_Get_Notification_By_Criteria.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Criteria_Adv(i_Params_Get_Notification_By_Criteria.TITLE,i_Params_Get_Notification_By_Criteria.DESCRIPTION,i_Params_Get_Notification_By_Criteria.OWNER_ID,i_Params_Get_Notification_By_Criteria.START_ROW,i_Params_Get_Notification_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Criteria_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_Where_Adv(Params_Get_Notification_By_Where i_Params_Get_Notification_By_Where)
{
List<Notification> oList = new List<Notification>();
long? tmp_TOTAL_COUNT = 0;
Notification oNotification = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Notification_By_Where.OWNER_ID == null) || (i_Params_Get_Notification_By_Where.OWNER_ID == 0)) { i_Params_Get_Notification_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Where.START_ROW == null) { i_Params_Get_Notification_By_Where.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Where.END_ROW == null) || (i_Params_Get_Notification_By_Where.END_ROW == 0)) { i_Params_Get_Notification_By_Where.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Where_Adv(i_Params_Get_Notification_By_Where.TITLE,i_Params_Get_Notification_By_Where.DESCRIPTION,i_Params_Get_Notification_By_Where.OWNER_ID,i_Params_Get_Notification_By_Where.START_ROW,i_Params_Get_Notification_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Where_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_Criteria_Adv(Params_Get_Comment_By_Criteria i_Params_Get_Comment_By_Criteria)
{
List<Comment> oList = new List<Comment>();
long? tmp_TOTAL_COUNT = 0;
Comment oComment = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_By_Criteria.OWNER_ID == null) || (i_Params_Get_Comment_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Comment_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Criteria.START_ROW == null) { i_Params_Get_Comment_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Criteria.END_ROW == null) || (i_Params_Get_Comment_By_Criteria.END_ROW == 0)) { i_Params_Get_Comment_By_Criteria.END_ROW = 1000000; }
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Criteria_Adv(i_Params_Get_Comment_By_Criteria.TITLE,i_Params_Get_Comment_By_Criteria.DESCRIPTION,i_Params_Get_Comment_By_Criteria.OWNER_ID,i_Params_Get_Comment_By_Criteria.START_ROW,i_Params_Get_Comment_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Criteria_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_Where_Adv(Params_Get_Comment_By_Where i_Params_Get_Comment_By_Where)
{
List<Comment> oList = new List<Comment>();
long? tmp_TOTAL_COUNT = 0;
Comment oComment = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_By_Where.OWNER_ID == null) || (i_Params_Get_Comment_By_Where.OWNER_ID == 0)) { i_Params_Get_Comment_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Where.START_ROW == null) { i_Params_Get_Comment_By_Where.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Where.END_ROW == null) || (i_Params_Get_Comment_By_Where.END_ROW == 0)) { i_Params_Get_Comment_By_Where.END_ROW = 1000000; }
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Where_Adv(i_Params_Get_Comment_By_Where.TITLE,i_Params_Get_Comment_By_Where.DESCRIPTION,i_Params_Get_Comment_By_Where.OWNER_ID,i_Params_Get_Comment_By_Where.START_ROW,i_Params_Get_Comment_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Where_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria_Adv(Params_Get_Report_coach_By_Criteria i_Params_Get_Report_coach_By_Criteria)
{
List<Report_coach> oList = new List<Report_coach>();
long? tmp_TOTAL_COUNT = 0;
Report_coach oReport_coach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Criteria.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Criteria.START_ROW == null) { i_Params_Get_Report_coach_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Criteria.END_ROW == null) || (i_Params_Get_Report_coach_By_Criteria.END_ROW == 0)) { i_Params_Get_Report_coach_By_Criteria.END_ROW = 1000000; }
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Criteria_Adv(i_Params_Get_Report_coach_By_Criteria.DESCRIPTION,i_Params_Get_Report_coach_By_Criteria.OWNER_ID,i_Params_Get_Report_coach_By_Criteria.START_ROW,i_Params_Get_Report_coach_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Criteria_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where_Adv(Params_Get_Report_coach_By_Where i_Params_Get_Report_coach_By_Where)
{
List<Report_coach> oList = new List<Report_coach>();
long? tmp_TOTAL_COUNT = 0;
Report_coach oReport_coach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Where.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Where.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Where.START_ROW == null) { i_Params_Get_Report_coach_By_Where.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Where.END_ROW == null) || (i_Params_Get_Report_coach_By_Where.END_ROW == 0)) { i_Params_Get_Report_coach_By_Where.END_ROW = 1000000; }
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Where_Adv(i_Params_Get_Report_coach_By_Where.DESCRIPTION,i_Params_Get_Report_coach_By_Where.OWNER_ID,i_Params_Get_Report_coach_By_Where.START_ROW,i_Params_Get_Report_coach_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Where_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria_Adv(Params_Get_Comment_report_By_Criteria i_Params_Get_Comment_report_By_Criteria)
{
List<Comment_report> oList = new List<Comment_report>();
long? tmp_TOTAL_COUNT = 0;
Comment_report oComment_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Criteria.START_ROW == null) { i_Params_Get_Comment_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Criteria.END_ROW == null) || (i_Params_Get_Comment_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Comment_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Criteria_Adv(i_Params_Get_Comment_report_By_Criteria.DESCRIPTION,i_Params_Get_Comment_report_By_Criteria.OWNER_ID,i_Params_Get_Comment_report_By_Criteria.START_ROW,i_Params_Get_Comment_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Criteria_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where_Adv(Params_Get_Comment_report_By_Where i_Params_Get_Comment_report_By_Where)
{
List<Comment_report> oList = new List<Comment_report>();
long? tmp_TOTAL_COUNT = 0;
Comment_report oComment_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Where.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Where.START_ROW == null) { i_Params_Get_Comment_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Where.END_ROW == null) || (i_Params_Get_Comment_report_By_Where.END_ROW == 0)) { i_Params_Get_Comment_report_By_Where.END_ROW = 1000000; }
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Where_Adv(i_Params_Get_Comment_report_By_Where.DESCRIPTION,i_Params_Get_Comment_report_By_Where.OWNER_ID,i_Params_Get_Comment_report_By_Where.START_ROW,i_Params_Get_Comment_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Where_Adv");}
return oList;
}
public List<User> Get_User_By_Criteria_Adv(Params_Get_User_By_Criteria i_Params_Get_User_By_Criteria)
{
List<User> oList = new List<User>();
long? tmp_TOTAL_COUNT = 0;
User oUser = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_User_By_Criteria.OWNER_ID == null) || (i_Params_Get_User_By_Criteria.OWNER_ID == 0)) { i_Params_Get_User_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Criteria.START_ROW == null) { i_Params_Get_User_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_User_By_Criteria.END_ROW == null) || (i_Params_Get_User_By_Criteria.END_ROW == 0)) { i_Params_Get_User_By_Criteria.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Criteria_Adv(i_Params_Get_User_By_Criteria.USERNAME,i_Params_Get_User_By_Criteria.PASSWORD,i_Params_Get_User_By_Criteria.USER_TYPE_CODE,i_Params_Get_User_By_Criteria.OWNER_ID,i_Params_Get_User_By_Criteria.START_ROW,i_Params_Get_User_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
i_Params_Get_User_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Criteria_Adv");}
return oList;
}
public List<User> Get_User_By_Where_Adv(Params_Get_User_By_Where i_Params_Get_User_By_Where)
{
List<User> oList = new List<User>();
long? tmp_TOTAL_COUNT = 0;
User oUser = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_User_By_Where.OWNER_ID == null) || (i_Params_Get_User_By_Where.OWNER_ID == 0)) { i_Params_Get_User_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Where.START_ROW == null) { i_Params_Get_User_By_Where.START_ROW = 0; }
if ((i_Params_Get_User_By_Where.END_ROW == null) || (i_Params_Get_User_By_Where.END_ROW == 0)) { i_Params_Get_User_By_Where.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Where_Adv(i_Params_Get_User_By_Where.USERNAME,i_Params_Get_User_By_Where.PASSWORD,i_Params_Get_User_By_Where.USER_TYPE_CODE,i_Params_Get_User_By_Where.OWNER_ID,i_Params_Get_User_By_Where.START_ROW,i_Params_Get_User_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
i_Params_Get_User_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Where_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_Criteria_Adv(Params_Get_Direct_message_By_Criteria i_Params_Get_Direct_message_By_Criteria)
{
List<Direct_message> oList = new List<Direct_message>();
long? tmp_TOTAL_COUNT = 0;
Direct_message oDirect_message = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Direct_message_By_Criteria.OWNER_ID == null) || (i_Params_Get_Direct_message_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Direct_message_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Direct_message_By_Criteria.START_ROW == null) { i_Params_Get_Direct_message_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Direct_message_By_Criteria.END_ROW == null) || (i_Params_Get_Direct_message_By_Criteria.END_ROW == 0)) { i_Params_Get_Direct_message_By_Criteria.END_ROW = 1000000; }
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_Criteria_Adv(i_Params_Get_Direct_message_By_Criteria.DESCRIPTION,i_Params_Get_Direct_message_By_Criteria.DATETIME,i_Params_Get_Direct_message_By_Criteria.OWNER_ID,i_Params_Get_Direct_message_By_Criteria.START_ROW,i_Params_Get_Direct_message_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
i_Params_Get_Direct_message_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_Criteria_Adv");}
return oList;
}
public List<Direct_message> Get_Direct_message_By_Where_Adv(Params_Get_Direct_message_By_Where i_Params_Get_Direct_message_By_Where)
{
List<Direct_message> oList = new List<Direct_message>();
long? tmp_TOTAL_COUNT = 0;
Direct_message oDirect_message = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Direct_message_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Direct_message_By_Where.OWNER_ID == null) || (i_Params_Get_Direct_message_By_Where.OWNER_ID == 0)) { i_Params_Get_Direct_message_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Direct_message_By_Where.START_ROW == null) { i_Params_Get_Direct_message_By_Where.START_ROW = 0; }
if ((i_Params_Get_Direct_message_By_Where.END_ROW == null) || (i_Params_Get_Direct_message_By_Where.END_ROW == 0)) { i_Params_Get_Direct_message_By_Where.END_ROW = 1000000; }
List<DALC.Direct_message> oList_DBEntries = _AppContext.Get_Direct_message_By_Where_Adv(i_Params_Get_Direct_message_By_Where.DESCRIPTION,i_Params_Get_Direct_message_By_Where.DATETIME,i_Params_Get_Direct_message_By_Where.OWNER_ID,i_Params_Get_Direct_message_By_Where.START_ROW,i_Params_Get_Direct_message_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oDirect_message = new Direct_message();
oTools.CopyPropValues(oDBEntry, oDirect_message);
oDirect_message.My_Author = new User();
oTools.CopyPropValues(oDBEntry.My_Author, oDirect_message.My_Author);
oDirect_message.My_Recipient = new User();
oTools.CopyPropValues(oDBEntry.My_Recipient, oDirect_message.My_Recipient);
oList.Add(oDirect_message);
}
}
i_Params_Get_Direct_message_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Direct_message_By_Where_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria_Adv(Params_Get_Report_player_By_Criteria i_Params_Get_Report_player_By_Criteria)
{
List<Report_player> oList = new List<Report_player>();
long? tmp_TOTAL_COUNT = 0;
Report_player oReport_player = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Criteria.OWNER_ID == null) || (i_Params_Get_Report_player_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Criteria.START_ROW == null) { i_Params_Get_Report_player_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Criteria.END_ROW == null) || (i_Params_Get_Report_player_By_Criteria.END_ROW == 0)) { i_Params_Get_Report_player_By_Criteria.END_ROW = 1000000; }
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Criteria_Adv(i_Params_Get_Report_player_By_Criteria.DESCRIPTION,i_Params_Get_Report_player_By_Criteria.OWNER_ID,i_Params_Get_Report_player_By_Criteria.START_ROW,i_Params_Get_Report_player_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Criteria_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_Where_Adv(Params_Get_Report_player_By_Where i_Params_Get_Report_player_By_Where)
{
List<Report_player> oList = new List<Report_player>();
long? tmp_TOTAL_COUNT = 0;
Report_player oReport_player = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Where.OWNER_ID == null) || (i_Params_Get_Report_player_By_Where.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Where.START_ROW == null) { i_Params_Get_Report_player_By_Where.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Where.END_ROW == null) || (i_Params_Get_Report_player_By_Where.END_ROW == 0)) { i_Params_Get_Report_player_By_Where.END_ROW = 1000000; }
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Where_Adv(i_Params_Get_Report_player_By_Where.DESCRIPTION,i_Params_Get_Report_player_By_Where.OWNER_ID,i_Params_Get_Report_player_By_Where.START_ROW,i_Params_Get_Report_player_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Where_Adv");}
return oList;
}
public List<Coach> Get_Coach_By_Criteria_Adv(Params_Get_Coach_By_Criteria i_Params_Get_Coach_By_Criteria)
{
List<Coach> oList = new List<Coach>();
long? tmp_TOTAL_COUNT = 0;
Coach oCoach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_By_Criteria.OWNER_ID == null) || (i_Params_Get_Coach_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Coach_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_By_Criteria.START_ROW == null) { i_Params_Get_Coach_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Coach_By_Criteria.END_ROW == null) || (i_Params_Get_Coach_By_Criteria.END_ROW == 0)) { i_Params_Get_Coach_By_Criteria.END_ROW = 1000000; }
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_Criteria_Adv(i_Params_Get_Coach_By_Criteria.FIRSTNAME,i_Params_Get_Coach_By_Criteria.LASTNAME,i_Params_Get_Coach_By_Criteria.EMAIL,i_Params_Get_Coach_By_Criteria.MOBILE,i_Params_Get_Coach_By_Criteria.GEO_LOCATION,i_Params_Get_Coach_By_Criteria.OWNER_ID,i_Params_Get_Coach_By_Criteria.START_ROW,i_Params_Get_Coach_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oCoach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oCoach.My_User);
oList.Add(oCoach);
}
}
i_Params_Get_Coach_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_Criteria_Adv");}
return oList;
}
public List<Coach> Get_Coach_By_Where_Adv(Params_Get_Coach_By_Where i_Params_Get_Coach_By_Where)
{
List<Coach> oList = new List<Coach>();
long? tmp_TOTAL_COUNT = 0;
Coach oCoach = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_By_Where.OWNER_ID == null) || (i_Params_Get_Coach_By_Where.OWNER_ID == 0)) { i_Params_Get_Coach_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_By_Where.START_ROW == null) { i_Params_Get_Coach_By_Where.START_ROW = 0; }
if ((i_Params_Get_Coach_By_Where.END_ROW == null) || (i_Params_Get_Coach_By_Where.END_ROW == 0)) { i_Params_Get_Coach_By_Where.END_ROW = 1000000; }
List<DALC.Coach> oList_DBEntries = _AppContext.Get_Coach_By_Where_Adv(i_Params_Get_Coach_By_Where.FIRSTNAME,i_Params_Get_Coach_By_Where.LASTNAME,i_Params_Get_Coach_By_Where.EMAIL,i_Params_Get_Coach_By_Where.MOBILE,i_Params_Get_Coach_By_Where.GEO_LOCATION,i_Params_Get_Coach_By_Where.OWNER_ID,i_Params_Get_Coach_By_Where.START_ROW,i_Params_Get_Coach_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach = new Coach();
oTools.CopyPropValues(oDBEntry, oCoach);
oCoach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oCoach.My_User);
oList.Add(oCoach);
}
}
i_Params_Get_Coach_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_By_Where_Adv");}
return oList;
}
public List<Player> Get_Player_By_Criteria_Adv(Params_Get_Player_By_Criteria i_Params_Get_Player_By_Criteria)
{
List<Player> oList = new List<Player>();
long? tmp_TOTAL_COUNT = 0;
Player oPlayer = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Player_By_Criteria.OWNER_ID == null) || (i_Params_Get_Player_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Player_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_By_Criteria.START_ROW == null) { i_Params_Get_Player_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Player_By_Criteria.END_ROW == null) || (i_Params_Get_Player_By_Criteria.END_ROW == 0)) { i_Params_Get_Player_By_Criteria.END_ROW = 1000000; }
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_Criteria_Adv(i_Params_Get_Player_By_Criteria.FIRSTNAME,i_Params_Get_Player_By_Criteria.LASTNAME,i_Params_Get_Player_By_Criteria.EMAIL,i_Params_Get_Player_By_Criteria.MOBILE,i_Params_Get_Player_By_Criteria.GEO_LOCATION,i_Params_Get_Player_By_Criteria.OWNER_ID,i_Params_Get_Player_By_Criteria.START_ROW,i_Params_Get_Player_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oPlayer.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oPlayer.My_User);
oList.Add(oPlayer);
}
}
i_Params_Get_Player_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_Criteria_Adv");}
return oList;
}
public List<Player> Get_Player_By_Where_Adv(Params_Get_Player_By_Where i_Params_Get_Player_By_Where)
{
List<Player> oList = new List<Player>();
long? tmp_TOTAL_COUNT = 0;
Player oPlayer = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Player_By_Where.OWNER_ID == null) || (i_Params_Get_Player_By_Where.OWNER_ID == 0)) { i_Params_Get_Player_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_By_Where.START_ROW == null) { i_Params_Get_Player_By_Where.START_ROW = 0; }
if ((i_Params_Get_Player_By_Where.END_ROW == null) || (i_Params_Get_Player_By_Where.END_ROW == 0)) { i_Params_Get_Player_By_Where.END_ROW = 1000000; }
List<DALC.Player> oList_DBEntries = _AppContext.Get_Player_By_Where_Adv(i_Params_Get_Player_By_Where.FIRSTNAME,i_Params_Get_Player_By_Where.LASTNAME,i_Params_Get_Player_By_Where.EMAIL,i_Params_Get_Player_By_Where.MOBILE,i_Params_Get_Player_By_Where.GEO_LOCATION,i_Params_Get_Player_By_Where.OWNER_ID,i_Params_Get_Player_By_Where.START_ROW,i_Params_Get_Player_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer = new Player();
oTools.CopyPropValues(oDBEntry, oPlayer);
oPlayer.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oPlayer.My_User);
oList.Add(oPlayer);
}
}
i_Params_Get_Player_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_By_Where_Adv");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_InList_Adv(Params_Get_Coach_leaderboards_By_Criteria_InList i_Params_Get_Coach_leaderboards_By_Criteria_InList)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Coach_leaderboards_By_Criteria_InList_SP oParams_Get_Coach_leaderboards_By_Criteria_InList_SP = new Params_Get_Coach_leaderboards_By_Criteria_InList_SP();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID;
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Coach_leaderboards_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.START_ROW = i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW;
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.END_ROW = i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW;
oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_leaderboards_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Criteria_InList(i_Params_Get_Coach_leaderboards_By_Criteria_InList.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Coach_leaderboards_By_Criteria_InList.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Criteria_InList.START_ROW,i_Params_Get_Coach_leaderboards_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Coach_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_leaderboards_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Criteria_InList_Adv");}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_InList_Adv(Params_Get_Coach_leaderboards_By_Where_InList i_Params_Get_Coach_leaderboards_By_Where_InList)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Coach_leaderboards_By_Where_InList_SP oParams_Get_Coach_leaderboards_By_Where_InList_SP = new Params_Get_Coach_leaderboards_By_Where_InList_SP();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_leaderboards_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW == null) { i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW == null) || (i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW == 0)) { i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Coach_leaderboards_By_Where_InList_SP.OWNER_ID = i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID;
oParams_Get_Coach_leaderboards_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Coach_leaderboards_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_leaderboards_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST);
oParams_Get_Coach_leaderboards_By_Where_InList_SP.START_ROW = i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW;
oParams_Get_Coach_leaderboards_By_Where_InList_SP.END_ROW = i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW;
oParams_Get_Coach_leaderboards_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_leaderboards_By_Where_InList.TOTAL_COUNT;
List<DALC.Coach_leaderboards> oList_DBEntries = _AppContext.Get_Coach_leaderboards_By_Where_InList(i_Params_Get_Coach_leaderboards_By_Where_InList.DESCRIPTION,i_Params_Get_Coach_leaderboards_By_Where_InList.COACH_ID_LIST,i_Params_Get_Coach_leaderboards_By_Where_InList.OWNER_ID,i_Params_Get_Coach_leaderboards_By_Where_InList.START_ROW,i_Params_Get_Coach_leaderboards_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_leaderboards = new Coach_leaderboards();
oTools.CopyPropValues(oDBEntry, oCoach_leaderboards);
oCoach_leaderboards.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_leaderboards.My_Coach);
oList.Add(oCoach_leaderboards);
}
}
i_Params_Get_Coach_leaderboards_By_Where_InList.TOTAL_COUNT = oParams_Get_Coach_leaderboards_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_leaderboards_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_leaderboards_By_Where_InList_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_InList_Adv(Params_Get_Player_leaderboards_By_Criteria_InList i_Params_Get_Player_leaderboards_By_Criteria_InList)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Player_leaderboards_By_Criteria_InList_SP oParams_Get_Player_leaderboards_By_Criteria_InList_SP = new Params_Get_Player_leaderboards_By_Criteria_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID;
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Player_leaderboards_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST);
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.START_ROW = i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW;
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.END_ROW = i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW;
oParams_Get_Player_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Player_leaderboards_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Criteria_InList(i_Params_Get_Player_leaderboards_By_Criteria_InList.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Player_leaderboards_By_Criteria_InList.OWNER_ID,i_Params_Get_Player_leaderboards_By_Criteria_InList.START_ROW,i_Params_Get_Player_leaderboards_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Player_leaderboards_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Player_leaderboards_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Criteria_InList_Adv");}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where_InList_Adv(Params_Get_Player_leaderboards_By_Where_InList i_Params_Get_Player_leaderboards_By_Where_InList)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Player_leaderboards_By_Where_InList_SP oParams_Get_Player_leaderboards_By_Where_InList_SP = new Params_Get_Player_leaderboards_By_Where_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Player_leaderboards_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW == null) { i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW == null) || (i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW == 0)) { i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Player_leaderboards_By_Where_InList_SP.OWNER_ID = i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID;
oParams_Get_Player_leaderboards_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Player_leaderboards_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Player_leaderboards_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST);
oParams_Get_Player_leaderboards_By_Where_InList_SP.START_ROW = i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW;
oParams_Get_Player_leaderboards_By_Where_InList_SP.END_ROW = i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW;
oParams_Get_Player_leaderboards_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Player_leaderboards_By_Where_InList.TOTAL_COUNT;
List<DALC.Player_leaderboards> oList_DBEntries = _AppContext.Get_Player_leaderboards_By_Where_InList(i_Params_Get_Player_leaderboards_By_Where_InList.DESCRIPTION,i_Params_Get_Player_leaderboards_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Player_leaderboards_By_Where_InList.OWNER_ID,i_Params_Get_Player_leaderboards_By_Where_InList.START_ROW,i_Params_Get_Player_leaderboards_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayer_leaderboards = new Player_leaderboards();
oTools.CopyPropValues(oDBEntry, oPlayer_leaderboards);
oPlayer_leaderboards.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayer_leaderboards.My_Player);
oList.Add(oPlayer_leaderboards);
}
}
i_Params_Get_Player_leaderboards_By_Where_InList.TOTAL_COUNT = oParams_Get_Player_leaderboards_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Player_leaderboards_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Player_leaderboards_By_Where_InList_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria_InList_Adv(Params_Get_Playersport_By_Criteria_InList i_Params_Get_Playersport_By_Criteria_InList)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Playersport_By_Criteria_InList_SP oParams_Get_Playersport_By_Criteria_InList_SP = new Params_Get_Playersport_By_Criteria_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Criteria_InList.START_ROW == null) { i_Params_Get_Playersport_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Playersport_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Playersport_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Playersport_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID;
oParams_Get_Playersport_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Playersport_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST);
oParams_Get_Playersport_By_Criteria_InList_SP.START_ROW = i_Params_Get_Playersport_By_Criteria_InList.START_ROW;
oParams_Get_Playersport_By_Criteria_InList_SP.END_ROW = i_Params_Get_Playersport_By_Criteria_InList.END_ROW;
oParams_Get_Playersport_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Playersport_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Criteria_InList(i_Params_Get_Playersport_By_Criteria_InList.DESCRIPTION,i_Params_Get_Playersport_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Playersport_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Playersport_By_Criteria_InList.OWNER_ID,i_Params_Get_Playersport_By_Criteria_InList.START_ROW,i_Params_Get_Playersport_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Playersport_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Playersport_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Criteria_InList_Adv");}
return oList;
}
public List<Playersport> Get_Playersport_By_Where_InList_Adv(Params_Get_Playersport_By_Where_InList i_Params_Get_Playersport_By_Where_InList)
{
List<Playersport> oList = new List<Playersport>();
Playersport oPlayersport = new Playersport();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Playersport_By_Where_InList_SP oParams_Get_Playersport_By_Where_InList_SP = new Params_Get_Playersport_By_Where_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Playersport_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Playersport_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Playersport_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Playersport_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Playersport_By_Where_InList.START_ROW == null) { i_Params_Get_Playersport_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Playersport_By_Where_InList.END_ROW == null) || (i_Params_Get_Playersport_By_Where_InList.END_ROW == 0)) { i_Params_Get_Playersport_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Playersport_By_Where_InList_SP.OWNER_ID = i_Params_Get_Playersport_By_Where_InList.OWNER_ID;
oParams_Get_Playersport_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Playersport_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Playersport_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST);
oParams_Get_Playersport_By_Where_InList_SP.START_ROW = i_Params_Get_Playersport_By_Where_InList.START_ROW;
oParams_Get_Playersport_By_Where_InList_SP.END_ROW = i_Params_Get_Playersport_By_Where_InList.END_ROW;
oParams_Get_Playersport_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Playersport_By_Where_InList.TOTAL_COUNT;
List<DALC.Playersport> oList_DBEntries = _AppContext.Get_Playersport_By_Where_InList(i_Params_Get_Playersport_By_Where_InList.DESCRIPTION,i_Params_Get_Playersport_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Playersport_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Playersport_By_Where_InList.OWNER_ID,i_Params_Get_Playersport_By_Where_InList.START_ROW,i_Params_Get_Playersport_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oPlayersport = new Playersport();
oTools.CopyPropValues(oDBEntry, oPlayersport);
oPlayersport.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oPlayersport.My_Player);
oPlayersport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oPlayersport.My_Sport);
oList.Add(oPlayersport);
}
}
i_Params_Get_Playersport_By_Where_InList.TOTAL_COUNT = oParams_Get_Playersport_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Playersport_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Playersport_By_Where_InList_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria_InList_Adv(Params_Get_Coachsport_By_Criteria_InList i_Params_Get_Coachsport_By_Criteria_InList)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Coachsport_By_Criteria_InList_SP oParams_Get_Coachsport_By_Criteria_InList_SP = new Params_Get_Coachsport_By_Criteria_InList_SP();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Criteria_InList.START_ROW == null) { i_Params_Get_Coachsport_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Coachsport_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Coachsport_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Coachsport_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID;
oParams_Get_Coachsport_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Coachsport_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST);
if ( i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Coachsport_By_Criteria_InList_SP.START_ROW = i_Params_Get_Coachsport_By_Criteria_InList.START_ROW;
oParams_Get_Coachsport_By_Criteria_InList_SP.END_ROW = i_Params_Get_Coachsport_By_Criteria_InList.END_ROW;
oParams_Get_Coachsport_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Coachsport_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Criteria_InList(i_Params_Get_Coachsport_By_Criteria_InList.DESCRIPTION,i_Params_Get_Coachsport_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Coachsport_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Coachsport_By_Criteria_InList.OWNER_ID,i_Params_Get_Coachsport_By_Criteria_InList.START_ROW,i_Params_Get_Coachsport_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Coachsport_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Coachsport_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Criteria_InList_Adv");}
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where_InList_Adv(Params_Get_Coachsport_By_Where_InList i_Params_Get_Coachsport_By_Where_InList)
{
List<Coachsport> oList = new List<Coachsport>();
Coachsport oCoachsport = new Coachsport();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Coachsport_By_Where_InList_SP oParams_Get_Coachsport_By_Where_InList_SP = new Params_Get_Coachsport_By_Where_InList_SP();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coachsport_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Coachsport_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Coachsport_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Coachsport_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coachsport_By_Where_InList.START_ROW == null) { i_Params_Get_Coachsport_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Coachsport_By_Where_InList.END_ROW == null) || (i_Params_Get_Coachsport_By_Where_InList.END_ROW == 0)) { i_Params_Get_Coachsport_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Coachsport_By_Where_InList_SP.OWNER_ID = i_Params_Get_Coachsport_By_Where_InList.OWNER_ID;
oParams_Get_Coachsport_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Coachsport_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST);
if ( i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coachsport_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST);
oParams_Get_Coachsport_By_Where_InList_SP.START_ROW = i_Params_Get_Coachsport_By_Where_InList.START_ROW;
oParams_Get_Coachsport_By_Where_InList_SP.END_ROW = i_Params_Get_Coachsport_By_Where_InList.END_ROW;
oParams_Get_Coachsport_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Coachsport_By_Where_InList.TOTAL_COUNT;
List<DALC.Coachsport> oList_DBEntries = _AppContext.Get_Coachsport_By_Where_InList(i_Params_Get_Coachsport_By_Where_InList.DESCRIPTION,i_Params_Get_Coachsport_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Coachsport_By_Where_InList.COACH_ID_LIST,i_Params_Get_Coachsport_By_Where_InList.OWNER_ID,i_Params_Get_Coachsport_By_Where_InList.START_ROW,i_Params_Get_Coachsport_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoachsport = new Coachsport();
oTools.CopyPropValues(oDBEntry, oCoachsport);
oCoachsport.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oCoachsport.My_Sport);
oCoachsport.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoachsport.My_Coach);
oList.Add(oCoachsport);
}
}
i_Params_Get_Coachsport_By_Where_InList.TOTAL_COUNT = oParams_Get_Coachsport_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Coachsport_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coachsport_By_Where_InList_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_InList_Adv(Params_Get_Coach_evaluation_By_Criteria_InList i_Params_Get_Coach_evaluation_By_Criteria_InList)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Coach_evaluation_By_Criteria_InList_SP oParams_Get_Coach_evaluation_By_Criteria_InList_SP = new Params_Get_Coach_evaluation_By_Criteria_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID;
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Coach_evaluation_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.START_ROW = i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW;
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.END_ROW = i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW;
oParams_Get_Coach_evaluation_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_evaluation_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Criteria_InList(i_Params_Get_Coach_evaluation_By_Criteria_InList.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Coach_evaluation_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Coach_evaluation_By_Criteria_InList.OWNER_ID,i_Params_Get_Coach_evaluation_By_Criteria_InList.START_ROW,i_Params_Get_Coach_evaluation_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Coach_evaluation_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_evaluation_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Criteria_InList_Adv");}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where_InList_Adv(Params_Get_Coach_evaluation_By_Where_InList i_Params_Get_Coach_evaluation_By_Where_InList)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Coach_evaluation_By_Where_InList_SP oParams_Get_Coach_evaluation_By_Where_InList_SP = new Params_Get_Coach_evaluation_By_Where_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Coach_evaluation_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW == null) { i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW == null) || (i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW == 0)) { i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Coach_evaluation_By_Where_InList_SP.OWNER_ID = i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID;
oParams_Get_Coach_evaluation_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Coach_evaluation_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Coach_evaluation_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST);
oParams_Get_Coach_evaluation_By_Where_InList_SP.START_ROW = i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW;
oParams_Get_Coach_evaluation_By_Where_InList_SP.END_ROW = i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW;
oParams_Get_Coach_evaluation_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Coach_evaluation_By_Where_InList.TOTAL_COUNT;
List<DALC.Coach_evaluation> oList_DBEntries = _AppContext.Get_Coach_evaluation_By_Where_InList(i_Params_Get_Coach_evaluation_By_Where_InList.DESCRIPTION,i_Params_Get_Coach_evaluation_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Coach_evaluation_By_Where_InList.COACH_ID_LIST,i_Params_Get_Coach_evaluation_By_Where_InList.OWNER_ID,i_Params_Get_Coach_evaluation_By_Where_InList.START_ROW,i_Params_Get_Coach_evaluation_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCoach_evaluation = new Coach_evaluation();
oTools.CopyPropValues(oDBEntry, oCoach_evaluation);
oCoach_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oCoach_evaluation.My_Player);
oCoach_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oCoach_evaluation.My_Coach);
oList.Add(oCoach_evaluation);
}
}
i_Params_Get_Coach_evaluation_By_Where_InList.TOTAL_COUNT = oParams_Get_Coach_evaluation_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Coach_evaluation_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Coach_evaluation_By_Where_InList_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria_InList_Adv(Params_Get_Session_evaluation_By_Criteria_InList i_Params_Get_Session_evaluation_By_Criteria_InList)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Session_evaluation_By_Criteria_InList_SP oParams_Get_Session_evaluation_By_Criteria_InList_SP = new Params_Get_Session_evaluation_By_Criteria_InList_SP();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW == null) { i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Session_evaluation_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID;
oParams_Get_Session_evaluation_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Session_evaluation_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST);
oParams_Get_Session_evaluation_By_Criteria_InList_SP.START_ROW = i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW;
oParams_Get_Session_evaluation_By_Criteria_InList_SP.END_ROW = i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW;
oParams_Get_Session_evaluation_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Session_evaluation_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Criteria_InList(i_Params_Get_Session_evaluation_By_Criteria_InList.DESCRIPTION,i_Params_Get_Session_evaluation_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Session_evaluation_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Session_evaluation_By_Criteria_InList.OWNER_ID,i_Params_Get_Session_evaluation_By_Criteria_InList.START_ROW,i_Params_Get_Session_evaluation_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Session_evaluation_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Session_evaluation_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Criteria_InList_Adv");}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where_InList_Adv(Params_Get_Session_evaluation_By_Where_InList i_Params_Get_Session_evaluation_By_Where_InList)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
Session_evaluation oSession_evaluation = new Session_evaluation();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Session_evaluation_By_Where_InList_SP oParams_Get_Session_evaluation_By_Where_InList_SP = new Params_Get_Session_evaluation_By_Where_InList_SP();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Session_evaluation_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Session_evaluation_By_Where_InList.START_ROW == null) { i_Params_Get_Session_evaluation_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Session_evaluation_By_Where_InList.END_ROW == null) || (i_Params_Get_Session_evaluation_By_Where_InList.END_ROW == 0)) { i_Params_Get_Session_evaluation_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Session_evaluation_By_Where_InList_SP.OWNER_ID = i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID;
oParams_Get_Session_evaluation_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Session_evaluation_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Session_evaluation_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST);
oParams_Get_Session_evaluation_By_Where_InList_SP.START_ROW = i_Params_Get_Session_evaluation_By_Where_InList.START_ROW;
oParams_Get_Session_evaluation_By_Where_InList_SP.END_ROW = i_Params_Get_Session_evaluation_By_Where_InList.END_ROW;
oParams_Get_Session_evaluation_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Session_evaluation_By_Where_InList.TOTAL_COUNT;
List<DALC.Session_evaluation> oList_DBEntries = _AppContext.Get_Session_evaluation_By_Where_InList(i_Params_Get_Session_evaluation_By_Where_InList.DESCRIPTION,i_Params_Get_Session_evaluation_By_Where_InList.COACH_ID_LIST,i_Params_Get_Session_evaluation_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Session_evaluation_By_Where_InList.OWNER_ID,i_Params_Get_Session_evaluation_By_Where_InList.START_ROW,i_Params_Get_Session_evaluation_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oSession_evaluation = new Session_evaluation();
oTools.CopyPropValues(oDBEntry, oSession_evaluation);
oSession_evaluation.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oSession_evaluation.My_Coach);
oSession_evaluation.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oSession_evaluation.My_Player);
oList.Add(oSession_evaluation);
}
}
i_Params_Get_Session_evaluation_By_Where_InList.TOTAL_COUNT = oParams_Get_Session_evaluation_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Session_evaluation_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Session_evaluation_By_Where_InList_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria_InList_Adv(Params_Get_Taken_session_By_Criteria_InList i_Params_Get_Taken_session_By_Criteria_InList)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Taken_session_By_Criteria_InList_SP oParams_Get_Taken_session_By_Criteria_InList_SP = new Params_Get_Taken_session_By_Criteria_InList_SP();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Criteria_InList.START_ROW == null) { i_Params_Get_Taken_session_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Taken_session_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Taken_session_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Taken_session_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID;
oParams_Get_Taken_session_By_Criteria_InList_SP.DATETIME = i_Params_Get_Taken_session_By_Criteria_InList.DATETIME;
if ( i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST);
oParams_Get_Taken_session_By_Criteria_InList_SP.START_ROW = i_Params_Get_Taken_session_By_Criteria_InList.START_ROW;
oParams_Get_Taken_session_By_Criteria_InList_SP.END_ROW = i_Params_Get_Taken_session_By_Criteria_InList.END_ROW;
oParams_Get_Taken_session_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Taken_session_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Criteria_InList(i_Params_Get_Taken_session_By_Criteria_InList.DATETIME,i_Params_Get_Taken_session_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Taken_session_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Taken_session_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Taken_session_By_Criteria_InList.OWNER_ID,i_Params_Get_Taken_session_By_Criteria_InList.START_ROW,i_Params_Get_Taken_session_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Taken_session_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Taken_session_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Criteria_InList_Adv");}
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where_InList_Adv(Params_Get_Taken_session_By_Where_InList i_Params_Get_Taken_session_By_Where_InList)
{
List<Taken_session> oList = new List<Taken_session>();
Taken_session oTaken_session = new Taken_session();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Taken_session_By_Where_InList_SP oParams_Get_Taken_session_By_Where_InList_SP = new Params_Get_Taken_session_By_Where_InList_SP();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Taken_session_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Taken_session_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Taken_session_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Taken_session_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Taken_session_By_Where_InList.START_ROW == null) { i_Params_Get_Taken_session_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Taken_session_By_Where_InList.END_ROW == null) || (i_Params_Get_Taken_session_By_Where_InList.END_ROW == 0)) { i_Params_Get_Taken_session_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Taken_session_By_Where_InList_SP.OWNER_ID = i_Params_Get_Taken_session_By_Where_InList.OWNER_ID;
oParams_Get_Taken_session_By_Where_InList_SP.DATETIME = i_Params_Get_Taken_session_By_Where_InList.DATETIME;
if ( i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Taken_session_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST);
oParams_Get_Taken_session_By_Where_InList_SP.START_ROW = i_Params_Get_Taken_session_By_Where_InList.START_ROW;
oParams_Get_Taken_session_By_Where_InList_SP.END_ROW = i_Params_Get_Taken_session_By_Where_InList.END_ROW;
oParams_Get_Taken_session_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Taken_session_By_Where_InList.TOTAL_COUNT;
List<DALC.Taken_session> oList_DBEntries = _AppContext.Get_Taken_session_By_Where_InList(i_Params_Get_Taken_session_By_Where_InList.DATETIME,i_Params_Get_Taken_session_By_Where_InList.COACH_ID_LIST,i_Params_Get_Taken_session_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Taken_session_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Taken_session_By_Where_InList.OWNER_ID,i_Params_Get_Taken_session_By_Where_InList.START_ROW,i_Params_Get_Taken_session_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTaken_session = new Taken_session();
oTools.CopyPropValues(oDBEntry, oTaken_session);
oTaken_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oTaken_session.My_Coach);
oTaken_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oTaken_session.My_Player);
oTaken_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oTaken_session.My_Sport);
oList.Add(oTaken_session);
}
}
i_Params_Get_Taken_session_By_Where_InList.TOTAL_COUNT = oParams_Get_Taken_session_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Taken_session_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Taken_session_By_Where_InList_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria_InList_Adv(Params_Get_Scheduled_session_By_Criteria_InList i_Params_Get_Scheduled_session_By_Criteria_InList)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Scheduled_session_By_Criteria_InList_SP oParams_Get_Scheduled_session_By_Criteria_InList_SP = new Params_Get_Scheduled_session_By_Criteria_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW == null) { i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Scheduled_session_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.DATE_TIME = i_Params_Get_Scheduled_session_By_Criteria_InList.DATE_TIME;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Scheduled_session_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Criteria_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST);
oParams_Get_Scheduled_session_By_Criteria_InList_SP.START_ROW = i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.END_ROW = i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW;
oParams_Get_Scheduled_session_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Scheduled_session_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Criteria_InList(i_Params_Get_Scheduled_session_By_Criteria_InList.DATE_TIME,i_Params_Get_Scheduled_session_By_Criteria_InList.DESCRIPTION,i_Params_Get_Scheduled_session_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Scheduled_session_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Scheduled_session_By_Criteria_InList.SPORT_ID_LIST,i_Params_Get_Scheduled_session_By_Criteria_InList.OWNER_ID,i_Params_Get_Scheduled_session_By_Criteria_InList.START_ROW,i_Params_Get_Scheduled_session_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Scheduled_session_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Scheduled_session_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Criteria_InList_Adv");}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where_InList_Adv(Params_Get_Scheduled_session_By_Where_InList i_Params_Get_Scheduled_session_By_Where_InList)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
Scheduled_session oScheduled_session = new Scheduled_session();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Scheduled_session_By_Where_InList_SP oParams_Get_Scheduled_session_By_Where_InList_SP = new Params_Get_Scheduled_session_By_Where_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Sport_By_SPORT_ID oParams_Get_Sport_By_SPORT_ID = new Params_Get_Sport_By_SPORT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Scheduled_session_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Scheduled_session_By_Where_InList.START_ROW == null) { i_Params_Get_Scheduled_session_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Scheduled_session_By_Where_InList.END_ROW == null) || (i_Params_Get_Scheduled_session_By_Where_InList.END_ROW == 0)) { i_Params_Get_Scheduled_session_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Scheduled_session_By_Where_InList_SP.OWNER_ID = i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID;
oParams_Get_Scheduled_session_By_Where_InList_SP.DATE_TIME = i_Params_Get_Scheduled_session_By_Where_InList.DATE_TIME;
oParams_Get_Scheduled_session_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Scheduled_session_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST == null)
{
i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST = new List<Int32?>();
}
oParams_Get_Scheduled_session_By_Where_InList_SP.SPORT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST);
oParams_Get_Scheduled_session_By_Where_InList_SP.START_ROW = i_Params_Get_Scheduled_session_By_Where_InList.START_ROW;
oParams_Get_Scheduled_session_By_Where_InList_SP.END_ROW = i_Params_Get_Scheduled_session_By_Where_InList.END_ROW;
oParams_Get_Scheduled_session_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Scheduled_session_By_Where_InList.TOTAL_COUNT;
List<DALC.Scheduled_session> oList_DBEntries = _AppContext.Get_Scheduled_session_By_Where_InList(i_Params_Get_Scheduled_session_By_Where_InList.DATE_TIME,i_Params_Get_Scheduled_session_By_Where_InList.DESCRIPTION,i_Params_Get_Scheduled_session_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Scheduled_session_By_Where_InList.COACH_ID_LIST,i_Params_Get_Scheduled_session_By_Where_InList.SPORT_ID_LIST,i_Params_Get_Scheduled_session_By_Where_InList.OWNER_ID,i_Params_Get_Scheduled_session_By_Where_InList.START_ROW,i_Params_Get_Scheduled_session_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oScheduled_session = new Scheduled_session();
oTools.CopyPropValues(oDBEntry, oScheduled_session);
oScheduled_session.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oScheduled_session.My_Player);
oScheduled_session.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oScheduled_session.My_Coach);
oScheduled_session.My_Sport = new Sport();
oTools.CopyPropValues(oDBEntry.My_Sport, oScheduled_session.My_Sport);
oList.Add(oScheduled_session);
}
}
i_Params_Get_Scheduled_session_By_Where_InList.TOTAL_COUNT = oParams_Get_Scheduled_session_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Scheduled_session_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Scheduled_session_By_Where_InList_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_Criteria_InList_Adv(Params_Get_Comment_By_Criteria_InList i_Params_Get_Comment_By_Criteria_InList)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Comment_By_Criteria_InList_SP oParams_Get_Comment_By_Criteria_InList_SP = new Params_Get_Comment_By_Criteria_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Comment_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Comment_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Criteria_InList.START_ROW == null) { i_Params_Get_Comment_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Comment_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Comment_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Comment_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Comment_By_Criteria_InList.OWNER_ID;
oParams_Get_Comment_By_Criteria_InList_SP.TITLE = i_Params_Get_Comment_By_Criteria_InList.TITLE;
oParams_Get_Comment_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Comment_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Comment_By_Criteria_InList_SP.START_ROW = i_Params_Get_Comment_By_Criteria_InList.START_ROW;
oParams_Get_Comment_By_Criteria_InList_SP.END_ROW = i_Params_Get_Comment_By_Criteria_InList.END_ROW;
oParams_Get_Comment_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Criteria_InList(i_Params_Get_Comment_By_Criteria_InList.TITLE,i_Params_Get_Comment_By_Criteria_InList.DESCRIPTION,i_Params_Get_Comment_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Comment_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Comment_By_Criteria_InList.OWNER_ID,i_Params_Get_Comment_By_Criteria_InList.START_ROW,i_Params_Get_Comment_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Comment_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Criteria_InList_Adv");}
return oList;
}
public List<Comment> Get_Comment_By_Where_InList_Adv(Params_Get_Comment_By_Where_InList i_Params_Get_Comment_By_Where_InList)
{
List<Comment> oList = new List<Comment>();
Comment oComment = new Comment();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Comment_By_Where_InList_SP oParams_Get_Comment_By_Where_InList_SP = new Params_Get_Comment_By_Where_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Comment_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Comment_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_By_Where_InList.START_ROW == null) { i_Params_Get_Comment_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_By_Where_InList.END_ROW == null) || (i_Params_Get_Comment_By_Where_InList.END_ROW == 0)) { i_Params_Get_Comment_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Comment_By_Where_InList_SP.OWNER_ID = i_Params_Get_Comment_By_Where_InList.OWNER_ID;
oParams_Get_Comment_By_Where_InList_SP.TITLE = i_Params_Get_Comment_By_Where_InList.TITLE;
oParams_Get_Comment_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Comment_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST);
oParams_Get_Comment_By_Where_InList_SP.START_ROW = i_Params_Get_Comment_By_Where_InList.START_ROW;
oParams_Get_Comment_By_Where_InList_SP.END_ROW = i_Params_Get_Comment_By_Where_InList.END_ROW;
oParams_Get_Comment_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_By_Where_InList.TOTAL_COUNT;
List<DALC.Comment> oList_DBEntries = _AppContext.Get_Comment_By_Where_InList(i_Params_Get_Comment_By_Where_InList.TITLE,i_Params_Get_Comment_By_Where_InList.DESCRIPTION,i_Params_Get_Comment_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Comment_By_Where_InList.COACH_ID_LIST,i_Params_Get_Comment_By_Where_InList.OWNER_ID,i_Params_Get_Comment_By_Where_InList.START_ROW,i_Params_Get_Comment_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment = new Comment();
oTools.CopyPropValues(oDBEntry, oComment);
oComment.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment.My_Player);
oComment.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment.My_Coach);
oList.Add(oComment);
}
}
i_Params_Get_Comment_By_Where_InList.TOTAL_COUNT = oParams_Get_Comment_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_By_Where_InList_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria_InList_Adv(Params_Get_Report_coach_By_Criteria_InList i_Params_Get_Report_coach_By_Criteria_InList)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Report_coach_By_Criteria_InList_SP oParams_Get_Report_coach_By_Criteria_InList_SP = new Params_Get_Report_coach_By_Criteria_InList_SP();
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Criteria_InList.START_ROW == null) { i_Params_Get_Report_coach_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Report_coach_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Report_coach_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Report_coach_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID;
oParams_Get_Report_coach_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Report_coach_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_coach_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST);
oParams_Get_Report_coach_By_Criteria_InList_SP.START_ROW = i_Params_Get_Report_coach_By_Criteria_InList.START_ROW;
oParams_Get_Report_coach_By_Criteria_InList_SP.END_ROW = i_Params_Get_Report_coach_By_Criteria_InList.END_ROW;
oParams_Get_Report_coach_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Report_coach_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Criteria_InList(i_Params_Get_Report_coach_By_Criteria_InList.DESCRIPTION,i_Params_Get_Report_coach_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Report_coach_By_Criteria_InList.OWNER_ID,i_Params_Get_Report_coach_By_Criteria_InList.START_ROW,i_Params_Get_Report_coach_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Report_coach_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_coach_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Criteria_InList_Adv");}
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where_InList_Adv(Params_Get_Report_coach_By_Where_InList i_Params_Get_Report_coach_By_Where_InList)
{
List<Report_coach> oList = new List<Report_coach>();
Report_coach oReport_coach = new Report_coach();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Report_coach_By_Where_InList_SP oParams_Get_Report_coach_By_Where_InList_SP = new Params_Get_Report_coach_By_Where_InList_SP();
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_coach_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Report_coach_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Report_coach_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Report_coach_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_coach_By_Where_InList.START_ROW == null) { i_Params_Get_Report_coach_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Report_coach_By_Where_InList.END_ROW == null) || (i_Params_Get_Report_coach_By_Where_InList.END_ROW == 0)) { i_Params_Get_Report_coach_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Report_coach_By_Where_InList_SP.OWNER_ID = i_Params_Get_Report_coach_By_Where_InList.OWNER_ID;
oParams_Get_Report_coach_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Report_coach_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_coach_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST);
oParams_Get_Report_coach_By_Where_InList_SP.START_ROW = i_Params_Get_Report_coach_By_Where_InList.START_ROW;
oParams_Get_Report_coach_By_Where_InList_SP.END_ROW = i_Params_Get_Report_coach_By_Where_InList.END_ROW;
oParams_Get_Report_coach_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Report_coach_By_Where_InList.TOTAL_COUNT;
List<DALC.Report_coach> oList_DBEntries = _AppContext.Get_Report_coach_By_Where_InList(i_Params_Get_Report_coach_By_Where_InList.DESCRIPTION,i_Params_Get_Report_coach_By_Where_InList.COACH_ID_LIST,i_Params_Get_Report_coach_By_Where_InList.OWNER_ID,i_Params_Get_Report_coach_By_Where_InList.START_ROW,i_Params_Get_Report_coach_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_coach = new Report_coach();
oTools.CopyPropValues(oDBEntry, oReport_coach);
oReport_coach.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_coach.My_User);
oReport_coach.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oReport_coach.My_Coach);
oList.Add(oReport_coach);
}
}
i_Params_Get_Report_coach_By_Where_InList.TOTAL_COUNT = oParams_Get_Report_coach_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_coach_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_coach_By_Where_InList_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria_InList_Adv(Params_Get_Comment_report_By_Criteria_InList i_Params_Get_Comment_report_By_Criteria_InList)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Comment_report_By_Criteria_InList_SP oParams_Get_Comment_report_By_Criteria_InList_SP = new Params_Get_Comment_report_By_Criteria_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Comment_By_COMMENT_ID oParams_Get_Comment_By_COMMENT_ID = new Params_Get_Comment_By_COMMENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Comment_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Comment_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Comment_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Comment_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Comment_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Comment_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Criteria_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST);
if ( i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Criteria_InList_SP.COMMENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST);
oParams_Get_Comment_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Comment_report_By_Criteria_InList.START_ROW;
oParams_Get_Comment_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Comment_report_By_Criteria_InList.END_ROW;
oParams_Get_Comment_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Criteria_InList(i_Params_Get_Comment_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Comment_report_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Comment_report_By_Criteria_InList.COACH_ID_LIST,i_Params_Get_Comment_report_By_Criteria_InList.COMMENT_ID_LIST,i_Params_Get_Comment_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Comment_report_By_Criteria_InList.START_ROW,i_Params_Get_Comment_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Comment_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Criteria_InList_Adv");}
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where_InList_Adv(Params_Get_Comment_report_By_Where_InList i_Params_Get_Comment_report_By_Where_InList)
{
List<Comment_report> oList = new List<Comment_report>();
Comment_report oComment_report = new Comment_report();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Comment_report_By_Where_InList_SP oParams_Get_Comment_report_By_Where_InList_SP = new Params_Get_Comment_report_By_Where_InList_SP();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
Params_Get_Coach_By_COACH_ID oParams_Get_Coach_By_COACH_ID = new Params_Get_Coach_By_COACH_ID();
Params_Get_Comment_By_COMMENT_ID oParams_Get_Comment_By_COMMENT_ID = new Params_Get_Comment_By_COMMENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Comment_report_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Comment_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Comment_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Comment_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Comment_report_By_Where_InList.START_ROW == null) { i_Params_Get_Comment_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Comment_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Comment_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Comment_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Comment_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Comment_report_By_Where_InList.OWNER_ID;
oParams_Get_Comment_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Comment_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST);
if ( i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Where_InList_SP.COACH_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST);
if ( i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST == null)
{
i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Comment_report_By_Where_InList_SP.COMMENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST);
oParams_Get_Comment_report_By_Where_InList_SP.START_ROW = i_Params_Get_Comment_report_By_Where_InList.START_ROW;
oParams_Get_Comment_report_By_Where_InList_SP.END_ROW = i_Params_Get_Comment_report_By_Where_InList.END_ROW;
oParams_Get_Comment_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Comment_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Comment_report> oList_DBEntries = _AppContext.Get_Comment_report_By_Where_InList(i_Params_Get_Comment_report_By_Where_InList.DESCRIPTION,i_Params_Get_Comment_report_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Comment_report_By_Where_InList.COACH_ID_LIST,i_Params_Get_Comment_report_By_Where_InList.COMMENT_ID_LIST,i_Params_Get_Comment_report_By_Where_InList.OWNER_ID,i_Params_Get_Comment_report_By_Where_InList.START_ROW,i_Params_Get_Comment_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oComment_report = new Comment_report();
oTools.CopyPropValues(oDBEntry, oComment_report);
oComment_report.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oComment_report.My_Player);
oComment_report.My_Coach = new Coach();
oTools.CopyPropValues(oDBEntry.My_Coach, oComment_report.My_Coach);
oComment_report.My_Comment = new Comment();
oTools.CopyPropValues(oDBEntry.My_Comment, oComment_report.My_Comment);
oList.Add(oComment_report);
}
}
i_Params_Get_Comment_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Comment_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Comment_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Comment_report_By_Where_InList_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria_InList_Adv(Params_Get_Report_player_By_Criteria_InList i_Params_Get_Report_player_By_Criteria_InList)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Report_player_By_Criteria_InList_SP oParams_Get_Report_player_By_Criteria_InList_SP = new Params_Get_Report_player_By_Criteria_InList_SP();
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Criteria_InList.START_ROW == null) { i_Params_Get_Report_player_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Report_player_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Report_player_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Report_player_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID;
oParams_Get_Report_player_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Report_player_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_player_By_Criteria_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST);
oParams_Get_Report_player_By_Criteria_InList_SP.START_ROW = i_Params_Get_Report_player_By_Criteria_InList.START_ROW;
oParams_Get_Report_player_By_Criteria_InList_SP.END_ROW = i_Params_Get_Report_player_By_Criteria_InList.END_ROW;
oParams_Get_Report_player_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Report_player_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Criteria_InList(i_Params_Get_Report_player_By_Criteria_InList.DESCRIPTION,i_Params_Get_Report_player_By_Criteria_InList.PLAYER_ID_LIST,i_Params_Get_Report_player_By_Criteria_InList.OWNER_ID,i_Params_Get_Report_player_By_Criteria_InList.START_ROW,i_Params_Get_Report_player_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Report_player_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_player_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Criteria_InList_Adv");}
return oList;
}
public List<Report_player> Get_Report_player_By_Where_InList_Adv(Params_Get_Report_player_By_Where_InList i_Params_Get_Report_player_By_Where_InList)
{
List<Report_player> oList = new List<Report_player>();
Report_player oReport_player = new Report_player();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Report_player_By_Where_InList_SP oParams_Get_Report_player_By_Where_InList_SP = new Params_Get_Report_player_By_Where_InList_SP();
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
Params_Get_Player_By_PLAYER_ID oParams_Get_Player_By_PLAYER_ID = new Params_Get_Player_By_PLAYER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_player_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Report_player_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Report_player_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Report_player_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_player_By_Where_InList.START_ROW == null) { i_Params_Get_Report_player_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Report_player_By_Where_InList.END_ROW == null) || (i_Params_Get_Report_player_By_Where_InList.END_ROW == 0)) { i_Params_Get_Report_player_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Report_player_By_Where_InList_SP.OWNER_ID = i_Params_Get_Report_player_By_Where_InList.OWNER_ID;
oParams_Get_Report_player_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Report_player_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST == null)
{
i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_player_By_Where_InList_SP.PLAYER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST);
oParams_Get_Report_player_By_Where_InList_SP.START_ROW = i_Params_Get_Report_player_By_Where_InList.START_ROW;
oParams_Get_Report_player_By_Where_InList_SP.END_ROW = i_Params_Get_Report_player_By_Where_InList.END_ROW;
oParams_Get_Report_player_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Report_player_By_Where_InList.TOTAL_COUNT;
List<DALC.Report_player> oList_DBEntries = _AppContext.Get_Report_player_By_Where_InList(i_Params_Get_Report_player_By_Where_InList.DESCRIPTION,i_Params_Get_Report_player_By_Where_InList.PLAYER_ID_LIST,i_Params_Get_Report_player_By_Where_InList.OWNER_ID,i_Params_Get_Report_player_By_Where_InList.START_ROW,i_Params_Get_Report_player_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_player = new Report_player();
oTools.CopyPropValues(oDBEntry, oReport_player);
oReport_player.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oReport_player.My_User);
oReport_player.My_Player = new Player();
oTools.CopyPropValues(oDBEntry.My_Player, oReport_player.My_Player);
oList.Add(oReport_player);
}
}
i_Params_Get_Report_player_By_Where_InList.TOTAL_COUNT = oParams_Get_Report_player_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_player_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_player_By_Where_InList_Adv");}
return oList;
}
}
}
