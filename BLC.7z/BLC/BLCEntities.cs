using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
#region Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID
public partial class Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID
{
#region Properties
public Int32? COACH_LEADERBOARDS_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID
public partial class Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID
{
#region Properties
public Int32? PLAYER_LEADERBOARDS_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Playersport_By_PLAYERSPORT_ID
public partial class Params_Get_Playersport_By_PLAYERSPORT_ID
{
#region Properties
public Int32? PLAYERSPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Sport_By_SPORT_ID
public partial class Params_Get_Sport_By_SPORT_ID
{
#region Properties
public Int32? SPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Coachsport_By_COACHSPORT_ID
public partial class Params_Get_Coachsport_By_COACHSPORT_ID
{
#region Properties
public Int32? COACHSPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID
public partial class Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID
{
#region Properties
public Int32? COACH_EVALUATION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Currency_By_CURRENCY_ID
public partial class Params_Get_Currency_By_CURRENCY_ID
{
#region Properties
public Int32? CURRENCY_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID
public partial class Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID
{
#region Properties
public Int32? SESSION_EVALUATION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Taken_session_By_TAKEN_SESSION_ID
public partial class Params_Get_Taken_session_By_TAKEN_SESSION_ID
{
#region Properties
public Int32? TAKEN_SESSION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID
public partial class Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID
{
#region Properties
public Int32? SCHEDULED_SESSION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Notification_By_NOTIFICATION_ID
public partial class Params_Get_Notification_By_NOTIFICATION_ID
{
#region Properties
public Int32? NOTIFICATION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Owner_By_OWNER_ID
public partial class Params_Get_Owner_By_OWNER_ID
{
#region Properties
public Int32? OWNER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Comment_By_COMMENT_ID
public partial class Params_Get_Comment_By_COMMENT_ID
{
#region Properties
public Int32? COMMENT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Report_coach_By_REPORT_COACH_ID
public partial class Params_Get_Report_coach_By_REPORT_COACH_ID
{
#region Properties
public Int32? REPORT_COACH_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Comment_report_By_COMMENT_REPORT_ID
public partial class Params_Get_Comment_report_By_COMMENT_REPORT_ID
{
#region Properties
public Int32? COMMENT_REPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_User_By_USER_ID
public partial class Params_Get_User_By_USER_ID
{
#region Properties
public long? USER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Direct_message_By_DIRECT_MESSAGE_ID
public partial class Params_Get_Direct_message_By_DIRECT_MESSAGE_ID
{
#region Properties
public long? DIRECT_MESSAGE_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Report_player_By_REPORT_PLAYER_ID
public partial class Params_Get_Report_player_By_REPORT_PLAYER_ID
{
#region Properties
public Int32? REPORT_PLAYER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Coach_By_COACH_ID
public partial class Params_Get_Coach_By_COACH_ID
{
#region Properties
public Int32? COACH_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Player_By_PLAYER_ID
public partial class Params_Get_Player_By_PLAYER_ID
{
#region Properties
public Int32? PLAYER_ID {get;set;}

#endregion
}
#endregion
public partial class Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List
{
public List<Int32?> COACH_LEADERBOARDS_ID_LIST {get;set;}
}
public partial class Params_Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_SP
{
public string COACH_LEADERBOARDS_ID_LIST {get;set;}

}
public partial class Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List
{
public List<Int32?> PLAYER_LEADERBOARDS_ID_LIST {get;set;}
}
public partial class Params_Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_SP
{
public string PLAYER_LEADERBOARDS_ID_LIST {get;set;}

}
public partial class Params_Get_Playersport_By_PLAYERSPORT_ID_List
{
public List<Int32?> PLAYERSPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Playersport_By_PLAYERSPORT_ID_List_SP
{
public string PLAYERSPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Sport_By_SPORT_ID_List
{
public List<Int32?> SPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Sport_By_SPORT_ID_List_SP
{
public string SPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Coachsport_By_COACHSPORT_ID_List
{
public List<Int32?> COACHSPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Coachsport_By_COACHSPORT_ID_List_SP
{
public string COACHSPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List
{
public List<Int32?> COACH_EVALUATION_ID_LIST {get;set;}
}
public partial class Params_Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_SP
{
public string COACH_EVALUATION_ID_LIST {get;set;}

}
public partial class Params_Get_Currency_By_CURRENCY_ID_List
{
public List<Int32?> CURRENCY_ID_LIST {get;set;}
}
public partial class Params_Get_Currency_By_CURRENCY_ID_List_SP
{
public string CURRENCY_ID_LIST {get;set;}

}
public partial class Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List
{
public List<Int32?> SESSION_EVALUATION_ID_LIST {get;set;}
}
public partial class Params_Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_SP
{
public string SESSION_EVALUATION_ID_LIST {get;set;}

}
public partial class Params_Get_Taken_session_By_TAKEN_SESSION_ID_List
{
public List<Int32?> TAKEN_SESSION_ID_LIST {get;set;}
}
public partial class Params_Get_Taken_session_By_TAKEN_SESSION_ID_List_SP
{
public string TAKEN_SESSION_ID_LIST {get;set;}

}
public partial class Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List
{
public List<Int32?> SCHEDULED_SESSION_ID_LIST {get;set;}
}
public partial class Params_Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_SP
{
public string SCHEDULED_SESSION_ID_LIST {get;set;}

}
public partial class Params_Get_Notification_By_NOTIFICATION_ID_List
{
public List<Int32?> NOTIFICATION_ID_LIST {get;set;}
}
public partial class Params_Get_Notification_By_NOTIFICATION_ID_List_SP
{
public string NOTIFICATION_ID_LIST {get;set;}

}
public partial class Params_Get_Owner_By_OWNER_ID_List
{
public List<Int32?> OWNER_ID_LIST {get;set;}
}
public partial class Params_Get_Owner_By_OWNER_ID_List_SP
{
public string OWNER_ID_LIST {get;set;}

}
public partial class Params_Get_Comment_By_COMMENT_ID_List
{
public List<Int32?> COMMENT_ID_LIST {get;set;}
}
public partial class Params_Get_Comment_By_COMMENT_ID_List_SP
{
public string COMMENT_ID_LIST {get;set;}

}
public partial class Params_Get_Report_coach_By_REPORT_COACH_ID_List
{
public List<Int32?> REPORT_COACH_ID_LIST {get;set;}
}
public partial class Params_Get_Report_coach_By_REPORT_COACH_ID_List_SP
{
public string REPORT_COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Comment_report_By_COMMENT_REPORT_ID_List
{
public List<Int32?> COMMENT_REPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Comment_report_By_COMMENT_REPORT_ID_List_SP
{
public string COMMENT_REPORT_ID_LIST {get;set;}

}
public partial class Params_Get_User_By_USER_ID_List
{
public List<long?> USER_ID_LIST {get;set;}
}
public partial class Params_Get_User_By_USER_ID_List_SP
{
public string USER_ID_LIST {get;set;}

}
public partial class Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List
{
public List<long?> DIRECT_MESSAGE_ID_LIST {get;set;}
}
public partial class Params_Get_Direct_message_By_DIRECT_MESSAGE_ID_List_SP
{
public string DIRECT_MESSAGE_ID_LIST {get;set;}

}
public partial class Params_Get_Report_player_By_REPORT_PLAYER_ID_List
{
public List<Int32?> REPORT_PLAYER_ID_LIST {get;set;}
}
public partial class Params_Get_Report_player_By_REPORT_PLAYER_ID_List_SP
{
public string REPORT_PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Coach_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}
}
public partial class Params_Get_Coach_By_COACH_ID_List_SP
{
public string COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Player_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}
}
public partial class Params_Get_Player_By_PLAYER_ID_List_SP
{
public string PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Coach_leaderboards_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Coach_leaderboards_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Player_leaderboards_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Player_leaderboards_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Playersport_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Playersport_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Playersport_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}

}
public partial class Params_Get_Sport_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Coachsport_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Coachsport_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}

}
public partial class Params_Get_Coachsport_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Coach_evaluation_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Coach_evaluation_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Coach_evaluation_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Currency_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Session_evaluation_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Session_evaluation_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Session_evaluation_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Taken_session_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Taken_session_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Taken_session_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Taken_session_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}

}
public partial class Params_Get_Scheduled_session_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Scheduled_session_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Scheduled_session_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Scheduled_session_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}

}
public partial class Params_Get_Notification_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Notification_By_USER_ID
{
public Int32? USER_ID {get;set;}

}
public partial class Params_Get_Comment_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Comment_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Comment_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Report_coach_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Report_coach_By_USER_ID
{
public Int32? USER_ID {get;set;}

}
public partial class Params_Get_Report_coach_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Comment_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Comment_report_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Comment_report_By_COACH_ID
{
public Int32? COACH_ID {get;set;}

}
public partial class Params_Get_Comment_report_By_COMMENT_ID
{
public Int32? COMMENT_ID {get;set;}

}
public partial class Params_Get_User_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_User_By_USERNAME
{
public string USERNAME {get;set;}

}
public partial class Params_Get_Direct_message_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Direct_message_By_AUTHOR_ID
{
public Int32? AUTHOR_ID {get;set;}

}
public partial class Params_Get_Direct_message_By_RECIPIENT_ID
{
public Int32? RECIPIENT_ID {get;set;}

}
public partial class Params_Get_Report_player_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Report_player_By_USER_ID
{
public long? USER_ID {get;set;}

}
public partial class Params_Get_Report_player_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}

}
public partial class Params_Get_Coach_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Coach_By_USER_ID
{
public long? USER_ID {get;set;}

}
public partial class Params_Get_Player_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Player_By_USER_ID
{
public long? USER_ID {get;set;}

}
public partial class Params_Get_Coach_leaderboards_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Player_leaderboards_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Playersport_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Playersport_By_SPORT_ID_List
{
public List<Int32?> SPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Coachsport_By_SPORT_ID_List
{
public List<Int32?> SPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Coachsport_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Coach_evaluation_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Coach_evaluation_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Session_evaluation_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Session_evaluation_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Taken_session_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Taken_session_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Taken_session_By_SPORT_ID_List
{
public List<Int32?> SPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Scheduled_session_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Scheduled_session_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Scheduled_session_By_SPORT_ID_List
{
public List<Int32?> SPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Notification_By_USER_ID_List
{
public List<Int32?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Comment_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Comment_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Report_coach_By_USER_ID_List
{
public List<Int32?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Report_coach_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Comment_report_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Comment_report_By_COACH_ID_List
{
public List<Int32?> COACH_ID_LIST {get;set;}

}
public partial class Params_Get_Comment_report_By_COMMENT_ID_List
{
public List<Int32?> COMMENT_ID_LIST {get;set;}

}
public partial class Params_Get_Direct_message_By_AUTHOR_ID_List
{
public List<Int32?> AUTHOR_ID_LIST {get;set;}

}
public partial class Params_Get_Direct_message_By_RECIPIENT_ID_List
{
public List<Int32?> RECIPIENT_ID_LIST {get;set;}

}
public partial class Params_Get_Report_player_By_USER_ID_List
{
public List<long?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Report_player_By_PLAYER_ID_List
{
public List<Int32?> PLAYER_ID_LIST {get;set;}

}
public partial class Params_Get_Coach_By_USER_ID_List
{
public List<long?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Player_By_USER_ID_List
{
public List<long?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Coach_leaderboards_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_leaderboards_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_leaderboards_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_leaderboards_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Playersport_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Playersport_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Sport_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string SPORT_NAME {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Sport_By_Where
{

public Int32? OWNER_ID {get;set;}
public string SPORT_NAME {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coachsport_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coachsport_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_evaluation_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_evaluation_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Currency_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string CURRENCY_NAME {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Currency_By_Where
{

public Int32? OWNER_ID {get;set;}
public string CURRENCY_NAME {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Session_evaluation_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Session_evaluation_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Taken_session_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DATETIME {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Taken_session_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DATETIME {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Scheduled_session_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Scheduled_session_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Where
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Where
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Criteria_V2
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Where_V2
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_By_Where
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_coach_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_coach_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_report_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_report_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_User_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_User_By_Where
{

public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Direct_message_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string DATETIME {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Direct_message_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string DATETIME {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_player_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_player_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public string GEO_LOCATION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_By_Where
{

public Int32? OWNER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public string GEO_LOCATION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public string GEO_LOCATION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_By_Where
{

public Int32? OWNER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public string GEO_LOCATION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_leaderboards_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_leaderboards_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_leaderboards_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_leaderboards_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_leaderboards_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_leaderboards_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_leaderboards_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Player_leaderboards_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Playersport_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Playersport_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Playersport_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Playersport_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coachsport_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coachsport_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string SPORT_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coachsport_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coachsport_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string SPORT_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_evaluation_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_evaluation_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_evaluation_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Coach_evaluation_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Session_evaluation_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Session_evaluation_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string COACH_ID_LIST {get;set;}
public string PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Session_evaluation_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Session_evaluation_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string COACH_ID_LIST {get;set;}
public string PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Taken_session_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DATETIME {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Taken_session_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DATETIME {get;set;}
public string COACH_ID_LIST {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Taken_session_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DATETIME {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Taken_session_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DATETIME {get;set;}
public string COACH_ID_LIST {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Scheduled_session_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Scheduled_session_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public string SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Scheduled_session_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Scheduled_session_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public string SPORT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_coach_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_coach_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_coach_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_coach_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string COACH_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_report_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> COMMENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_report_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public string COMMENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_report_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public List<Int32?> COACH_ID_LIST {get;set;}
public List<Int32?> COMMENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Comment_report_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public string COACH_ID_LIST {get;set;}
public string COMMENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_player_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_player_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_player_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_player_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string PLAYER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
#region Params_Delete_Coach_leaderboards
public partial class Params_Delete_Coach_leaderboards
{
#region Properties
public Int32? COACH_LEADERBOARDS_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Player_leaderboards
public partial class Params_Delete_Player_leaderboards
{
#region Properties
public Int32? PLAYER_LEADERBOARDS_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Playersport
public partial class Params_Delete_Playersport
{
#region Properties
public Int32? PLAYERSPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Sport
public partial class Params_Delete_Sport
{
#region Properties
public Int32? SPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Coachsport
public partial class Params_Delete_Coachsport
{
#region Properties
public Int32? COACHSPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Coach_evaluation
public partial class Params_Delete_Coach_evaluation
{
#region Properties
public Int32? COACH_EVALUATION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Currency
public partial class Params_Delete_Currency
{
#region Properties
public Int32? CURRENCY_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Session_evaluation
public partial class Params_Delete_Session_evaluation
{
#region Properties
public Int32? SESSION_EVALUATION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Taken_session
public partial class Params_Delete_Taken_session
{
#region Properties
public Int32? TAKEN_SESSION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Scheduled_session
public partial class Params_Delete_Scheduled_session
{
#region Properties
public Int32? SCHEDULED_SESSION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Notification
public partial class Params_Delete_Notification
{
#region Properties
public Int32? NOTIFICATION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Owner
public partial class Params_Delete_Owner
{
#region Properties
public Int32? OWNER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Comment
public partial class Params_Delete_Comment
{
#region Properties
public Int32? COMMENT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Report_coach
public partial class Params_Delete_Report_coach
{
#region Properties
public Int32? REPORT_COACH_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Comment_report
public partial class Params_Delete_Comment_report
{
#region Properties
public Int32? COMMENT_REPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_User
public partial class Params_Delete_User
{
#region Properties
public long? USER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Direct_message
public partial class Params_Delete_Direct_message
{
#region Properties
public long? DIRECT_MESSAGE_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Report_player
public partial class Params_Delete_Report_player
{
#region Properties
public Int32? REPORT_PLAYER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Coach
public partial class Params_Delete_Coach
{
#region Properties
public Int32? COACH_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Player
public partial class Params_Delete_Player
{
#region Properties
public Int32? PLAYER_ID {get;set;}
#endregion
}
#endregion
public partial class Params_Delete_Coach_leaderboards_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Coach_leaderboards_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Player_leaderboards_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Player_leaderboards_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Playersport_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Playersport_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Playersport_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}
}
public partial class Params_Delete_Sport_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Coachsport_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Coachsport_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}
}
public partial class Params_Delete_Coachsport_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Coach_evaluation_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Coach_evaluation_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Coach_evaluation_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Currency_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Session_evaluation_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Session_evaluation_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Session_evaluation_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Taken_session_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Taken_session_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Taken_session_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Taken_session_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}
}
public partial class Params_Delete_Scheduled_session_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Scheduled_session_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Scheduled_session_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Scheduled_session_By_SPORT_ID
{
public Int32? SPORT_ID {get;set;}
}
public partial class Params_Delete_Notification_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Notification_By_USER_ID
{
public Int32? USER_ID {get;set;}
}
public partial class Params_Delete_Comment_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Comment_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Comment_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Report_coach_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Report_coach_By_USER_ID
{
public Int32? USER_ID {get;set;}
}
public partial class Params_Delete_Report_coach_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Comment_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Comment_report_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Comment_report_By_COACH_ID
{
public Int32? COACH_ID {get;set;}
}
public partial class Params_Delete_Comment_report_By_COMMENT_ID
{
public Int32? COMMENT_ID {get;set;}
}
public partial class Params_Delete_User_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_User_By_USERNAME
{
public string USERNAME {get;set;}
}
public partial class Params_Delete_Direct_message_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Direct_message_By_AUTHOR_ID
{
public Int32? AUTHOR_ID {get;set;}
}
public partial class Params_Delete_Direct_message_By_RECIPIENT_ID
{
public Int32? RECIPIENT_ID {get;set;}
}
public partial class Params_Delete_Report_player_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Report_player_By_USER_ID
{
public long? USER_ID {get;set;}
}
public partial class Params_Delete_Report_player_By_PLAYER_ID
{
public Int32? PLAYER_ID {get;set;}
}
public partial class Params_Delete_Coach_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Coach_By_USER_ID
{
public long? USER_ID {get;set;}
}
public partial class Params_Delete_Player_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Player_By_USER_ID
{
public long? USER_ID {get;set;}
}
public partial class Coach_leaderboards
{
public Int32? COACH_LEADERBOARDS_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? POINTS {get;set;}
public Int32? STANDING {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
}
public partial class Player_leaderboards
{
public Int32? PLAYER_LEADERBOARDS_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? POINTS {get;set;}
public Int32? STANDING {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
}
public partial class Playersport
{
public Int32? PLAYERSPORT_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Sport
{
public Int32? SPORT_ID {get;set;}
public string SPORT_NAME {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Coachsport
{
public Int32? COACHSPORT_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public Int32? COACH_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Coach_evaluation
{
public Int32? COACH_EVALUATION_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public decimal RATING {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Currency
{
public Int32? CURRENCY_ID {get;set;}
public string CURRENCY_NAME {get;set;}
public decimal TO_USD {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Session_evaluation
{
public Int32? SESSION_EVALUATION_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public decimal SESSION_RATING {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Taken_session
{
public Int32? TAKEN_SESSION_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public string DATETIME {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Scheduled_session
{
public Int32? SCHEDULED_SESSION_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Notification
{
public Int32? NOTIFICATION_ID {get;set;}
public Int32? USER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Owner
{
public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Comment
{
public Int32? COMMENT_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public bool? IS_BLOCKED {get;set;}
public Int32? REPORTS {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Report_coach
{
public Int32? REPORT_COACH_ID {get;set;}
public Int32? USER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Comment_report
{
public Int32? COMMENT_REPORT_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? COMMENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class User
{
public long? USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public bool? IS_LOGGED_IN {get;set;}
public bool? IS_ACTIVE {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Direct_message
{
public long? DIRECT_MESSAGE_ID {get;set;}
public Int32? AUTHOR_ID {get;set;}
public Int32? RECIPIENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public bool? IS_DELETED_BY_RECIPIENT {get;set;}
public string DATETIME {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Report_player
{
public Int32? REPORT_PLAYER_ID {get;set;}
public long? USER_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Coach
{
public Int32? COACH_ID {get;set;}
public long? USER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public Int32? PRICE_PER_SESSION {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public Int32? AGE {get;set;}
public string GEO_LOCATION {get;set;}
public Int32? SCORE {get;set;}
public Int32? SESSIONS_COMPLETED {get;set;}
public Int32? REPORT {get;set;}
public bool? IS_BLOCKED {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Player
{
public Int32? PLAYER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public long? USER_ID {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public Int32? AGE {get;set;}
public string GEO_LOCATION {get;set;}
public Int32? SESSIONS_COMPLETED {get;set;}
public bool? IS_BLOCKED {get;set;}
public Int32? REPORTS {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
#region Params_Edit_Coach_leaderboards_List
public partial class Params_Edit_Coach_leaderboards_List
{
#region Properties
public List<Coach_leaderboards> My_List_To_Edit { get; set; }
public List<Coach_leaderboards> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Player_leaderboards_List
public partial class Params_Edit_Player_leaderboards_List
{
#region Properties
public List<Player_leaderboards> My_List_To_Edit { get; set; }
public List<Player_leaderboards> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Playersport_List
public partial class Params_Edit_Playersport_List
{
#region Properties
public List<Playersport> My_List_To_Edit { get; set; }
public List<Playersport> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Sport_List
public partial class Params_Edit_Sport_List
{
#region Properties
public List<Sport> My_List_To_Edit { get; set; }
public List<Sport> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Coachsport_List
public partial class Params_Edit_Coachsport_List
{
#region Properties
public List<Coachsport> My_List_To_Edit { get; set; }
public List<Coachsport> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Coach_evaluation_List
public partial class Params_Edit_Coach_evaluation_List
{
#region Properties
public List<Coach_evaluation> My_List_To_Edit { get; set; }
public List<Coach_evaluation> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Currency_List
public partial class Params_Edit_Currency_List
{
#region Properties
public List<Currency> My_List_To_Edit { get; set; }
public List<Currency> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Session_evaluation_List
public partial class Params_Edit_Session_evaluation_List
{
#region Properties
public List<Session_evaluation> My_List_To_Edit { get; set; }
public List<Session_evaluation> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Taken_session_List
public partial class Params_Edit_Taken_session_List
{
#region Properties
public List<Taken_session> My_List_To_Edit { get; set; }
public List<Taken_session> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Scheduled_session_List
public partial class Params_Edit_Scheduled_session_List
{
#region Properties
public List<Scheduled_session> My_List_To_Edit { get; set; }
public List<Scheduled_session> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Notification_List
public partial class Params_Edit_Notification_List
{
#region Properties
public List<Notification> My_List_To_Edit { get; set; }
public List<Notification> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Owner_List
public partial class Params_Edit_Owner_List
{
#region Properties
public List<Owner> My_List_To_Edit { get; set; }
public List<Owner> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Comment_List
public partial class Params_Edit_Comment_List
{
#region Properties
public List<Comment> My_List_To_Edit { get; set; }
public List<Comment> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Report_coach_List
public partial class Params_Edit_Report_coach_List
{
#region Properties
public List<Report_coach> My_List_To_Edit { get; set; }
public List<Report_coach> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Comment_report_List
public partial class Params_Edit_Comment_report_List
{
#region Properties
public List<Comment_report> My_List_To_Edit { get; set; }
public List<Comment_report> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_User_List
public partial class Params_Edit_User_List
{
#region Properties
public List<User> My_List_To_Edit { get; set; }
public List<User> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Direct_message_List
public partial class Params_Edit_Direct_message_List
{
#region Properties
public List<Direct_message> My_List_To_Edit { get; set; }
public List<Direct_message> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Report_player_List
public partial class Params_Edit_Report_player_List
{
#region Properties
public List<Report_player> My_List_To_Edit { get; set; }
public List<Report_player> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Coach_List
public partial class Params_Edit_Coach_List
{
#region Properties
public List<Coach> My_List_To_Edit { get; set; }
public List<Coach> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Player_List
public partial class Params_Edit_Player_List
{
#region Properties
public List<Player> My_List_To_Edit { get; set; }
public List<Player> My_List_To_Delete { get; set; }
#endregion
}
#endregion
}
