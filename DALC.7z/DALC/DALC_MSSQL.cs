using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Dynamic;
namespace DALC
{
public partial class MSSQL_DALC : IDALC
{
public Coach_leaderboards Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID ( Int32? COACH_LEADERBOARDS_ID)
{
Coach_leaderboards o = new Coach_leaderboards();
dynamic p = new ExpandoObject();
p.COACH_LEADERBOARDS_ID = COACH_LEADERBOARDS_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_LEADERBOARDS_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Player_leaderboards Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID ( Int32? PLAYER_LEADERBOARDS_ID)
{
Player_leaderboards o = new Player_leaderboards();
dynamic p = new ExpandoObject();
p.PLAYER_LEADERBOARDS_ID = PLAYER_LEADERBOARDS_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_LEADERBOARDS_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Playersport Get_Playersport_By_PLAYERSPORT_ID ( Int32? PLAYERSPORT_ID)
{
Playersport o = new Playersport();
dynamic p = new ExpandoObject();
p.PLAYERSPORT_ID = PLAYERSPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYERSPORT_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Sport Get_Sport_By_SPORT_ID ( Int32? SPORT_ID)
{
Sport o = new Sport();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_SPORT_BY_SPORT_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Coachsport Get_Coachsport_By_COACHSPORT_ID ( Int32? COACHSPORT_ID)
{
Coachsport o = new Coachsport();
dynamic p = new ExpandoObject();
p.COACHSPORT_ID = COACHSPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACHSPORT_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Coach_evaluation Get_Coach_evaluation_By_COACH_EVALUATION_ID ( Int32? COACH_EVALUATION_ID)
{
Coach_evaluation o = new Coach_evaluation();
dynamic p = new ExpandoObject();
p.COACH_EVALUATION_ID = COACH_EVALUATION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_EVALUATION_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Currency Get_Currency_By_CURRENCY_ID ( Int32? CURRENCY_ID)
{
Currency o = new Currency();
dynamic p = new ExpandoObject();
p.CURRENCY_ID = CURRENCY_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_CURRENCY_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Session_evaluation Get_Session_evaluation_By_SESSION_EVALUATION_ID ( Int32? SESSION_EVALUATION_ID)
{
Session_evaluation o = new Session_evaluation();
dynamic p = new ExpandoObject();
p.SESSION_EVALUATION_ID = SESSION_EVALUATION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_SESSION_EVALUATION_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Taken_session Get_Taken_session_By_TAKEN_SESSION_ID ( Int32? TAKEN_SESSION_ID)
{
Taken_session o = new Taken_session();
dynamic p = new ExpandoObject();
p.TAKEN_SESSION_ID = TAKEN_SESSION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_TAKEN_SESSION_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Scheduled_session Get_Scheduled_session_By_SCHEDULED_SESSION_ID ( Int32? SCHEDULED_SESSION_ID)
{
Scheduled_session o = new Scheduled_session();
dynamic p = new ExpandoObject();
p.SCHEDULED_SESSION_ID = SCHEDULED_SESSION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SCHEDULED_SESSION_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Notification Get_Notification_By_NOTIFICATION_ID ( Int32? NOTIFICATION_ID)
{
Notification o = new Notification();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID = NOTIFICATION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Owner Get_Owner_By_OWNER_ID ( Int32? OWNER_ID)
{
Owner o = new Owner();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_OWNER_BY_OWNER_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Comment Get_Comment_By_COMMENT_ID ( Int32? COMMENT_ID)
{
Comment o = new Comment();
dynamic p = new ExpandoObject();
p.COMMENT_ID = COMMENT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COMMENT_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Report_coach Get_Report_coach_By_REPORT_COACH_ID ( Int32? REPORT_COACH_ID)
{
Report_coach o = new Report_coach();
dynamic p = new ExpandoObject();
p.REPORT_COACH_ID = REPORT_COACH_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_REPORT_COACH_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Comment_report Get_Comment_report_By_COMMENT_REPORT_ID ( Int32? COMMENT_REPORT_ID)
{
Comment_report o = new Comment_report();
dynamic p = new ExpandoObject();
p.COMMENT_REPORT_ID = COMMENT_REPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_REPORT_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public User Get_User_By_USER_ID ( long? USER_ID)
{
User o = new User();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Direct_message Get_Direct_message_By_DIRECT_MESSAGE_ID ( long? DIRECT_MESSAGE_ID)
{
Direct_message o = new Direct_message();
dynamic p = new ExpandoObject();
p.DIRECT_MESSAGE_ID = DIRECT_MESSAGE_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_DIRECT_MESSAGE_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Report_player Get_Report_player_By_REPORT_PLAYER_ID ( Int32? REPORT_PLAYER_ID)
{
Report_player o = new Report_player();
dynamic p = new ExpandoObject();
p.REPORT_PLAYER_ID = REPORT_PLAYER_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_REPORT_PLAYER_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Coach Get_Coach_By_COACH_ID ( Int32? COACH_ID)
{
Coach o = new Coach();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACH_BY_COACH_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Player Get_Player_By_PLAYER_ID ( Int32? PLAYER_ID)
{
Player o = new Player();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_PLAYER_BY_PLAYER_ID", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Coach_leaderboards Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_Adv ( Int32? COACH_LEADERBOARDS_ID)
{
Coach_leaderboards o = new Coach_leaderboards();
dynamic p = new ExpandoObject();
p.COACH_LEADERBOARDS_ID = COACH_LEADERBOARDS_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_LEADERBOARDS_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
}
return o;
}
public Player_leaderboards Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_Adv ( Int32? PLAYER_LEADERBOARDS_ID)
{
Player_leaderboards o = new Player_leaderboards();
dynamic p = new ExpandoObject();
p.PLAYER_LEADERBOARDS_ID = PLAYER_LEADERBOARDS_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_LEADERBOARDS_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
}
return o;
}
public Playersport Get_Playersport_By_PLAYERSPORT_ID_Adv ( Int32? PLAYERSPORT_ID)
{
Playersport o = new Playersport();
dynamic p = new ExpandoObject();
p.PLAYERSPORT_ID = PLAYERSPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYERSPORT_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(R["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(R["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(R["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(R["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(R["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(R["T_SPORT_OWNER_ID"]);
}
return o;
}
public Sport Get_Sport_By_SPORT_ID_Adv ( Int32? SPORT_ID)
{
Sport o = new Sport();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_SPORT_BY_SPORT_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Coachsport Get_Coachsport_By_COACHSPORT_ID_Adv ( Int32? COACHSPORT_ID)
{
Coachsport o = new Coachsport();
dynamic p = new ExpandoObject();
p.COACHSPORT_ID = COACHSPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACHSPORT_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(R["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(R["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(R["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(R["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(R["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(R["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
}
return o;
}
public Coach_evaluation Get_Coach_evaluation_By_COACH_EVALUATION_ID_Adv ( Int32? COACH_EVALUATION_ID)
{
Coach_evaluation o = new Coach_evaluation();
dynamic p = new ExpandoObject();
p.COACH_EVALUATION_ID = COACH_EVALUATION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_EVALUATION_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
}
return o;
}
public Currency Get_Currency_By_CURRENCY_ID_Adv ( Int32? CURRENCY_ID)
{
Currency o = new Currency();
dynamic p = new ExpandoObject();
p.CURRENCY_ID = CURRENCY_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_CURRENCY_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Session_evaluation Get_Session_evaluation_By_SESSION_EVALUATION_ID_Adv ( Int32? SESSION_EVALUATION_ID)
{
Session_evaluation o = new Session_evaluation();
dynamic p = new ExpandoObject();
p.SESSION_EVALUATION_ID = SESSION_EVALUATION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_SESSION_EVALUATION_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
}
return o;
}
public Taken_session Get_Taken_session_By_TAKEN_SESSION_ID_Adv ( Int32? TAKEN_SESSION_ID)
{
Taken_session o = new Taken_session();
dynamic p = new ExpandoObject();
p.TAKEN_SESSION_ID = TAKEN_SESSION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_TAKEN_SESSION_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(R["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(R["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(R["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(R["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(R["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(R["T_SPORT_OWNER_ID"]);
}
return o;
}
public Scheduled_session Get_Scheduled_session_By_SCHEDULED_SESSION_ID_Adv ( Int32? SCHEDULED_SESSION_ID)
{
Scheduled_session o = new Scheduled_session();
dynamic p = new ExpandoObject();
p.SCHEDULED_SESSION_ID = SCHEDULED_SESSION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SCHEDULED_SESSION_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(R["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(R["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(R["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(R["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(R["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(R["T_SPORT_OWNER_ID"]);
}
return o;
}
public Notification Get_Notification_By_NOTIFICATION_ID_Adv ( Int32? NOTIFICATION_ID)
{
Notification o = new Notification();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID = NOTIFICATION_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(R["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(R["T_USER_ENTRY_DATE"]);
}
return o;
}
public Comment Get_Comment_By_COMMENT_ID_Adv ( Int32? COMMENT_ID)
{
Comment o = new Comment();
dynamic p = new ExpandoObject();
p.COMMENT_ID = COMMENT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COMMENT_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
}
return o;
}
public Report_coach Get_Report_coach_By_REPORT_COACH_ID_Adv ( Int32? REPORT_COACH_ID)
{
Report_coach o = new Report_coach();
dynamic p = new ExpandoObject();
p.REPORT_COACH_ID = REPORT_COACH_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_REPORT_COACH_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(R["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(R["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
}
return o;
}
public Comment_report Get_Comment_report_By_COMMENT_REPORT_ID_Adv ( Int32? COMMENT_REPORT_ID)
{
Comment_report o = new Comment_report();
dynamic p = new ExpandoObject();
p.COMMENT_REPORT_ID = COMMENT_REPORT_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_REPORT_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(R["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(R["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(R["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(R["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(R["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(R["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(R["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(R["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(R["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(R["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(R["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(R["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(R["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(R["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(R["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(R["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(R["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(R["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(R["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(R["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(R["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(R["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(R["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(R["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(R["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(R["T_COMMENT_OWNER_ID"]);
}
return o;
}
public User Get_User_By_USER_ID_Adv ( long? USER_ID)
{
User o = new User();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Direct_message Get_Direct_message_By_DIRECT_MESSAGE_ID_Adv ( long? DIRECT_MESSAGE_ID)
{
Direct_message o = new Direct_message();
dynamic p = new ExpandoObject();
p.DIRECT_MESSAGE_ID = DIRECT_MESSAGE_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_DIRECT_MESSAGE_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(R["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(R["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(R["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(R["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(R["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(R["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(R["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(R["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(R["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(R["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(R["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(R["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(R["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(R["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(R["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(R["T_RECIPIENT_ENTRY_DATE"]);
}
return o;
}
public Report_player Get_Report_player_By_REPORT_PLAYER_ID_Adv ( Int32? REPORT_PLAYER_ID)
{
Report_player o = new Report_player();
dynamic p = new ExpandoObject();
p.REPORT_PLAYER_ID = REPORT_PLAYER_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_REPORT_PLAYER_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(R["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(R["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(R["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(R["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(R["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(R["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(R["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(R["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(R["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(R["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(R["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(R["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(R["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(R["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(R["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(R["T_PLAYER_OWNER_ID"]);
}
return o;
}
public Coach Get_Coach_By_COACH_ID_Adv ( Int32? COACH_ID)
{
Coach o = new Coach();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_COACH_BY_COACH_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(R["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(R["T_USER_ENTRY_DATE"]);
}
return o;
}
public Player Get_Player_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
Player o = new Player();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> Q = ExecuteSelectQuery("UPG_GET_PLAYER_BY_PLAYER_ID_ADV", p);
var R = Q.FirstOrDefault();
if (R != null){
oTools.CopyPropValues_FromDataRecord(R, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(R["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(R["T_USER_ENTRY_DATE"]);
}
return o;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List ( List<Int32?> COACH_LEADERBOARDS_ID_LIST)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.COACH_LEADERBOARDS_ID_LIST = string.Join(",", COACH_LEADERBOARDS_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_LEADERBOARDS_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List ( List<Int32?> PLAYER_LEADERBOARDS_ID_LIST)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.PLAYER_LEADERBOARDS_ID_LIST = string.Join(",", PLAYER_LEADERBOARDS_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_LEADERBOARDS_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYERSPORT_ID_List ( List<Int32?> PLAYERSPORT_ID_LIST)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.PLAYERSPORT_ID_LIST = string.Join(",", PLAYERSPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYERSPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Sport> Get_Sport_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_SPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACHSPORT_ID_List ( List<Int32?> COACHSPORT_ID_LIST)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.COACHSPORT_ID_LIST = string.Join(",", COACHSPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACHSPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_EVALUATION_ID_List ( List<Int32?> COACH_EVALUATION_ID_LIST)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_EVALUATION_ID_LIST = string.Join(",", COACH_EVALUATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_EVALUATION_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Currency> Get_Currency_By_CURRENCY_ID_List ( List<Int32?> CURRENCY_ID_LIST)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.CURRENCY_ID_LIST = string.Join(",", CURRENCY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_CURRENCY_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_SESSION_EVALUATION_ID_List ( List<Int32?> SESSION_EVALUATION_ID_LIST)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.SESSION_EVALUATION_ID_LIST = string.Join(",", SESSION_EVALUATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_SESSION_EVALUATION_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_TAKEN_SESSION_ID_List ( List<Int32?> TAKEN_SESSION_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.TAKEN_SESSION_ID_LIST = string.Join(",", TAKEN_SESSION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_TAKEN_SESSION_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List ( List<Int32?> SCHEDULED_SESSION_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.SCHEDULED_SESSION_ID_LIST = string.Join(",", SCHEDULED_SESSION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SCHEDULED_SESSION_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List ( List<Int32?> NOTIFICATION_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID_LIST = string.Join(",", NOTIFICATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Owner> Get_Owner_By_OWNER_ID_List ( List<Int32?> OWNER_ID_LIST)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.OWNER_ID_LIST = string.Join(",", OWNER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_OWNER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_COMMENT_ID_List ( List<Int32?> COMMENT_ID_LIST)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COMMENT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_REPORT_COACH_ID_List ( List<Int32?> REPORT_COACH_ID_LIST)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.REPORT_COACH_ID_LIST = string.Join(",", REPORT_COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_REPORT_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_REPORT_ID_List ( List<Int32?> COMMENT_REPORT_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COMMENT_REPORT_ID_LIST = string.Join(",", COMMENT_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_REPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USER_ID_List ( List<long?> USER_ID_LIST)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_DIRECT_MESSAGE_ID_List ( List<long?> DIRECT_MESSAGE_ID_LIST)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.DIRECT_MESSAGE_ID_LIST = string.Join(",", DIRECT_MESSAGE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_DIRECT_MESSAGE_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_REPORT_PLAYER_ID_List ( List<Int32?> REPORT_PLAYER_ID_LIST)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.REPORT_PLAYER_ID_LIST = string.Join(",", REPORT_PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_REPORT_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_Adv ( List<Int32?> COACH_LEADERBOARDS_ID_LIST)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.COACH_LEADERBOARDS_ID_LIST = string.Join(",", COACH_LEADERBOARDS_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_LEADERBOARDS_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_Adv ( List<Int32?> PLAYER_LEADERBOARDS_ID_LIST)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.PLAYER_LEADERBOARDS_ID_LIST = string.Join(",", PLAYER_LEADERBOARDS_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_LEADERBOARDS_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYERSPORT_ID_List_Adv ( List<Int32?> PLAYERSPORT_ID_LIST)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.PLAYERSPORT_ID_LIST = string.Join(",", PLAYERSPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYERSPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Sport> Get_Sport_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_SPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACHSPORT_ID_List_Adv ( List<Int32?> COACHSPORT_ID_LIST)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.COACHSPORT_ID_LIST = string.Join(",", COACHSPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACHSPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_Adv ( List<Int32?> COACH_EVALUATION_ID_LIST)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_EVALUATION_ID_LIST = string.Join(",", COACH_EVALUATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_EVALUATION_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Currency> Get_Currency_By_CURRENCY_ID_List_Adv ( List<Int32?> CURRENCY_ID_LIST)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.CURRENCY_ID_LIST = string.Join(",", CURRENCY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_CURRENCY_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_Adv ( List<Int32?> SESSION_EVALUATION_ID_LIST)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.SESSION_EVALUATION_ID_LIST = string.Join(",", SESSION_EVALUATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_SESSION_EVALUATION_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_TAKEN_SESSION_ID_List_Adv ( List<Int32?> TAKEN_SESSION_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.TAKEN_SESSION_ID_LIST = string.Join(",", TAKEN_SESSION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_TAKEN_SESSION_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_Adv ( List<Int32?> SCHEDULED_SESSION_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.SCHEDULED_SESSION_ID_LIST = string.Join(",", SCHEDULED_SESSION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SCHEDULED_SESSION_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List_Adv ( List<Int32?> NOTIFICATION_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID_LIST = string.Join(",", NOTIFICATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_COMMENT_ID_List_Adv ( List<Int32?> COMMENT_ID_LIST)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COMMENT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_REPORT_COACH_ID_List_Adv ( List<Int32?> REPORT_COACH_ID_LIST)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.REPORT_COACH_ID_LIST = string.Join(",", REPORT_COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_REPORT_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_REPORT_ID_List_Adv ( List<Int32?> COMMENT_REPORT_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COMMENT_REPORT_ID_LIST = string.Join(",", COMMENT_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_REPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_DIRECT_MESSAGE_ID_List_Adv ( List<long?> DIRECT_MESSAGE_ID_LIST)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.DIRECT_MESSAGE_ID_LIST = string.Join(",", DIRECT_MESSAGE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_DIRECT_MESSAGE_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_REPORT_PLAYER_ID_List_Adv ( List<Int32?> REPORT_PLAYER_ID_LIST)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.REPORT_PLAYER_ID_LIST = string.Join(",", REPORT_PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_REPORT_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID ( Int32? COACH_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID ( Int32? SPORT_ID)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_SPORT_ID", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Sport> Get_Sport_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID ( Int32? SPORT_ID)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_SPORT_ID", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID ( Int32? COACH_ID)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID ( Int32? COACH_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Currency> Get_Currency_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID ( Int32? COACH_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID ( Int32? COACH_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID ( Int32? SPORT_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_SPORT_ID", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID ( Int32? COACH_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID ( Int32? SPORT_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SPORT_ID", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID ( Int32? USER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID ( Int32? COACH_ID)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID ( Int32? USER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_USER_ID", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID ( Int32? COACH_ID)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID ( Int32? COACH_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COACH_ID", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID ( Int32? COMMENT_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COMMENT_ID = COMMENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_ID", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_OWNER_ID ( Int32? OWNER_ID)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USERNAME ( string USERNAME)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USERNAME", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID ( Int32? AUTHOR_ID)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.AUTHOR_ID = AUTHOR_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_AUTHOR_ID", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID ( Int32? RECIPIENT_ID)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.RECIPIENT_ID = RECIPIENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_RECIPIENT_ID", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID ( long? USER_ID)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_USER_ID", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID ( Int32? PLAYER_ID)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_PLAYER_ID", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID ( long? USER_ID)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_USER_ID", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_OWNER_ID", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_USER_ID ( long? USER_ID)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_USER_ID", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID_Adv ( Int32? SPORT_ID)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_SPORT_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Sport> Get_Sport_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID_Adv ( Int32? SPORT_ID)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_SPORT_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Currency> Get_Currency_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID_Adv ( Int32? SPORT_ID)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_SPORT_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_Adv ( Int32? SPORT_ID)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID = SPORT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SPORT_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_Adv ( Int32? USER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID_Adv ( Int32? USER_ID)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_USER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID_Adv ( Int32? COACH_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COACH_ID = COACH_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COACH_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID_Adv ( Int32? COMMENT_ID)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COMMENT_ID = COMMENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USERNAME_Adv ( string USERNAME)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USERNAME_ADV", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID_Adv ( Int32? AUTHOR_ID)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.AUTHOR_ID = AUTHOR_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_AUTHOR_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_Adv ( Int32? RECIPIENT_ID)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.RECIPIENT_ID = RECIPIENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_RECIPIENT_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID_Adv ( long? USER_ID)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_USER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID_Adv ( Int32? PLAYER_ID)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.PLAYER_ID = PLAYER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_PLAYER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID_Adv ( long? USER_ID)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_USER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_OWNER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_USER_ID_Adv ( long? USER_ID)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_USER_ID_ADV", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_SPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_SPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_SPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SPORT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List ( List<Int32?> USER_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID_List ( List<Int32?> USER_ID_LIST)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_USER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COACH_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID_List ( List<Int32?> COMMENT_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID_List ( List<Int32?> AUTHOR_ID_LIST)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.AUTHOR_ID_LIST = string.Join(",", AUTHOR_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_AUTHOR_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_List ( List<Int32?> RECIPIENT_ID_LIST)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.RECIPIENT_ID_LIST = string.Join(",", RECIPIENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_RECIPIENT_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID_List ( List<long?> USER_ID_LIST)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_USER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_PLAYER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID_List ( List<long?> USER_ID_LIST)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_USER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_USER_ID_List ( List<long?> USER_ID_LIST)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_USER_ID_LIST", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Playersport> Get_Playersport_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_SPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_SPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coachsport> Get_Coachsport_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Taken_session> Get_Taken_session_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_SPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_SPORT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment> Get_Comment_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_USER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_coach> Get_Report_coach_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COACH_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Comment_report> Get_Comment_report_By_COMMENT_ID_List_Adv ( List<Int32?> COMMENT_ID_LIST)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_COMMENT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_AUTHOR_ID_List_Adv ( List<Int32?> AUTHOR_ID_LIST)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.AUTHOR_ID_LIST = string.Join(",", AUTHOR_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_AUTHOR_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_List_Adv ( List<Int32?> RECIPIENT_ID_LIST)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.RECIPIENT_ID_LIST = string.Join(",", RECIPIENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_RECIPIENT_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_USER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_player> Get_Report_player_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_PLAYER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach> Get_Coach_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_USER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Player> Get_Player_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_USER_ID_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Sport> Get_Sport_By_Criteria ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.SPORT_NAME = SPORT_NAME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Sport> Get_Sport_By_Where ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.SPORT_NAME = SPORT_NAME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Currency> Get_Currency_By_Criteria ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.CURRENCY_NAME = CURRENCY_NAME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Currency> Get_Currency_By_Where ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.CURRENCY_NAME = CURRENCY_NAME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Criteria ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Where ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Criteria ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Where ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Criteria_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.MAINTENANCE_DUE_DATE = MAINTENANCE_DUE_DATE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_CRITERIA_V2", p);
if (R != null) {foreach (var X in R) {
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Where_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.MAINTENANCE_DUE_DATE = MAINTENANCE_DUE_DATE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_WHERE_V2", p);
if (R != null) {foreach (var X in R) {
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Criteria ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Where ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Criteria ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Where ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Direct_message> Get_Direct_message_By_Criteria ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Direct_message> Get_Direct_message_By_Where ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach> Get_Coach_By_Criteria ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach> Get_Coach_By_Where ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player> Get_Player_By_Criteria ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_CRITERIA", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player> Get_Player_By_Where ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_WHERE", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Sport> Get_Sport_By_Criteria_Adv ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.SPORT_NAME = SPORT_NAME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Sport> Get_Sport_By_Where_Adv ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Sport> oList = new List<Sport>();
dynamic p = new ExpandoObject();
p.SPORT_NAME = SPORT_NAME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SPORT_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Sport o = new Sport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Currency> Get_Currency_By_Criteria_Adv ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.CURRENCY_NAME = CURRENCY_NAME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Currency> Get_Currency_By_Where_Adv ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Currency> oList = new List<Currency>();
dynamic p = new ExpandoObject();
p.CURRENCY_NAME = CURRENCY_NAME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CURRENCY_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Currency o = new Currency();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria_Adv ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where_Adv ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria_Adv ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where_Adv ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Criteria_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Where_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Criteria_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Where_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Criteria_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Where_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
User o = new User();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Direct_message> Get_Direct_message_By_Criteria_Adv ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Direct_message> Get_Direct_message_By_Where_Adv ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Direct_message> oList = new List<Direct_message>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.DATETIME = DATETIME; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_DIRECT_MESSAGE_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Direct_message o = new Direct_message();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Author = new User();
o.My_Author.USER_ID = GV<Int64>(X["T_AUTHOR_USER_ID"]);o.My_Author.OWNER_ID = GV<Int32>(X["T_AUTHOR_OWNER_ID"]);o.My_Author.USERNAME = GV<String>(X["T_AUTHOR_USERNAME"]);o.My_Author.PASSWORD = GV<String>(X["T_AUTHOR_PASSWORD"]);o.My_Author.USER_TYPE_CODE = GV<String>(X["T_AUTHOR_USER_TYPE_CODE"]);o.My_Author.IS_LOGGED_IN = GV<Boolean>(X["T_AUTHOR_IS_LOGGED_IN"]);o.My_Author.IS_ACTIVE = GV<Boolean>(X["T_AUTHOR_IS_ACTIVE"]);o.My_Author.ENTRY_DATE = GV<String>(X["T_AUTHOR_ENTRY_DATE"]);
o.My_Recipient = new User();
o.My_Recipient.USER_ID = GV<Int64>(X["T_RECIPIENT_USER_ID"]);o.My_Recipient.OWNER_ID = GV<Int32>(X["T_RECIPIENT_OWNER_ID"]);o.My_Recipient.USERNAME = GV<String>(X["T_RECIPIENT_USERNAME"]);o.My_Recipient.PASSWORD = GV<String>(X["T_RECIPIENT_PASSWORD"]);o.My_Recipient.USER_TYPE_CODE = GV<String>(X["T_RECIPIENT_USER_TYPE_CODE"]);o.My_Recipient.IS_LOGGED_IN = GV<Boolean>(X["T_RECIPIENT_IS_LOGGED_IN"]);o.My_Recipient.IS_ACTIVE = GV<Boolean>(X["T_RECIPIENT_IS_ACTIVE"]);o.My_Recipient.ENTRY_DATE = GV<String>(X["T_RECIPIENT_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach> Get_Coach_By_Criteria_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach> Get_Coach_By_Where_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach> oList = new List<Coach>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Coach o = new Coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player> Get_Player_By_Criteria_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_CRITERIA_ADV", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player> Get_Player_By_Where_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player> oList = new List<Player>();
dynamic p = new ExpandoObject();
p.FIRSTNAME = FIRSTNAME; p.LASTNAME = LASTNAME; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.GEO_LOCATION = GEO_LOCATION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_BY_WHERE_ADV", p);
if (R != null) {foreach (var X in R) {
Player o = new Player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria_InList ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where_InList ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria_InList ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where_InList ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria_InList ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where_InList ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Criteria_InList ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Where_InList ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_CRITERIA_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_WHERE_IN_LIST", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_leaderboards> oList = new List<Coach_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_LEADERBOARDS_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_leaderboards o = new Coach_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Player_leaderboards> Get_Player_leaderboards_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Player_leaderboards> oList = new List<Player_leaderboards>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYER_LEADERBOARDS_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Player_leaderboards o = new Player_leaderboards();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Playersport> Get_Playersport_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Playersport> oList = new List<Playersport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_PLAYERSPORT_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Playersport o = new Playersport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coachsport> Get_Coachsport_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coachsport> oList = new List<Coachsport>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACHSPORT_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coachsport o = new Coachsport();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Coach_evaluation> Get_Coach_evaluation_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Coach_evaluation> oList = new List<Coach_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COACH_EVALUATION_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Coach_evaluation o = new Coach_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Session_evaluation> Get_Session_evaluation_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Session_evaluation> oList = new List<Session_evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SESSION_EVALUATION_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Session_evaluation o = new Session_evaluation();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Criteria_InList_Adv ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Taken_session> Get_Taken_session_By_Where_InList_Adv ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Taken_session> oList = new List<Taken_session>();
dynamic p = new ExpandoObject();
p.DATETIME = DATETIME; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TAKEN_SESSION_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Taken_session o = new Taken_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Criteria_InList_Adv ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Scheduled_session> Get_Scheduled_session_By_Where_InList_Adv ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Scheduled_session> oList = new List<Scheduled_session>();
dynamic p = new ExpandoObject();
p.DATE_TIME = DATE_TIME; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.SPORT_ID_LIST = string.Join(",", SPORT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_SCHEDULED_SESSION_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Scheduled_session o = new Scheduled_session();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Sport = new Sport();
o.My_Sport.SPORT_ID = GV<Int32>(X["T_SPORT_SPORT_ID"]);o.My_Sport.SPORT_NAME = GV<String>(X["T_SPORT_SPORT_NAME"]);o.My_Sport.DESCRIPTION = GV<String>(X["T_SPORT_DESCRIPTION"]);o.My_Sport.ENTRY_USER_ID = GV<Int64>(X["T_SPORT_ENTRY_USER_ID"]);o.My_Sport.ENTRY_DATE = GV<String>(X["T_SPORT_ENTRY_DATE"]);o.My_Sport.OWNER_ID = GV<Int32>(X["T_SPORT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Criteria_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment> Get_Comment_By_Where_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment> oList = new List<Comment>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment o = new Comment();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_coach> Get_Report_coach_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_coach> oList = new List<Report_coach>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_COACH_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_coach o = new Report_coach();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Comment_report> Get_Comment_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Comment_report> oList = new List<Comment_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.COACH_ID_LIST = string.Join(",", COACH_ID_LIST.ToArray()); p.COMMENT_ID_LIST = string.Join(",", COMMENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_COMMENT_REPORT_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Comment_report o = new Comment_report();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
o.My_Coach = new Coach();
o.My_Coach.COACH_ID = GV<Int32>(X["T_COACH_COACH_ID"]);o.My_Coach.USER_ID = GV<Int64>(X["T_COACH_USER_ID"]);o.My_Coach.FIRSTNAME = GV<String>(X["T_COACH_FIRSTNAME"]);o.My_Coach.LASTNAME = GV<String>(X["T_COACH_LASTNAME"]);o.My_Coach.PRICE_PER_SESSION = GV<Int32>(X["T_COACH_PRICE_PER_SESSION"]);o.My_Coach.EMAIL = GV<String>(X["T_COACH_EMAIL"]);o.My_Coach.MOBILE = GV<String>(X["T_COACH_MOBILE"]);o.My_Coach.AGE = GV<Int32>(X["T_COACH_AGE"]);o.My_Coach.GEO_LOCATION = GV<String>(X["T_COACH_GEO_LOCATION"]);o.My_Coach.SCORE = GV<Int32>(X["T_COACH_SCORE"]);o.My_Coach.SESSIONS_COMPLETED = GV<Int32>(X["T_COACH_SESSIONS_COMPLETED"]);o.My_Coach.REPORT = GV<Int32>(X["T_COACH_REPORT"]);o.My_Coach.IS_BLOCKED = GV<Boolean>(X["T_COACH_IS_BLOCKED"]);o.My_Coach.ENTRY_USER_ID = GV<Int64>(X["T_COACH_ENTRY_USER_ID"]);o.My_Coach.ENTRY_DATE = GV<String>(X["T_COACH_ENTRY_DATE"]);o.My_Coach.OWNER_ID = GV<Int32>(X["T_COACH_OWNER_ID"]);
o.My_Comment = new Comment();
o.My_Comment.COMMENT_ID = GV<Int32>(X["T_COMMENT_COMMENT_ID"]);o.My_Comment.PLAYER_ID = GV<Int32>(X["T_COMMENT_PLAYER_ID"]);o.My_Comment.COACH_ID = GV<Int32>(X["T_COMMENT_COACH_ID"]);o.My_Comment.IS_BLOCKED = GV<Boolean>(X["T_COMMENT_IS_BLOCKED"]);o.My_Comment.REPORTS = GV<Int32>(X["T_COMMENT_REPORTS"]);o.My_Comment.TITLE = GV<String>(X["T_COMMENT_TITLE"]);o.My_Comment.DESCRIPTION = GV<String>(X["T_COMMENT_DESCRIPTION"]);o.My_Comment.ENTRY_USER_ID = GV<Int64>(X["T_COMMENT_ENTRY_USER_ID"]);o.My_Comment.ENTRY_DATE = GV<String>(X["T_COMMENT_ENTRY_DATE"]);o.My_Comment.OWNER_ID = GV<Int32>(X["T_COMMENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_player> Get_Report_player_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_player> oList = new List<Report_player>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.PLAYER_ID_LIST = string.Join(",", PLAYER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_PLAYER_BY_WHERE_IN_LIST_ADV", p);
if (R != null) {foreach (var X in R) {
Report_player o = new Report_player();
oTools.CopyPropValues_FromDataRecord(X, o);
o.My_User = new User();
o.My_User.USER_ID = GV<Int64>(X["T_USER_USER_ID"]);o.My_User.OWNER_ID = GV<Int32>(X["T_USER_OWNER_ID"]);o.My_User.USERNAME = GV<String>(X["T_USER_USERNAME"]);o.My_User.PASSWORD = GV<String>(X["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = GV<String>(X["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = GV<Boolean>(X["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = GV<Boolean>(X["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = GV<String>(X["T_USER_ENTRY_DATE"]);
o.My_Player = new Player();
o.My_Player.PLAYER_ID = GV<Int32>(X["T_PLAYER_PLAYER_ID"]);o.My_Player.FIRSTNAME = GV<String>(X["T_PLAYER_FIRSTNAME"]);o.My_Player.LASTNAME = GV<String>(X["T_PLAYER_LASTNAME"]);o.My_Player.USER_ID = GV<Int64>(X["T_PLAYER_USER_ID"]);o.My_Player.EMAIL = GV<String>(X["T_PLAYER_EMAIL"]);o.My_Player.MOBILE = GV<String>(X["T_PLAYER_MOBILE"]);o.My_Player.AGE = GV<Int32>(X["T_PLAYER_AGE"]);o.My_Player.GEO_LOCATION = GV<String>(X["T_PLAYER_GEO_LOCATION"]);o.My_Player.SESSIONS_COMPLETED = GV<Int32>(X["T_PLAYER_SESSIONS_COMPLETED"]);o.My_Player.IS_BLOCKED = GV<Boolean>(X["T_PLAYER_IS_BLOCKED"]);o.My_Player.REPORTS = GV<Int32>(X["T_PLAYER_REPORTS"]);o.My_Player.ENTRY_USER_ID = GV<Int64>(X["T_PLAYER_ENTRY_USER_ID"]);o.My_Player.ENTRY_DATE = GV<String>(X["T_PLAYER_ENTRY_DATE"]);o.My_Player.OWNER_ID = GV<Int32>(X["T_PLAYER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public void Delete_Coach_leaderboards ( Int32? COACH_LEADERBOARDS_ID)
{
var p = new { COACH_LEADERBOARDS_ID = COACH_LEADERBOARDS_ID };
ExecuteDelete("UPG_DELETE_COACH_LEADERBOARDS", p);
}
public void Delete_Player_leaderboards ( Int32? PLAYER_LEADERBOARDS_ID)
{
var p = new { PLAYER_LEADERBOARDS_ID = PLAYER_LEADERBOARDS_ID };
ExecuteDelete("UPG_DELETE_PLAYER_LEADERBOARDS", p);
}
public void Delete_Playersport ( Int32? PLAYERSPORT_ID)
{
var p = new { PLAYERSPORT_ID = PLAYERSPORT_ID };
ExecuteDelete("UPG_DELETE_PLAYERSPORT", p);
}
public void Delete_Sport ( Int32? SPORT_ID)
{
var p = new { SPORT_ID = SPORT_ID };
ExecuteDelete("UPG_DELETE_SPORT", p);
}
public void Delete_Coachsport ( Int32? COACHSPORT_ID)
{
var p = new { COACHSPORT_ID = COACHSPORT_ID };
ExecuteDelete("UPG_DELETE_COACHSPORT", p);
}
public void Delete_Coach_evaluation ( Int32? COACH_EVALUATION_ID)
{
var p = new { COACH_EVALUATION_ID = COACH_EVALUATION_ID };
ExecuteDelete("UPG_DELETE_COACH_EVALUATION", p);
}
public void Delete_Currency ( Int32? CURRENCY_ID)
{
var p = new { CURRENCY_ID = CURRENCY_ID };
ExecuteDelete("UPG_DELETE_CURRENCY", p);
}
public void Delete_Session_evaluation ( Int32? SESSION_EVALUATION_ID)
{
var p = new { SESSION_EVALUATION_ID = SESSION_EVALUATION_ID };
ExecuteDelete("UPG_DELETE_SESSION_EVALUATION", p);
}
public void Delete_Taken_session ( Int32? TAKEN_SESSION_ID)
{
var p = new { TAKEN_SESSION_ID = TAKEN_SESSION_ID };
ExecuteDelete("UPG_DELETE_TAKEN_SESSION", p);
}
public void Delete_Scheduled_session ( Int32? SCHEDULED_SESSION_ID)
{
var p = new { SCHEDULED_SESSION_ID = SCHEDULED_SESSION_ID };
ExecuteDelete("UPG_DELETE_SCHEDULED_SESSION", p);
}
public void Delete_Notification ( Int32? NOTIFICATION_ID)
{
var p = new { NOTIFICATION_ID = NOTIFICATION_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION", p);
}
public void Delete_Owner ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_OWNER", p);
}
public void Delete_Comment ( Int32? COMMENT_ID)
{
var p = new { COMMENT_ID = COMMENT_ID };
ExecuteDelete("UPG_DELETE_COMMENT", p);
}
public void Delete_Report_coach ( Int32? REPORT_COACH_ID)
{
var p = new { REPORT_COACH_ID = REPORT_COACH_ID };
ExecuteDelete("UPG_DELETE_REPORT_COACH", p);
}
public void Delete_Comment_report ( Int32? COMMENT_REPORT_ID)
{
var p = new { COMMENT_REPORT_ID = COMMENT_REPORT_ID };
ExecuteDelete("UPG_DELETE_COMMENT_REPORT", p);
}
public void Delete_User ( long? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_USER", p);
}
public void Delete_Direct_message ( long? DIRECT_MESSAGE_ID)
{
var p = new { DIRECT_MESSAGE_ID = DIRECT_MESSAGE_ID };
ExecuteDelete("UPG_DELETE_DIRECT_MESSAGE", p);
}
public void Delete_Report_player ( Int32? REPORT_PLAYER_ID)
{
var p = new { REPORT_PLAYER_ID = REPORT_PLAYER_ID };
ExecuteDelete("UPG_DELETE_REPORT_PLAYER", p);
}
public void Delete_Coach ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_COACH", p);
}
public void Delete_Player ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_PLAYER", p);
}
public void Delete_Coach_leaderboards_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_COACH_LEADERBOARDS_BY_OWNER_ID", p);
}
public void Delete_Coach_leaderboards_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_COACH_LEADERBOARDS_BY_COACH_ID", p);
}
public void Delete_Player_leaderboards_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_PLAYER_LEADERBOARDS_BY_OWNER_ID", p);
}
public void Delete_Player_leaderboards_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_PLAYER_LEADERBOARDS_BY_PLAYER_ID", p);
}
public void Delete_Playersport_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_PLAYERSPORT_BY_OWNER_ID", p);
}
public void Delete_Playersport_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_PLAYERSPORT_BY_PLAYER_ID", p);
}
public void Delete_Playersport_By_SPORT_ID ( Int32? SPORT_ID)
{
var p = new { SPORT_ID = SPORT_ID };
ExecuteDelete("UPG_DELETE_PLAYERSPORT_BY_SPORT_ID", p);
}
public void Delete_Sport_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_SPORT_BY_OWNER_ID", p);
}
public void Delete_Coachsport_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_COACHSPORT_BY_OWNER_ID", p);
}
public void Delete_Coachsport_By_SPORT_ID ( Int32? SPORT_ID)
{
var p = new { SPORT_ID = SPORT_ID };
ExecuteDelete("UPG_DELETE_COACHSPORT_BY_SPORT_ID", p);
}
public void Delete_Coachsport_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_COACHSPORT_BY_COACH_ID", p);
}
public void Delete_Coach_evaluation_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_COACH_EVALUATION_BY_OWNER_ID", p);
}
public void Delete_Coach_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_COACH_EVALUATION_BY_PLAYER_ID", p);
}
public void Delete_Coach_evaluation_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_COACH_EVALUATION_BY_COACH_ID", p);
}
public void Delete_Currency_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_CURRENCY_BY_OWNER_ID", p);
}
public void Delete_Session_evaluation_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_SESSION_EVALUATION_BY_OWNER_ID", p);
}
public void Delete_Session_evaluation_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_SESSION_EVALUATION_BY_COACH_ID", p);
}
public void Delete_Session_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_SESSION_EVALUATION_BY_PLAYER_ID", p);
}
public void Delete_Taken_session_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_TAKEN_SESSION_BY_OWNER_ID", p);
}
public void Delete_Taken_session_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_TAKEN_SESSION_BY_COACH_ID", p);
}
public void Delete_Taken_session_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_TAKEN_SESSION_BY_PLAYER_ID", p);
}
public void Delete_Taken_session_By_SPORT_ID ( Int32? SPORT_ID)
{
var p = new { SPORT_ID = SPORT_ID };
ExecuteDelete("UPG_DELETE_TAKEN_SESSION_BY_SPORT_ID", p);
}
public void Delete_Scheduled_session_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_SCHEDULED_SESSION_BY_OWNER_ID", p);
}
public void Delete_Scheduled_session_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_SCHEDULED_SESSION_BY_PLAYER_ID", p);
}
public void Delete_Scheduled_session_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_SCHEDULED_SESSION_BY_COACH_ID", p);
}
public void Delete_Scheduled_session_By_SPORT_ID ( Int32? SPORT_ID)
{
var p = new { SPORT_ID = SPORT_ID };
ExecuteDelete("UPG_DELETE_SCHEDULED_SESSION_BY_SPORT_ID", p);
}
public void Delete_Notification_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION_BY_OWNER_ID", p);
}
public void Delete_Notification_By_USER_ID ( Int32? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION_BY_USER_ID", p);
}
public void Delete_Comment_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_COMMENT_BY_OWNER_ID", p);
}
public void Delete_Comment_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_COMMENT_BY_PLAYER_ID", p);
}
public void Delete_Comment_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_COMMENT_BY_COACH_ID", p);
}
public void Delete_Report_coach_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_REPORT_COACH_BY_OWNER_ID", p);
}
public void Delete_Report_coach_By_USER_ID ( Int32? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_REPORT_COACH_BY_USER_ID", p);
}
public void Delete_Report_coach_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_REPORT_COACH_BY_COACH_ID", p);
}
public void Delete_Comment_report_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_COMMENT_REPORT_BY_OWNER_ID", p);
}
public void Delete_Comment_report_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_COMMENT_REPORT_BY_PLAYER_ID", p);
}
public void Delete_Comment_report_By_COACH_ID ( Int32? COACH_ID)
{
var p = new { COACH_ID = COACH_ID };
ExecuteDelete("UPG_DELETE_COMMENT_REPORT_BY_COACH_ID", p);
}
public void Delete_Comment_report_By_COMMENT_ID ( Int32? COMMENT_ID)
{
var p = new { COMMENT_ID = COMMENT_ID };
ExecuteDelete("UPG_DELETE_COMMENT_REPORT_BY_COMMENT_ID", p);
}
public void Delete_User_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_USER_BY_OWNER_ID", p);
}
public void Delete_User_By_USERNAME ( string USERNAME)
{
var p = new { USERNAME = USERNAME };
ExecuteDelete("UPG_DELETE_USER_BY_USERNAME", p);
}
public void Delete_Direct_message_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_DIRECT_MESSAGE_BY_OWNER_ID", p);
}
public void Delete_Direct_message_By_AUTHOR_ID ( Int32? AUTHOR_ID)
{
var p = new { AUTHOR_ID = AUTHOR_ID };
ExecuteDelete("UPG_DELETE_DIRECT_MESSAGE_BY_AUTHOR_ID", p);
}
public void Delete_Direct_message_By_RECIPIENT_ID ( Int32? RECIPIENT_ID)
{
var p = new { RECIPIENT_ID = RECIPIENT_ID };
ExecuteDelete("UPG_DELETE_DIRECT_MESSAGE_BY_RECIPIENT_ID", p);
}
public void Delete_Report_player_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_REPORT_PLAYER_BY_OWNER_ID", p);
}
public void Delete_Report_player_By_USER_ID ( long? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_REPORT_PLAYER_BY_USER_ID", p);
}
public void Delete_Report_player_By_PLAYER_ID ( Int32? PLAYER_ID)
{
var p = new { PLAYER_ID = PLAYER_ID };
ExecuteDelete("UPG_DELETE_REPORT_PLAYER_BY_PLAYER_ID", p);
}
public void Delete_Coach_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_COACH_BY_OWNER_ID", p);
}
public void Delete_Coach_By_USER_ID ( long? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_COACH_BY_USER_ID", p);
}
public void Delete_Player_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_PLAYER_BY_OWNER_ID", p);
}
public void Delete_Player_By_USER_ID ( long? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_PLAYER_BY_USER_ID", p);
}
public Int32? Edit_Coach_leaderboards ( Int32? COACH_LEADERBOARDS_ID, Int32? COACH_ID, Int32? POINTS, Int32? STANDING, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION)
{
Coach_leaderboards oCoach_leaderboards = new Coach_leaderboards();
oCoach_leaderboards.COACH_LEADERBOARDS_ID = COACH_LEADERBOARDS_ID;oCoach_leaderboards.COACH_ID = COACH_ID;oCoach_leaderboards.POINTS = POINTS;oCoach_leaderboards.STANDING = STANDING;oCoach_leaderboards.ENTRY_USER_ID = ENTRY_USER_ID;oCoach_leaderboards.ENTRY_DATE = ENTRY_DATE;oCoach_leaderboards.OWNER_ID = OWNER_ID;oCoach_leaderboards.DESCRIPTION = DESCRIPTION;
ExecuteEdit("UPG_EDIT_COACH_LEADERBOARDS", oCoach_leaderboards, "COACH_LEADERBOARDS_ID");
return oCoach_leaderboards.COACH_LEADERBOARDS_ID;
}
public Int32? Edit_Player_leaderboards ( Int32? PLAYER_LEADERBOARDS_ID, Int32? PLAYER_ID, Int32? POINTS, Int32? STANDING, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION)
{
Player_leaderboards oPlayer_leaderboards = new Player_leaderboards();
oPlayer_leaderboards.PLAYER_LEADERBOARDS_ID = PLAYER_LEADERBOARDS_ID;oPlayer_leaderboards.PLAYER_ID = PLAYER_ID;oPlayer_leaderboards.POINTS = POINTS;oPlayer_leaderboards.STANDING = STANDING;oPlayer_leaderboards.ENTRY_USER_ID = ENTRY_USER_ID;oPlayer_leaderboards.ENTRY_DATE = ENTRY_DATE;oPlayer_leaderboards.OWNER_ID = OWNER_ID;oPlayer_leaderboards.DESCRIPTION = DESCRIPTION;
ExecuteEdit("UPG_EDIT_PLAYER_LEADERBOARDS", oPlayer_leaderboards, "PLAYER_LEADERBOARDS_ID");
return oPlayer_leaderboards.PLAYER_LEADERBOARDS_ID;
}
public Int32? Edit_Playersport ( Int32? PLAYERSPORT_ID, Int32? PLAYER_ID, Int32? SPORT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Playersport oPlayersport = new Playersport();
oPlayersport.PLAYERSPORT_ID = PLAYERSPORT_ID;oPlayersport.PLAYER_ID = PLAYER_ID;oPlayersport.SPORT_ID = SPORT_ID;oPlayersport.DESCRIPTION = DESCRIPTION;oPlayersport.ENTRY_USER_ID = ENTRY_USER_ID;oPlayersport.ENTRY_DATE = ENTRY_DATE;oPlayersport.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_PLAYERSPORT", oPlayersport, "PLAYERSPORT_ID");
return oPlayersport.PLAYERSPORT_ID;
}
public Int32? Edit_Sport ( Int32? SPORT_ID, string SPORT_NAME, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Sport oSport = new Sport();
oSport.SPORT_ID = SPORT_ID;oSport.SPORT_NAME = SPORT_NAME;oSport.DESCRIPTION = DESCRIPTION;oSport.ENTRY_USER_ID = ENTRY_USER_ID;oSport.ENTRY_DATE = ENTRY_DATE;oSport.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_SPORT", oSport, "SPORT_ID");
return oSport.SPORT_ID;
}
public Int32? Edit_Coachsport ( Int32? COACHSPORT_ID, Int32? SPORT_ID, Int32? COACH_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Coachsport oCoachsport = new Coachsport();
oCoachsport.COACHSPORT_ID = COACHSPORT_ID;oCoachsport.SPORT_ID = SPORT_ID;oCoachsport.COACH_ID = COACH_ID;oCoachsport.DESCRIPTION = DESCRIPTION;oCoachsport.ENTRY_USER_ID = ENTRY_USER_ID;oCoachsport.ENTRY_DATE = ENTRY_DATE;oCoachsport.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_COACHSPORT", oCoachsport, "COACHSPORT_ID");
return oCoachsport.COACHSPORT_ID;
}
public Int32? Edit_Coach_evaluation ( Int32? COACH_EVALUATION_ID, Int32? PLAYER_ID, Int32? COACH_ID, decimal RATING, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Coach_evaluation oCoach_evaluation = new Coach_evaluation();
oCoach_evaluation.COACH_EVALUATION_ID = COACH_EVALUATION_ID;oCoach_evaluation.PLAYER_ID = PLAYER_ID;oCoach_evaluation.COACH_ID = COACH_ID;oCoach_evaluation.RATING = RATING;oCoach_evaluation.DESCRIPTION = DESCRIPTION;oCoach_evaluation.ENTRY_USER_ID = ENTRY_USER_ID;oCoach_evaluation.ENTRY_DATE = ENTRY_DATE;oCoach_evaluation.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_COACH_EVALUATION", oCoach_evaluation, "COACH_EVALUATION_ID");
return oCoach_evaluation.COACH_EVALUATION_ID;
}
public Int32? Edit_Currency ( Int32? CURRENCY_ID, string CURRENCY_NAME, decimal TO_USD, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Currency oCurrency = new Currency();
oCurrency.CURRENCY_ID = CURRENCY_ID;oCurrency.CURRENCY_NAME = CURRENCY_NAME;oCurrency.TO_USD = TO_USD;oCurrency.ENTRY_USER_ID = ENTRY_USER_ID;oCurrency.ENTRY_DATE = ENTRY_DATE;oCurrency.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_CURRENCY", oCurrency, "CURRENCY_ID");
return oCurrency.CURRENCY_ID;
}
public Int32? Edit_Session_evaluation ( Int32? SESSION_EVALUATION_ID, Int32? COACH_ID, Int32? PLAYER_ID, decimal SESSION_RATING, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Session_evaluation oSession_evaluation = new Session_evaluation();
oSession_evaluation.SESSION_EVALUATION_ID = SESSION_EVALUATION_ID;oSession_evaluation.COACH_ID = COACH_ID;oSession_evaluation.PLAYER_ID = PLAYER_ID;oSession_evaluation.SESSION_RATING = SESSION_RATING;oSession_evaluation.DESCRIPTION = DESCRIPTION;oSession_evaluation.ENTRY_USER_ID = ENTRY_USER_ID;oSession_evaluation.ENTRY_DATE = ENTRY_DATE;oSession_evaluation.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_SESSION_EVALUATION", oSession_evaluation, "SESSION_EVALUATION_ID");
return oSession_evaluation.SESSION_EVALUATION_ID;
}
public Int32? Edit_Taken_session ( Int32? TAKEN_SESSION_ID, Int32? COACH_ID, Int32? PLAYER_ID, Int32? SPORT_ID, string DATETIME, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Taken_session oTaken_session = new Taken_session();
oTaken_session.TAKEN_SESSION_ID = TAKEN_SESSION_ID;oTaken_session.COACH_ID = COACH_ID;oTaken_session.PLAYER_ID = PLAYER_ID;oTaken_session.SPORT_ID = SPORT_ID;oTaken_session.DATETIME = DATETIME;oTaken_session.ENTRY_USER_ID = ENTRY_USER_ID;oTaken_session.ENTRY_DATE = ENTRY_DATE;oTaken_session.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_TAKEN_SESSION", oTaken_session, "TAKEN_SESSION_ID");
return oTaken_session.TAKEN_SESSION_ID;
}
public Int32? Edit_Scheduled_session ( Int32? SCHEDULED_SESSION_ID, Int32? PLAYER_ID, Int32? COACH_ID, Int32? SPORT_ID, string DATE_TIME, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Scheduled_session oScheduled_session = new Scheduled_session();
oScheduled_session.SCHEDULED_SESSION_ID = SCHEDULED_SESSION_ID;oScheduled_session.PLAYER_ID = PLAYER_ID;oScheduled_session.COACH_ID = COACH_ID;oScheduled_session.SPORT_ID = SPORT_ID;oScheduled_session.DATE_TIME = DATE_TIME;oScheduled_session.DESCRIPTION = DESCRIPTION;oScheduled_session.ENTRY_USER_ID = ENTRY_USER_ID;oScheduled_session.ENTRY_DATE = ENTRY_DATE;oScheduled_session.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_SCHEDULED_SESSION", oScheduled_session, "SCHEDULED_SESSION_ID");
return oScheduled_session.SCHEDULED_SESSION_ID;
}
public Int32? Edit_Notification ( Int32? NOTIFICATION_ID, Int32? USER_ID, string TITLE, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Notification oNotification = new Notification();
oNotification.NOTIFICATION_ID = NOTIFICATION_ID;oNotification.USER_ID = USER_ID;oNotification.TITLE = TITLE;oNotification.DESCRIPTION = DESCRIPTION;oNotification.ENTRY_USER_ID = ENTRY_USER_ID;oNotification.ENTRY_DATE = ENTRY_DATE;oNotification.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_NOTIFICATION", oNotification, "NOTIFICATION_ID");
return oNotification.NOTIFICATION_ID;
}
public Int32? Edit_Owner ( Int32? OWNER_ID, string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, string ENTRY_DATE)
{
Owner oOwner = new Owner();
oOwner.OWNER_ID = OWNER_ID;oOwner.CODE = CODE;oOwner.MAINTENANCE_DUE_DATE = MAINTENANCE_DUE_DATE;oOwner.DESCRIPTION = DESCRIPTION;oOwner.ENTRY_DATE = ENTRY_DATE;
ExecuteEdit("UPG_EDIT_OWNER", oOwner, "OWNER_ID");
return oOwner.OWNER_ID;
}
public Int32? Edit_Comment ( Int32? COMMENT_ID, Int32? PLAYER_ID, Int32? COACH_ID, bool? IS_BLOCKED, Int32? REPORTS, string TITLE, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Comment oComment = new Comment();
oComment.COMMENT_ID = COMMENT_ID;oComment.PLAYER_ID = PLAYER_ID;oComment.COACH_ID = COACH_ID;oComment.IS_BLOCKED = IS_BLOCKED;oComment.REPORTS = REPORTS;oComment.TITLE = TITLE;oComment.DESCRIPTION = DESCRIPTION;oComment.ENTRY_USER_ID = ENTRY_USER_ID;oComment.ENTRY_DATE = ENTRY_DATE;oComment.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_COMMENT", oComment, "COMMENT_ID");
return oComment.COMMENT_ID;
}
public Int32? Edit_Report_coach ( Int32? REPORT_COACH_ID, Int32? USER_ID, Int32? COACH_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Report_coach oReport_coach = new Report_coach();
oReport_coach.REPORT_COACH_ID = REPORT_COACH_ID;oReport_coach.USER_ID = USER_ID;oReport_coach.COACH_ID = COACH_ID;oReport_coach.DESCRIPTION = DESCRIPTION;oReport_coach.ENTRY_USER_ID = ENTRY_USER_ID;oReport_coach.ENTRY_DATE = ENTRY_DATE;oReport_coach.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_REPORT_COACH", oReport_coach, "REPORT_COACH_ID");
return oReport_coach.REPORT_COACH_ID;
}
public Int32? Edit_Comment_report ( Int32? COMMENT_REPORT_ID, Int32? PLAYER_ID, Int32? COACH_ID, Int32? COMMENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Comment_report oComment_report = new Comment_report();
oComment_report.COMMENT_REPORT_ID = COMMENT_REPORT_ID;oComment_report.PLAYER_ID = PLAYER_ID;oComment_report.COACH_ID = COACH_ID;oComment_report.COMMENT_ID = COMMENT_ID;oComment_report.DESCRIPTION = DESCRIPTION;oComment_report.ENTRY_USER_ID = ENTRY_USER_ID;oComment_report.ENTRY_DATE = ENTRY_DATE;oComment_report.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_COMMENT_REPORT", oComment_report, "COMMENT_REPORT_ID");
return oComment_report.COMMENT_REPORT_ID;
}
public long? Edit_User ( long? USER_ID, Int32? OWNER_ID, string USERNAME, string PASSWORD, string USER_TYPE_CODE, bool? IS_LOGGED_IN, bool? IS_ACTIVE, string ENTRY_DATE)
{
User oUser = new User();
oUser.USER_ID = USER_ID;oUser.OWNER_ID = OWNER_ID;oUser.USERNAME = USERNAME;oUser.PASSWORD = PASSWORD;oUser.USER_TYPE_CODE = USER_TYPE_CODE;oUser.IS_LOGGED_IN = IS_LOGGED_IN;oUser.IS_ACTIVE = IS_ACTIVE;oUser.ENTRY_DATE = ENTRY_DATE;
ExecuteEdit("UPG_EDIT_USER", oUser, "USER_ID");
return oUser.USER_ID;
}
public long? Edit_Direct_message ( long? DIRECT_MESSAGE_ID, Int32? AUTHOR_ID, Int32? RECIPIENT_ID, string DESCRIPTION, bool? IS_DELETED_BY_RECIPIENT, string DATETIME, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Direct_message oDirect_message = new Direct_message();
oDirect_message.DIRECT_MESSAGE_ID = DIRECT_MESSAGE_ID;oDirect_message.AUTHOR_ID = AUTHOR_ID;oDirect_message.RECIPIENT_ID = RECIPIENT_ID;oDirect_message.DESCRIPTION = DESCRIPTION;oDirect_message.IS_DELETED_BY_RECIPIENT = IS_DELETED_BY_RECIPIENT;oDirect_message.DATETIME = DATETIME;oDirect_message.ENTRY_USER_ID = ENTRY_USER_ID;oDirect_message.ENTRY_DATE = ENTRY_DATE;oDirect_message.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_DIRECT_MESSAGE", oDirect_message, "DIRECT_MESSAGE_ID");
return oDirect_message.DIRECT_MESSAGE_ID;
}
public Int32? Edit_Report_player ( Int32? REPORT_PLAYER_ID, long? USER_ID, Int32? PLAYER_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Report_player oReport_player = new Report_player();
oReport_player.REPORT_PLAYER_ID = REPORT_PLAYER_ID;oReport_player.USER_ID = USER_ID;oReport_player.PLAYER_ID = PLAYER_ID;oReport_player.DESCRIPTION = DESCRIPTION;oReport_player.ENTRY_USER_ID = ENTRY_USER_ID;oReport_player.ENTRY_DATE = ENTRY_DATE;oReport_player.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_REPORT_PLAYER", oReport_player, "REPORT_PLAYER_ID");
return oReport_player.REPORT_PLAYER_ID;
}
public Int32? Edit_Coach ( Int32? COACH_ID, long? USER_ID, string FIRSTNAME, string LASTNAME, Int32? PRICE_PER_SESSION, string EMAIL, string MOBILE, Int32? AGE, string GEO_LOCATION, Int32? SCORE, Int32? SESSIONS_COMPLETED, Int32? REPORT, bool? IS_BLOCKED, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Coach oCoach = new Coach();
oCoach.COACH_ID = COACH_ID;oCoach.USER_ID = USER_ID;oCoach.FIRSTNAME = FIRSTNAME;oCoach.LASTNAME = LASTNAME;oCoach.PRICE_PER_SESSION = PRICE_PER_SESSION;oCoach.EMAIL = EMAIL;oCoach.MOBILE = MOBILE;oCoach.AGE = AGE;oCoach.GEO_LOCATION = GEO_LOCATION;oCoach.SCORE = SCORE;oCoach.SESSIONS_COMPLETED = SESSIONS_COMPLETED;oCoach.REPORT = REPORT;oCoach.IS_BLOCKED = IS_BLOCKED;oCoach.ENTRY_USER_ID = ENTRY_USER_ID;oCoach.ENTRY_DATE = ENTRY_DATE;oCoach.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_COACH", oCoach, "COACH_ID");
return oCoach.COACH_ID;
}
public Int32? Edit_Player ( Int32? PLAYER_ID, string FIRSTNAME, string LASTNAME, long? USER_ID, string EMAIL, string MOBILE, Int32? AGE, string GEO_LOCATION, Int32? SESSIONS_COMPLETED, bool? IS_BLOCKED, Int32? REPORTS, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Player oPlayer = new Player();
oPlayer.PLAYER_ID = PLAYER_ID;oPlayer.FIRSTNAME = FIRSTNAME;oPlayer.LASTNAME = LASTNAME;oPlayer.USER_ID = USER_ID;oPlayer.EMAIL = EMAIL;oPlayer.MOBILE = MOBILE;oPlayer.AGE = AGE;oPlayer.GEO_LOCATION = GEO_LOCATION;oPlayer.SESSIONS_COMPLETED = SESSIONS_COMPLETED;oPlayer.IS_BLOCKED = IS_BLOCKED;oPlayer.REPORTS = REPORTS;oPlayer.ENTRY_USER_ID = ENTRY_USER_ID;oPlayer.ENTRY_DATE = ENTRY_DATE;oPlayer.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_PLAYER", oPlayer, "PLAYER_ID");
return oPlayer.PLAYER_ID;
}
public List<dynamic> GET_DISTINCT_SETUP_TBL ( Int32? OWNER_ID)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("GET_DISTINCT_SETUP_TBL", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.TBL_NAME = GV<String>(X["TBL_NAME"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> GET_NEXT_VALUE ( string STARTER_CODE)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.STARTER_CODE = STARTER_CODE;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("GET_NEXT_VALUE", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.LAST_VALUE = GV<Int64>(X["LAST_VALUE"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> GET_TBL_SETUP ()
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
IEnumerable<IDataRecord> R = ExecuteSelectQuery("GET_TBL_SETUP", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.OWNER_ID = GV<Int32>(X["OWNER_ID"]);o.TBL_NAME = GV<String>(X["TBL_NAME"]);o.CODE_NAME = GV<String>(X["CODE_NAME"]);o.ISSYSTEM = GV<Boolean>(X["ISSYSTEM"]);o.ISDELETEABLE = GV<Boolean>(X["ISDELETEABLE"]);o.ISUPDATEABLE = GV<Boolean>(X["ISUPDATEABLE"]);o.ISDELETED = GV<Boolean>(X["ISDELETED"]);o.ISVISIBLE = GV<Boolean>(X["ISVISIBLE"]);o.DISPLAY_ORDER = GV<Int32>(X["DISPLAY_ORDER"]);o.CODE_VALUE_EN = GV<String>(X["CODE_VALUE_EN"]);o.CODE_VALUE_FR = GV<String>(X["CODE_VALUE_FR"]);o.CODE_VALUE_AR = GV<String>(X["CODE_VALUE_AR"]);o.NOTES = GV<String>(X["NOTES"]);o.ENTRY_DATE = GV<String>(X["ENTRY_DATE"]);o.ENTRY_USER_ID = GV<Int64>(X["ENTRY_USER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_CHECK_USER_EXISTENCE ( Int32? OWNER_ID, string USERNAME,ref  bool? EXISTS)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.USERNAME = USERNAME; p.EXISTS = EXISTS;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_CHECK_USER_EXISTENCE", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
EXISTS = p.EXISTS;
return oList;
}
public List<dynamic> UP_EDIT_SETUP ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME, bool? ISSYSTEM, bool? ISDELETEABLE, bool? ISUPDATEABLE, bool? ISVISIBLE, bool? ISDELETED, Int32? DISPLAY_ORDER, string CODE_VALUE_EN, string CODE_VALUE_FR, string CODE_VALUE_AR, string ENTRY_DATE, Int32? ENTRY_USER_ID, string NOTES)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.TBL_NAME = TBL_NAME; p.CODE_NAME = CODE_NAME; p.ISSYSTEM = ISSYSTEM; p.ISDELETEABLE = ISDELETEABLE; p.ISUPDATEABLE = ISUPDATEABLE; p.ISVISIBLE = ISVISIBLE; p.ISDELETED = ISDELETED; p.DISPLAY_ORDER = DISPLAY_ORDER; p.CODE_VALUE_EN = CODE_VALUE_EN; p.CODE_VALUE_FR = CODE_VALUE_FR; p.CODE_VALUE_AR = CODE_VALUE_AR; p.ENTRY_DATE = ENTRY_DATE; p.ENTRY_USER_ID = ENTRY_USER_ID; p.NOTES = NOTES;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_EDIT_SETUP", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_EXTRACT_ROUTINE_PARAMETERS ( string ROUTINE_NAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.ROUTINE_NAME = ROUTINE_NAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_EXTRACT_ROUTINE_PARAMETERS", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.ROUTINE_NAME = GV<String>(X["ROUTINE_NAME"]);o.PARAM_NAME = GV<String>(X["PARAM_NAME"]);o.PARAM_TYPE = GV<String>(X["PARAM_TYPE"]);o.IS_OUTPUT = GV<Boolean>(X["IS_OUTPUT"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_EXTRACT_ROUTINE_RESULT_SCHEMA ( string ROUTINE_NAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.ROUTINE_NAME = ROUTINE_NAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_EXTRACT_ROUTINE_RESULT_SCHEMA", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.ROUTINE_NAME = GV<String>(X["ROUTINE_NAME"]);o.COLUMN_NAME = GV<String>(X["COLUMN_NAME"]);o.COLUMN_TYPE = GV<String>(X["COLUMN_TYPE"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GENERATE_INSERT_STATEMENTS ( string @tableName)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.@tableName = @tableName;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GENERATE_INSERT_STATEMENTS", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_NEXT_VALUE ( string STARTER_CODE,ref  Int32? VALUE)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.STARTER_CODE = STARTER_CODE; p.VALUE = VALUE;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_NEXT_VALUE", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
VALUE = p.VALUE;
return oList;
}
public List<dynamic> UP_GET_SETUP_ENTRIES ( Int32? OWNER_ID, string TBL_NAME, bool? ISDELETED, bool? ISVISIBLE)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.TBL_NAME = TBL_NAME; p.ISDELETED = ISDELETED; p.ISVISIBLE = ISVISIBLE;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_SETUP_ENTRIES", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.OWNER_ID = GV<Int32>(X["OWNER_ID"]);o.TBL_NAME = GV<String>(X["TBL_NAME"]);o.CODE_NAME = GV<String>(X["CODE_NAME"]);o.ISSYSTEM = GV<Boolean>(X["ISSYSTEM"]);o.ISDELETEABLE = GV<Boolean>(X["ISDELETEABLE"]);o.ISUPDATEABLE = GV<Boolean>(X["ISUPDATEABLE"]);o.DISPLAY_ORDER = GV<Int32>(X["DISPLAY_ORDER"]);o.ISVISIBLE = GV<Boolean>(X["ISVISIBLE"]);o.ISDELETED = GV<Boolean>(X["ISDELETED"]);o.CODE_VALUE_EN = GV<String>(X["CODE_VALUE_EN"]);o.CODE_VALUE_FR = GV<String>(X["CODE_VALUE_FR"]);o.CODE_VALUE_AR = GV<String>(X["CODE_VALUE_AR"]);o.NOTES = GV<String>(X["NOTES"]);o.ENTRY_DATE = GV<String>(X["ENTRY_DATE"]);o.ENTRY_USER_ID = GV<Int64>(X["ENTRY_USER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_SETUP_ENTRY ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.TBL_NAME = TBL_NAME; p.CODE_NAME = CODE_NAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_SETUP_ENTRY", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.OWNER_ID = GV<Int32>(X["OWNER_ID"]);o.TBL_NAME = GV<String>(X["TBL_NAME"]);o.CODE_NAME = GV<String>(X["CODE_NAME"]);o.ISSYSTEM = GV<Boolean>(X["ISSYSTEM"]);o.ISDELETEABLE = GV<Boolean>(X["ISDELETEABLE"]);o.ISUPDATEABLE = GV<Boolean>(X["ISUPDATEABLE"]);o.DISPLAY_ORDER = GV<Int32>(X["DISPLAY_ORDER"]);o.ISVISIBLE = GV<Boolean>(X["ISVISIBLE"]);o.ISDELETED = GV<Boolean>(X["ISDELETED"]);o.CODE_VALUE_EN = GV<String>(X["CODE_VALUE_EN"]);o.CODE_VALUE_FR = GV<String>(X["CODE_VALUE_FR"]);o.CODE_VALUE_AR = GV<String>(X["CODE_VALUE_AR"]);o.NOTES = GV<String>(X["NOTES"]);o.ENTRY_DATE = GV<String>(X["ENTRY_DATE"]);o.ENTRY_USER_ID = GV<Int64>(X["ENTRY_USER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_USER_BY_CREDENTIALS ( Int32? OWNER_ID, string USERNAME, string PASSWORD)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.USERNAME = USERNAME; p.PASSWORD = PASSWORD;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_USER_BY_CREDENTIALS", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.USER_ID = GV<Int64>(X["USER_ID"]);o.OWNER_ID = GV<Int32>(X["OWNER_ID"]);o.USERNAME = GV<String>(X["USERNAME"]);o.PASSWORD = GV<String>(X["PASSWORD"]);o.ENTRY_DATE = GV<String>(X["ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_USER_BY_USERNAME ( string @__USERNAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.@__USERNAME = @__USERNAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_USER_BY_USERNAME", p);
if (R != null) {foreach (var X in R) {
dynamic o = new ExpandoObject();
o.USER_ID = GV<Int64>(X["USER_ID"]);o.OWNER_ID = GV<Int32>(X["OWNER_ID"]);o.USERNAME = GV<String>(X["USERNAME"]);o.PASSWORD = GV<String>(X["PASSWORD"]);o.USER_TYPE_CODE = GV<String>(X["USER_TYPE_CODE"]);o.IS_LOGGED_IN = GV<Boolean>(X["IS_LOGGED_IN"]);o.IS_ACTIVE = GV<Boolean>(X["IS_ACTIVE"]);o.ENTRY_DATE = GV<String>(X["ENTRY_DATE"]);o.FTS = GV<String>(X["FTS"]);
oList.Add(o);
}
}
return oList;
}
}
}
