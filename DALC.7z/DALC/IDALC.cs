using System;
using System.Collections.Generic;
namespace DALC
{
#region Repositories
public partial class Coach_leaderboards
{
public Int32? COACH_LEADERBOARDS_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? POINTS {get;set;}
public Int32? STANDING {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public Coach My_Coach {get;set;}
}
public partial class Player_leaderboards
{
public Int32? PLAYER_LEADERBOARDS_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? POINTS {get;set;}
public Int32? STANDING {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public Player My_Player {get;set;}
}
public partial class Playersport
{
public Int32? PLAYERSPORT_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Player My_Player {get;set;}
public Sport My_Sport {get;set;}
}
public partial class Sport
{
public Int32? SPORT_ID {get;set;}
public string SPORT_NAME {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Coachsport
{
public Int32? COACHSPORT_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public Int32? COACH_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Sport My_Sport {get;set;}
public Coach My_Coach {get;set;}
}
public partial class Coach_evaluation
{
public Int32? COACH_EVALUATION_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public decimal RATING {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
}
public partial class Currency
{
public Int32? CURRENCY_ID {get;set;}
public string CURRENCY_NAME {get;set;}
public decimal TO_USD {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Session_evaluation
{
public Int32? SESSION_EVALUATION_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public decimal SESSION_RATING {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Coach My_Coach {get;set;}
public Player My_Player {get;set;}
}
public partial class Taken_session
{
public Int32? TAKEN_SESSION_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public string DATETIME {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Coach My_Coach {get;set;}
public Player My_Player {get;set;}
public Sport My_Sport {get;set;}
}
public partial class Scheduled_session
{
public Int32? SCHEDULED_SESSION_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? SPORT_ID {get;set;}
public string DATE_TIME {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
public Sport My_Sport {get;set;}
}
public partial class Notification
{
public Int32? NOTIFICATION_ID {get;set;}
public Int32? USER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
}
public partial class Owner
{
public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Comment
{
public Int32? COMMENT_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public bool? IS_BLOCKED {get;set;}
public Int32? REPORTS {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
}
public partial class Report_coach
{
public Int32? REPORT_COACH_ID {get;set;}
public Int32? USER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
public Coach My_Coach {get;set;}
}
public partial class Comment_report
{
public Int32? COMMENT_REPORT_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public Int32? COACH_ID {get;set;}
public Int32? COMMENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Player My_Player {get;set;}
public Coach My_Coach {get;set;}
public Comment My_Comment {get;set;}
}
public partial class User
{
public long? USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public bool? IS_LOGGED_IN {get;set;}
public bool? IS_ACTIVE {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Direct_message
{
public long? DIRECT_MESSAGE_ID {get;set;}
public Int32? AUTHOR_ID {get;set;}
public Int32? RECIPIENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public bool? IS_DELETED_BY_RECIPIENT {get;set;}
public string DATETIME {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_Author {get;set;}
public User My_Recipient {get;set;}
}
public partial class Report_player
{
public Int32? REPORT_PLAYER_ID {get;set;}
public long? USER_ID {get;set;}
public Int32? PLAYER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
public Player My_Player {get;set;}
}
public partial class Coach
{
public Int32? COACH_ID {get;set;}
public long? USER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public Int32? PRICE_PER_SESSION {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public Int32? AGE {get;set;}
public string GEO_LOCATION {get;set;}
public Int32? SCORE {get;set;}
public Int32? SESSIONS_COMPLETED {get;set;}
public Int32? REPORT {get;set;}
public bool? IS_BLOCKED {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
}
public partial class Player
{
public Int32? PLAYER_ID {get;set;}
public string FIRSTNAME {get;set;}
public string LASTNAME {get;set;}
public long? USER_ID {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public Int32? AGE {get;set;}
public string GEO_LOCATION {get;set;}
public Int32? SESSIONS_COMPLETED {get;set;}
public bool? IS_BLOCKED {get;set;}
public Int32? REPORTS {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
}
#endregion 
public partial interface IDALC
{
Coach_leaderboards Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID ( Int32? COACH_LEADERBOARDS_ID);
Player_leaderboards Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID ( Int32? PLAYER_LEADERBOARDS_ID);
Playersport Get_Playersport_By_PLAYERSPORT_ID ( Int32? PLAYERSPORT_ID);
Sport Get_Sport_By_SPORT_ID ( Int32? SPORT_ID);
Coachsport Get_Coachsport_By_COACHSPORT_ID ( Int32? COACHSPORT_ID);
Coach_evaluation Get_Coach_evaluation_By_COACH_EVALUATION_ID ( Int32? COACH_EVALUATION_ID);
Currency Get_Currency_By_CURRENCY_ID ( Int32? CURRENCY_ID);
Session_evaluation Get_Session_evaluation_By_SESSION_EVALUATION_ID ( Int32? SESSION_EVALUATION_ID);
Taken_session Get_Taken_session_By_TAKEN_SESSION_ID ( Int32? TAKEN_SESSION_ID);
Scheduled_session Get_Scheduled_session_By_SCHEDULED_SESSION_ID ( Int32? SCHEDULED_SESSION_ID);
Notification Get_Notification_By_NOTIFICATION_ID ( Int32? NOTIFICATION_ID);
Owner Get_Owner_By_OWNER_ID ( Int32? OWNER_ID);
Comment Get_Comment_By_COMMENT_ID ( Int32? COMMENT_ID);
Report_coach Get_Report_coach_By_REPORT_COACH_ID ( Int32? REPORT_COACH_ID);
Comment_report Get_Comment_report_By_COMMENT_REPORT_ID ( Int32? COMMENT_REPORT_ID);
User Get_User_By_USER_ID ( long? USER_ID);
Direct_message Get_Direct_message_By_DIRECT_MESSAGE_ID ( long? DIRECT_MESSAGE_ID);
Report_player Get_Report_player_By_REPORT_PLAYER_ID ( Int32? REPORT_PLAYER_ID);
Coach Get_Coach_By_COACH_ID ( Int32? COACH_ID);
Player Get_Player_By_PLAYER_ID ( Int32? PLAYER_ID);
Coach_leaderboards Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_Adv ( Int32? COACH_LEADERBOARDS_ID);
Player_leaderboards Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_Adv ( Int32? PLAYER_LEADERBOARDS_ID);
Playersport Get_Playersport_By_PLAYERSPORT_ID_Adv ( Int32? PLAYERSPORT_ID);
Sport Get_Sport_By_SPORT_ID_Adv ( Int32? SPORT_ID);
Coachsport Get_Coachsport_By_COACHSPORT_ID_Adv ( Int32? COACHSPORT_ID);
Coach_evaluation Get_Coach_evaluation_By_COACH_EVALUATION_ID_Adv ( Int32? COACH_EVALUATION_ID);
Currency Get_Currency_By_CURRENCY_ID_Adv ( Int32? CURRENCY_ID);
Session_evaluation Get_Session_evaluation_By_SESSION_EVALUATION_ID_Adv ( Int32? SESSION_EVALUATION_ID);
Taken_session Get_Taken_session_By_TAKEN_SESSION_ID_Adv ( Int32? TAKEN_SESSION_ID);
Scheduled_session Get_Scheduled_session_By_SCHEDULED_SESSION_ID_Adv ( Int32? SCHEDULED_SESSION_ID);
Notification Get_Notification_By_NOTIFICATION_ID_Adv ( Int32? NOTIFICATION_ID);
Comment Get_Comment_By_COMMENT_ID_Adv ( Int32? COMMENT_ID);
Report_coach Get_Report_coach_By_REPORT_COACH_ID_Adv ( Int32? REPORT_COACH_ID);
Comment_report Get_Comment_report_By_COMMENT_REPORT_ID_Adv ( Int32? COMMENT_REPORT_ID);
User Get_User_By_USER_ID_Adv ( long? USER_ID);
Direct_message Get_Direct_message_By_DIRECT_MESSAGE_ID_Adv ( long? DIRECT_MESSAGE_ID);
Report_player Get_Report_player_By_REPORT_PLAYER_ID_Adv ( Int32? REPORT_PLAYER_ID);
Coach Get_Coach_By_COACH_ID_Adv ( Int32? COACH_ID);
Player Get_Player_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List ( List<Int32?> COACH_LEADERBOARDS_ID_LIST);
List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List ( List<Int32?> PLAYER_LEADERBOARDS_ID_LIST);
List<Playersport> Get_Playersport_By_PLAYERSPORT_ID_List ( List<Int32?> PLAYERSPORT_ID_LIST);
List<Sport> Get_Sport_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST);
List<Coachsport> Get_Coachsport_By_COACHSPORT_ID_List ( List<Int32?> COACHSPORT_ID_LIST);
List<Coach_evaluation> Get_Coach_evaluation_By_COACH_EVALUATION_ID_List ( List<Int32?> COACH_EVALUATION_ID_LIST);
List<Currency> Get_Currency_By_CURRENCY_ID_List ( List<Int32?> CURRENCY_ID_LIST);
List<Session_evaluation> Get_Session_evaluation_By_SESSION_EVALUATION_ID_List ( List<Int32?> SESSION_EVALUATION_ID_LIST);
List<Taken_session> Get_Taken_session_By_TAKEN_SESSION_ID_List ( List<Int32?> TAKEN_SESSION_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List ( List<Int32?> SCHEDULED_SESSION_ID_LIST);
List<Notification> Get_Notification_By_NOTIFICATION_ID_List ( List<Int32?> NOTIFICATION_ID_LIST);
List<Owner> Get_Owner_By_OWNER_ID_List ( List<Int32?> OWNER_ID_LIST);
List<Comment> Get_Comment_By_COMMENT_ID_List ( List<Int32?> COMMENT_ID_LIST);
List<Report_coach> Get_Report_coach_By_REPORT_COACH_ID_List ( List<Int32?> REPORT_COACH_ID_LIST);
List<Comment_report> Get_Comment_report_By_COMMENT_REPORT_ID_List ( List<Int32?> COMMENT_REPORT_ID_LIST);
List<User> Get_User_By_USER_ID_List ( List<long?> USER_ID_LIST);
List<Direct_message> Get_Direct_message_By_DIRECT_MESSAGE_ID_List ( List<long?> DIRECT_MESSAGE_ID_LIST);
List<Report_player> Get_Report_player_By_REPORT_PLAYER_ID_List ( List<Int32?> REPORT_PLAYER_ID_LIST);
List<Coach> Get_Coach_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Player> Get_Player_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_LEADERBOARDS_ID_List_Adv ( List<Int32?> COACH_LEADERBOARDS_ID_LIST);
List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_LEADERBOARDS_ID_List_Adv ( List<Int32?> PLAYER_LEADERBOARDS_ID_LIST);
List<Playersport> Get_Playersport_By_PLAYERSPORT_ID_List_Adv ( List<Int32?> PLAYERSPORT_ID_LIST);
List<Sport> Get_Sport_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST);
List<Coachsport> Get_Coachsport_By_COACHSPORT_ID_List_Adv ( List<Int32?> COACHSPORT_ID_LIST);
List<Coach_evaluation> Get_Coach_evaluation_By_COACH_EVALUATION_ID_List_Adv ( List<Int32?> COACH_EVALUATION_ID_LIST);
List<Currency> Get_Currency_By_CURRENCY_ID_List_Adv ( List<Int32?> CURRENCY_ID_LIST);
List<Session_evaluation> Get_Session_evaluation_By_SESSION_EVALUATION_ID_List_Adv ( List<Int32?> SESSION_EVALUATION_ID_LIST);
List<Taken_session> Get_Taken_session_By_TAKEN_SESSION_ID_List_Adv ( List<Int32?> TAKEN_SESSION_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_SCHEDULED_SESSION_ID_List_Adv ( List<Int32?> SCHEDULED_SESSION_ID_LIST);
List<Notification> Get_Notification_By_NOTIFICATION_ID_List_Adv ( List<Int32?> NOTIFICATION_ID_LIST);
List<Comment> Get_Comment_By_COMMENT_ID_List_Adv ( List<Int32?> COMMENT_ID_LIST);
List<Report_coach> Get_Report_coach_By_REPORT_COACH_ID_List_Adv ( List<Int32?> REPORT_COACH_ID_LIST);
List<Comment_report> Get_Comment_report_By_COMMENT_REPORT_ID_List_Adv ( List<Int32?> COMMENT_REPORT_ID_LIST);
List<User> Get_User_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST);
List<Direct_message> Get_Direct_message_By_DIRECT_MESSAGE_ID_List_Adv ( List<long?> DIRECT_MESSAGE_ID_LIST);
List<Report_player> Get_Report_player_By_REPORT_PLAYER_ID_List_Adv ( List<Int32?> REPORT_PLAYER_ID_LIST);
List<Coach> Get_Coach_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Player> Get_Player_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Coach_leaderboards> Get_Coach_leaderboards_By_OWNER_ID ( Int32? OWNER_ID);
List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID ( Int32? COACH_ID);
List<Player_leaderboards> Get_Player_leaderboards_By_OWNER_ID ( Int32? OWNER_ID);
List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Playersport> Get_Playersport_By_OWNER_ID ( Int32? OWNER_ID);
List<Playersport> Get_Playersport_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Playersport> Get_Playersport_By_SPORT_ID ( Int32? SPORT_ID);
List<Sport> Get_Sport_By_OWNER_ID ( Int32? OWNER_ID);
List<Coachsport> Get_Coachsport_By_OWNER_ID ( Int32? OWNER_ID);
List<Coachsport> Get_Coachsport_By_SPORT_ID ( Int32? SPORT_ID);
List<Coachsport> Get_Coachsport_By_COACH_ID ( Int32? COACH_ID);
List<Coach_evaluation> Get_Coach_evaluation_By_OWNER_ID ( Int32? OWNER_ID);
List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID ( Int32? COACH_ID);
List<Currency> Get_Currency_By_OWNER_ID ( Int32? OWNER_ID);
List<Session_evaluation> Get_Session_evaluation_By_OWNER_ID ( Int32? OWNER_ID);
List<Session_evaluation> Get_Session_evaluation_By_COACH_ID ( Int32? COACH_ID);
List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Taken_session> Get_Taken_session_By_OWNER_ID ( Int32? OWNER_ID);
List<Taken_session> Get_Taken_session_By_COACH_ID ( Int32? COACH_ID);
List<Taken_session> Get_Taken_session_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Taken_session> Get_Taken_session_By_SPORT_ID ( Int32? SPORT_ID);
List<Scheduled_session> Get_Scheduled_session_By_OWNER_ID ( Int32? OWNER_ID);
List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Scheduled_session> Get_Scheduled_session_By_COACH_ID ( Int32? COACH_ID);
List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID ( Int32? SPORT_ID);
List<Notification> Get_Notification_By_OWNER_ID ( Int32? OWNER_ID);
List<Notification> Get_Notification_By_USER_ID ( Int32? USER_ID);
List<Comment> Get_Comment_By_OWNER_ID ( Int32? OWNER_ID);
List<Comment> Get_Comment_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Comment> Get_Comment_By_COACH_ID ( Int32? COACH_ID);
List<Report_coach> Get_Report_coach_By_OWNER_ID ( Int32? OWNER_ID);
List<Report_coach> Get_Report_coach_By_USER_ID ( Int32? USER_ID);
List<Report_coach> Get_Report_coach_By_COACH_ID ( Int32? COACH_ID);
List<Comment_report> Get_Comment_report_By_OWNER_ID ( Int32? OWNER_ID);
List<Comment_report> Get_Comment_report_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Comment_report> Get_Comment_report_By_COACH_ID ( Int32? COACH_ID);
List<Comment_report> Get_Comment_report_By_COMMENT_ID ( Int32? COMMENT_ID);
List<User> Get_User_By_OWNER_ID ( Int32? OWNER_ID);
List<User> Get_User_By_USERNAME ( string USERNAME);
List<Direct_message> Get_Direct_message_By_OWNER_ID ( Int32? OWNER_ID);
List<Direct_message> Get_Direct_message_By_AUTHOR_ID ( Int32? AUTHOR_ID);
List<Direct_message> Get_Direct_message_By_RECIPIENT_ID ( Int32? RECIPIENT_ID);
List<Report_player> Get_Report_player_By_OWNER_ID ( Int32? OWNER_ID);
List<Report_player> Get_Report_player_By_USER_ID ( long? USER_ID);
List<Report_player> Get_Report_player_By_PLAYER_ID ( Int32? PLAYER_ID);
List<Coach> Get_Coach_By_OWNER_ID ( Int32? OWNER_ID);
List<Coach> Get_Coach_By_USER_ID ( long? USER_ID);
List<Player> Get_Player_By_OWNER_ID ( Int32? OWNER_ID);
List<Player> Get_Player_By_USER_ID ( long? USER_ID);
List<Coach_leaderboards> Get_Coach_leaderboards_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Player_leaderboards> Get_Player_leaderboards_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Playersport> Get_Playersport_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Playersport> Get_Playersport_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Playersport> Get_Playersport_By_SPORT_ID_Adv ( Int32? SPORT_ID);
List<Sport> Get_Sport_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Coachsport> Get_Coachsport_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Coachsport> Get_Coachsport_By_SPORT_ID_Adv ( Int32? SPORT_ID);
List<Coachsport> Get_Coachsport_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Coach_evaluation> Get_Coach_evaluation_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Currency> Get_Currency_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Session_evaluation> Get_Session_evaluation_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Taken_session> Get_Taken_session_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Taken_session> Get_Taken_session_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Taken_session> Get_Taken_session_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Taken_session> Get_Taken_session_By_SPORT_ID_Adv ( Int32? SPORT_ID);
List<Scheduled_session> Get_Scheduled_session_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_Adv ( Int32? SPORT_ID);
List<Notification> Get_Notification_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Notification> Get_Notification_By_USER_ID_Adv ( Int32? USER_ID);
List<Comment> Get_Comment_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Comment> Get_Comment_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Comment> Get_Comment_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Report_coach> Get_Report_coach_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Report_coach> Get_Report_coach_By_USER_ID_Adv ( Int32? USER_ID);
List<Report_coach> Get_Report_coach_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Comment_report> Get_Comment_report_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Comment_report> Get_Comment_report_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Comment_report> Get_Comment_report_By_COACH_ID_Adv ( Int32? COACH_ID);
List<Comment_report> Get_Comment_report_By_COMMENT_ID_Adv ( Int32? COMMENT_ID);
List<User> Get_User_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<User> Get_User_By_USERNAME_Adv ( string USERNAME);
List<Direct_message> Get_Direct_message_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Direct_message> Get_Direct_message_By_AUTHOR_ID_Adv ( Int32? AUTHOR_ID);
List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_Adv ( Int32? RECIPIENT_ID);
List<Report_player> Get_Report_player_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Report_player> Get_Report_player_By_USER_ID_Adv ( long? USER_ID);
List<Report_player> Get_Report_player_By_PLAYER_ID_Adv ( Int32? PLAYER_ID);
List<Coach> Get_Coach_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Coach> Get_Coach_By_USER_ID_Adv ( long? USER_ID);
List<Player> Get_Player_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Player> Get_Player_By_USER_ID_Adv ( long? USER_ID);
List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Playersport> Get_Playersport_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Playersport> Get_Playersport_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST);
List<Coachsport> Get_Coachsport_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST);
List<Coachsport> Get_Coachsport_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Taken_session> Get_Taken_session_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Taken_session> Get_Taken_session_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Taken_session> Get_Taken_session_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_List ( List<Int32?> SPORT_ID_LIST);
List<Notification> Get_Notification_By_USER_ID_List ( List<Int32?> USER_ID_LIST);
List<Comment> Get_Comment_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Comment> Get_Comment_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Report_coach> Get_Report_coach_By_USER_ID_List ( List<Int32?> USER_ID_LIST);
List<Report_coach> Get_Report_coach_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Comment_report> Get_Comment_report_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Comment_report> Get_Comment_report_By_COACH_ID_List ( List<Int32?> COACH_ID_LIST);
List<Comment_report> Get_Comment_report_By_COMMENT_ID_List ( List<Int32?> COMMENT_ID_LIST);
List<Direct_message> Get_Direct_message_By_AUTHOR_ID_List ( List<Int32?> AUTHOR_ID_LIST);
List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_List ( List<Int32?> RECIPIENT_ID_LIST);
List<Report_player> Get_Report_player_By_USER_ID_List ( List<long?> USER_ID_LIST);
List<Report_player> Get_Report_player_By_PLAYER_ID_List ( List<Int32?> PLAYER_ID_LIST);
List<Coach> Get_Coach_By_USER_ID_List ( List<long?> USER_ID_LIST);
List<Player> Get_Player_By_USER_ID_List ( List<long?> USER_ID_LIST);
List<Coach_leaderboards> Get_Coach_leaderboards_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Player_leaderboards> Get_Player_leaderboards_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Playersport> Get_Playersport_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Playersport> Get_Playersport_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST);
List<Coachsport> Get_Coachsport_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST);
List<Coachsport> Get_Coachsport_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Coach_evaluation> Get_Coach_evaluation_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Coach_evaluation> Get_Coach_evaluation_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Session_evaluation> Get_Session_evaluation_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Session_evaluation> Get_Session_evaluation_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Taken_session> Get_Taken_session_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Taken_session> Get_Taken_session_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Taken_session> Get_Taken_session_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Scheduled_session> Get_Scheduled_session_By_SPORT_ID_List_Adv ( List<Int32?> SPORT_ID_LIST);
List<Notification> Get_Notification_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST);
List<Comment> Get_Comment_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Comment> Get_Comment_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Report_coach> Get_Report_coach_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST);
List<Report_coach> Get_Report_coach_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Comment_report> Get_Comment_report_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Comment_report> Get_Comment_report_By_COACH_ID_List_Adv ( List<Int32?> COACH_ID_LIST);
List<Comment_report> Get_Comment_report_By_COMMENT_ID_List_Adv ( List<Int32?> COMMENT_ID_LIST);
List<Direct_message> Get_Direct_message_By_AUTHOR_ID_List_Adv ( List<Int32?> AUTHOR_ID_LIST);
List<Direct_message> Get_Direct_message_By_RECIPIENT_ID_List_Adv ( List<Int32?> RECIPIENT_ID_LIST);
List<Report_player> Get_Report_player_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST);
List<Report_player> Get_Report_player_By_PLAYER_ID_List_Adv ( List<Int32?> PLAYER_ID_LIST);
List<Coach> Get_Coach_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST);
List<Player> Get_Player_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Sport> Get_Sport_By_Criteria ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Sport> Get_Sport_By_Where ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Currency> Get_Currency_By_Criteria ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Currency> Get_Currency_By_Where ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Criteria ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Where ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Criteria ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Where ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Criteria ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Where ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Criteria ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Where ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Criteria_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Where_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Criteria ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Where ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Criteria ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Where ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Direct_message> Get_Direct_message_By_Criteria ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Direct_message> Get_Direct_message_By_Where ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach> Get_Coach_By_Criteria ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach> Get_Coach_By_Where ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player> Get_Player_By_Criteria ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player> Get_Player_By_Where ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Sport> Get_Sport_By_Criteria_Adv ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Sport> Get_Sport_By_Where_Adv ( string SPORT_NAME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Currency> Get_Currency_By_Criteria_Adv ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Currency> Get_Currency_By_Where_Adv ( string CURRENCY_NAME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Criteria_Adv ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Where_Adv ( string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Criteria_Adv ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Where_Adv ( string DATE_TIME, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Criteria_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Where_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Criteria_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Where_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Criteria_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Where_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Direct_message> Get_Direct_message_By_Criteria_Adv ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Direct_message> Get_Direct_message_By_Where_Adv ( string DESCRIPTION, string DATETIME, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach> Get_Coach_By_Criteria_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach> Get_Coach_By_Where_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player> Get_Player_By_Criteria_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player> Get_Player_By_Where_Adv ( string FIRSTNAME, string LASTNAME, string EMAIL, string MOBILE, string GEO_LOCATION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Criteria_InList ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Where_InList ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Criteria_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Where_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Criteria_InList ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Where_InList ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Criteria_InList ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Where_InList ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Criteria_InList ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Where_InList ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Criteria_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Where_InList ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Criteria_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Where_InList ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_leaderboards> Get_Coach_leaderboards_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Player_leaderboards> Get_Player_leaderboards_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Playersport> Get_Playersport_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coachsport> Get_Coachsport_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> SPORT_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Coach_evaluation> Get_Coach_evaluation_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Session_evaluation> Get_Session_evaluation_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Criteria_InList_Adv ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Taken_session> Get_Taken_session_By_Where_InList_Adv ( string DATETIME, List<Int32?> COACH_ID_LIST, List<Int32?> PLAYER_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Criteria_InList_Adv ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Scheduled_session> Get_Scheduled_session_By_Where_InList_Adv ( string DATE_TIME, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> SPORT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Criteria_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment> Get_Comment_By_Where_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_coach> Get_Report_coach_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> COACH_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Comment_report> Get_Comment_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, List<Int32?> COACH_ID_LIST, List<Int32?> COMMENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_player> Get_Report_player_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> PLAYER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
void Delete_Coach_leaderboards ( Int32? COACH_LEADERBOARDS_ID);
void Delete_Player_leaderboards ( Int32? PLAYER_LEADERBOARDS_ID);
void Delete_Playersport ( Int32? PLAYERSPORT_ID);
void Delete_Sport ( Int32? SPORT_ID);
void Delete_Coachsport ( Int32? COACHSPORT_ID);
void Delete_Coach_evaluation ( Int32? COACH_EVALUATION_ID);
void Delete_Currency ( Int32? CURRENCY_ID);
void Delete_Session_evaluation ( Int32? SESSION_EVALUATION_ID);
void Delete_Taken_session ( Int32? TAKEN_SESSION_ID);
void Delete_Scheduled_session ( Int32? SCHEDULED_SESSION_ID);
void Delete_Notification ( Int32? NOTIFICATION_ID);
void Delete_Owner ( Int32? OWNER_ID);
void Delete_Comment ( Int32? COMMENT_ID);
void Delete_Report_coach ( Int32? REPORT_COACH_ID);
void Delete_Comment_report ( Int32? COMMENT_REPORT_ID);
void Delete_User ( long? USER_ID);
void Delete_Direct_message ( long? DIRECT_MESSAGE_ID);
void Delete_Report_player ( Int32? REPORT_PLAYER_ID);
void Delete_Coach ( Int32? COACH_ID);
void Delete_Player ( Int32? PLAYER_ID);
void Delete_Coach_leaderboards_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Coach_leaderboards_By_COACH_ID ( Int32? COACH_ID);
void Delete_Player_leaderboards_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Player_leaderboards_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Playersport_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Playersport_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Playersport_By_SPORT_ID ( Int32? SPORT_ID);
void Delete_Sport_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Coachsport_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Coachsport_By_SPORT_ID ( Int32? SPORT_ID);
void Delete_Coachsport_By_COACH_ID ( Int32? COACH_ID);
void Delete_Coach_evaluation_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Coach_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Coach_evaluation_By_COACH_ID ( Int32? COACH_ID);
void Delete_Currency_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Session_evaluation_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Session_evaluation_By_COACH_ID ( Int32? COACH_ID);
void Delete_Session_evaluation_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Taken_session_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Taken_session_By_COACH_ID ( Int32? COACH_ID);
void Delete_Taken_session_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Taken_session_By_SPORT_ID ( Int32? SPORT_ID);
void Delete_Scheduled_session_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Scheduled_session_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Scheduled_session_By_COACH_ID ( Int32? COACH_ID);
void Delete_Scheduled_session_By_SPORT_ID ( Int32? SPORT_ID);
void Delete_Notification_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Notification_By_USER_ID ( Int32? USER_ID);
void Delete_Comment_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Comment_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Comment_By_COACH_ID ( Int32? COACH_ID);
void Delete_Report_coach_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Report_coach_By_USER_ID ( Int32? USER_ID);
void Delete_Report_coach_By_COACH_ID ( Int32? COACH_ID);
void Delete_Comment_report_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Comment_report_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Comment_report_By_COACH_ID ( Int32? COACH_ID);
void Delete_Comment_report_By_COMMENT_ID ( Int32? COMMENT_ID);
void Delete_User_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_User_By_USERNAME ( string USERNAME);
void Delete_Direct_message_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Direct_message_By_AUTHOR_ID ( Int32? AUTHOR_ID);
void Delete_Direct_message_By_RECIPIENT_ID ( Int32? RECIPIENT_ID);
void Delete_Report_player_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Report_player_By_USER_ID ( long? USER_ID);
void Delete_Report_player_By_PLAYER_ID ( Int32? PLAYER_ID);
void Delete_Coach_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Coach_By_USER_ID ( long? USER_ID);
void Delete_Player_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Player_By_USER_ID ( long? USER_ID);
Int32? Edit_Coach_leaderboards ( Int32? COACH_LEADERBOARDS_ID, Int32? COACH_ID, Int32? POINTS, Int32? STANDING, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION);
Int32? Edit_Player_leaderboards ( Int32? PLAYER_LEADERBOARDS_ID, Int32? PLAYER_ID, Int32? POINTS, Int32? STANDING, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION);
Int32? Edit_Playersport ( Int32? PLAYERSPORT_ID, Int32? PLAYER_ID, Int32? SPORT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Sport ( Int32? SPORT_ID, string SPORT_NAME, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Coachsport ( Int32? COACHSPORT_ID, Int32? SPORT_ID, Int32? COACH_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Coach_evaluation ( Int32? COACH_EVALUATION_ID, Int32? PLAYER_ID, Int32? COACH_ID, decimal RATING, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Currency ( Int32? CURRENCY_ID, string CURRENCY_NAME, decimal TO_USD, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Session_evaluation ( Int32? SESSION_EVALUATION_ID, Int32? COACH_ID, Int32? PLAYER_ID, decimal SESSION_RATING, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Taken_session ( Int32? TAKEN_SESSION_ID, Int32? COACH_ID, Int32? PLAYER_ID, Int32? SPORT_ID, string DATETIME, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Scheduled_session ( Int32? SCHEDULED_SESSION_ID, Int32? PLAYER_ID, Int32? COACH_ID, Int32? SPORT_ID, string DATE_TIME, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Notification ( Int32? NOTIFICATION_ID, Int32? USER_ID, string TITLE, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Owner ( Int32? OWNER_ID, string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, string ENTRY_DATE);
Int32? Edit_Comment ( Int32? COMMENT_ID, Int32? PLAYER_ID, Int32? COACH_ID, bool? IS_BLOCKED, Int32? REPORTS, string TITLE, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Report_coach ( Int32? REPORT_COACH_ID, Int32? USER_ID, Int32? COACH_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Comment_report ( Int32? COMMENT_REPORT_ID, Int32? PLAYER_ID, Int32? COACH_ID, Int32? COMMENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
long? Edit_User ( long? USER_ID, Int32? OWNER_ID, string USERNAME, string PASSWORD, string USER_TYPE_CODE, bool? IS_LOGGED_IN, bool? IS_ACTIVE, string ENTRY_DATE);
long? Edit_Direct_message ( long? DIRECT_MESSAGE_ID, Int32? AUTHOR_ID, Int32? RECIPIENT_ID, string DESCRIPTION, bool? IS_DELETED_BY_RECIPIENT, string DATETIME, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Report_player ( Int32? REPORT_PLAYER_ID, long? USER_ID, Int32? PLAYER_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Coach ( Int32? COACH_ID, long? USER_ID, string FIRSTNAME, string LASTNAME, Int32? PRICE_PER_SESSION, string EMAIL, string MOBILE, Int32? AGE, string GEO_LOCATION, Int32? SCORE, Int32? SESSIONS_COMPLETED, Int32? REPORT, bool? IS_BLOCKED, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Player ( Int32? PLAYER_ID, string FIRSTNAME, string LASTNAME, long? USER_ID, string EMAIL, string MOBILE, Int32? AGE, string GEO_LOCATION, Int32? SESSIONS_COMPLETED, bool? IS_BLOCKED, Int32? REPORTS, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
List<dynamic> GET_DISTINCT_SETUP_TBL ( Int32? OWNER_ID);
List<dynamic> GET_NEXT_VALUE ( string STARTER_CODE);
List<dynamic> GET_TBL_SETUP ();
List<dynamic> UP_CHECK_USER_EXISTENCE ( Int32? OWNER_ID, string USERNAME,ref  bool? EXISTS);
List<dynamic> UP_EDIT_SETUP ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME, bool? ISSYSTEM, bool? ISDELETEABLE, bool? ISUPDATEABLE, bool? ISVISIBLE, bool? ISDELETED, Int32? DISPLAY_ORDER, string CODE_VALUE_EN, string CODE_VALUE_FR, string CODE_VALUE_AR, string ENTRY_DATE, Int32? ENTRY_USER_ID, string NOTES);
List<dynamic> UP_EXTRACT_ROUTINE_PARAMETERS ( string ROUTINE_NAME);
List<dynamic> UP_EXTRACT_ROUTINE_RESULT_SCHEMA ( string ROUTINE_NAME);
List<dynamic> UP_GENERATE_INSERT_STATEMENTS ( string @tableName);
List<dynamic> UP_GET_NEXT_VALUE ( string STARTER_CODE,ref  Int32? VALUE);
List<dynamic> UP_GET_SETUP_ENTRIES ( Int32? OWNER_ID, string TBL_NAME, bool? ISDELETED, bool? ISVISIBLE);
List<dynamic> UP_GET_SETUP_ENTRY ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME);
List<dynamic> UP_GET_USER_BY_CREDENTIALS ( Int32? OWNER_ID, string USERNAME, string PASSWORD);
List<dynamic> UP_GET_USER_BY_USERNAME ( string @__USERNAME);
}
}
